import { createServerFn } from "@tanstack/react-start";
import { getSql } from "@/lib/db";
import { authMiddleware } from "@/lib/auth/middleware";
import { getSessionUser } from "@/lib/auth/verify.server";
import { ensureSeed } from "./seed";
import type {
  Comment,
  Conversation,
  Message,
  NotificationItem,
  Post,
  Profile,
  StoryGroup,
} from "./types";

type Sql = Awaited<ReturnType<typeof getSql>>;

async function optionalUserId(): Promise<string | null> {
  try {
    const u = await getSessionUser();
    return u?.id ?? null;
  } catch {
    return null;
  }
}

function slugBase(input: string): string {
  const s = input
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "")
    .slice(0, 16);
  return s || "nexly";
}

async function uniqueUsername(sql: Sql, base: string, userId: string): Promise<string> {
  let candidate = base;
  for (let i = 0; i < 40; i++) {
    const rows = await sql<{ user_id: string }>`
      select user_id from profiles where username = ${candidate}
    `;
    if (rows.length === 0 || rows[0].user_id === userId) return candidate;
    candidate = `${base.slice(0, 12)}${Math.floor(10 + Math.random() * 89)}`;
  }
  return `${base.slice(0, 10)}${Date.now().toString(36).slice(-4)}`;
}

export async function ensureProfile(
  sql: Sql,
  userId: string,
  hint?: { name?: string | null; email?: string | null; image?: string | null },
): Promise<void> {
  const existing = await sql`select user_id from profiles where user_id = ${userId}`;
  if (existing.length) return;
  const base = slugBase(hint?.name || hint?.email?.split("@")[0] || "nexly");
  const username = await uniqueUsername(sql, base, userId);
  const display = (hint?.name && hint.name.trim()) || username;
  await sql`
    insert into profiles (user_id, username, display_name, avatar_url)
    values (${userId}, ${username}, ${display}, ${hint?.image ?? null})
    on conflict (user_id) do nothing
  `;
}

async function ready(sql: Sql) {
  await ensureSeed(sql);
}

function toIso(v: unknown): string {
  if (v instanceof Date) return v.toISOString();
  if (typeof v === "string") return v;
  return new Date().toISOString();
}

type PostRow = {
  id: number;
  user_id: string;
  image_url: string;
  caption: string;
  location: string | null;
  music_track_id: string | null;
  music_name: string | null;
  music_artist: string | null;
  music_preview_url: string | null;
  music_artwork_url: string | null;
  created_at: string | Date;
  username: string;
  display_name: string;
  avatar_url: string | null;
  like_count: number;
  comment_count: number;
  liked_by_me: number | boolean;
  saved_by_me: number | boolean;
};

function mapPost(row: PostRow): Post {
  return {
    id: Number(row.id),
    userId: row.user_id,
    username: row.username,
    displayName: row.display_name,
    avatarUrl: row.avatar_url,
    imageUrl: row.image_url,
    caption: row.caption,
    location: row.location,
    music:
      row.music_name && row.music_artist
        ? {
            trackId: row.music_track_id ?? row.music_name,
            name: row.music_name,
            artist: row.music_artist,
            previewUrl: row.music_preview_url,
            artworkUrl: row.music_artwork_url,
          }
        : null,
    createdAt: toIso(row.created_at),
    likeCount: Number(row.like_count),
    commentCount: Number(row.comment_count),
    likedByMe: Boolean(row.liked_by_me),
    savedByMe: Boolean(row.saved_by_me),
  };
}

const POST_SELECT = `
  select
    p.id, p.user_id, p.image_url, p.caption, p.location,
    p.music_track_id, p.music_name, p.music_artist, p.music_preview_url, p.music_artwork_url,
    p.created_at,
    pr.username, pr.display_name, pr.avatar_url,
    (select count(*)::int from likes l where l.post_id = p.id) as like_count,
    (select count(*)::int from comments c where c.post_id = p.id) as comment_count,
    case when $1::text is null then 0
         when exists (select 1 from likes l2 where l2.post_id = p.id and l2.user_id = $1) then 1
         else 0 end as liked_by_me,
    case when $1::text is null then 0
         when exists (select 1 from saves s where s.post_id = p.id and s.user_id = $1) then 1
         else 0 end as saved_by_me
`;

export const getFeed = createServerFn({ method: "GET" })
  .validator((payload?: { tab?: "foryou" | "following" }) => payload ?? { tab: "foryou" as const })
  .handler(async ({ data }) => {
    const sql = await getSql();
    await ready(sql);
    const me = await optionalUserId();
    const tab = data?.tab === "following" ? "following" : "foryou";
    const rows =
      tab === "following" && me
        ? await sql.query<PostRow>(
            `${POST_SELECT}
             from posts p
             join profiles pr on pr.user_id = p.user_id
             where p.user_id in (select following_id from follows where follower_id = $2)
                or p.user_id = $2
             order by p.created_at desc
             limit 60`,
            [me, me],
          )
        : await sql.query<PostRow>(
            `${POST_SELECT}
             from posts p
             join profiles pr on pr.user_id = p.user_id
             order by p.created_at desc
             limit 60`,
            [me],
          );
    return rows.map(mapPost);
  });

export const getExplore = createServerFn({ method: "GET" }).handler(async () => {
  const sql = await getSql();
  await ready(sql);
  const me = await optionalUserId();
  const rows = await sql.query<PostRow>(
    `${POST_SELECT}
     from posts p
     join profiles pr on pr.user_id = p.user_id
     order by like_count desc, p.created_at desc
     limit 48`,
    [me],
  );
  return rows.map(mapPost);
});

export const getPost = createServerFn({ method: "GET" })
  .validator((id: number) => Number(id))
  .handler(async ({ data: id }) => {
    const sql = await getSql();
    await ready(sql);
    const me = await optionalUserId();
    const rows = await sql.query<PostRow>(
      `${POST_SELECT}
       from posts p
       join profiles pr on pr.user_id = p.user_id
       where p.id = $2`,
      [me, id],
    );
    return rows[0] ? mapPost(rows[0]) : null;
  });

export const getStories = createServerFn({ method: "GET" }).handler(async () => {
  const sql = await getSql();
  await ready(sql);
  const rows = await sql<{
    id: number;
    user_id: string;
    image_url: string;
    created_at: string | Date;
    username: string;
    display_name: string;
    avatar_url: string | null;
  }>`
    select s.id, s.user_id, s.image_url, s.created_at,
           pr.username, pr.display_name, pr.avatar_url
    from stories s
    join profiles pr on pr.user_id = s.user_id
    where s.expires_at > now()
    order by s.created_at desc
  `;
  const map = new Map<string, StoryGroup>();
  for (const r of rows) {
    let g = map.get(r.user_id);
    if (!g) {
      g = {
        userId: r.user_id,
        username: r.username,
        displayName: r.display_name,
        avatarUrl: r.avatar_url,
        items: [],
      };
      map.set(r.user_id, g);
    }
    g.items.push({ id: Number(r.id), imageUrl: r.image_url, createdAt: toIso(r.created_at) });
  }
  return [...map.values()];
});

export const getComments = createServerFn({ method: "GET" })
  .validator((postId: number) => Number(postId))
  .handler(async ({ data: postId }) => {
    const sql = await getSql();
    const rows = await sql<{
      id: number;
      post_id: number;
      user_id: string;
      body: string;
      created_at: string | Date;
      username: string;
      display_name: string;
      avatar_url: string | null;
    }>`
      select c.id, c.post_id, c.user_id, c.body, c.created_at,
             pr.username, pr.display_name, pr.avatar_url
      from comments c
      join profiles pr on pr.user_id = c.user_id
      where c.post_id = ${postId}
      order by c.created_at asc
      limit 80
    `;
    return rows.map(
      (r): Comment => ({
        id: Number(r.id),
        postId: Number(r.post_id),
        userId: r.user_id,
        username: r.username,
        displayName: r.display_name,
        avatarUrl: r.avatar_url,
        body: r.body,
        createdAt: toIso(r.created_at),
      }),
    );
  });

export const searchAll = createServerFn({ method: "GET" })
  .validator((q: string) => String(q ?? "").trim().slice(0, 60))
  .handler(async ({ data: q }) => {
    const sql = await getSql();
    await ready(sql);
    const me = await optionalUserId();
    if (!q) return { people: [] as Profile[], posts: [] as Post[] };
    const like = `%${q.toLowerCase()}%`;
    const people = await sql<{
      user_id: string;
      username: string;
      display_name: string;
      bio: string;
      avatar_url: string | null;
      website: string | null;
      is_seed: boolean;
      created_at: string | Date;
    }>`
      select user_id, username, display_name, bio, avatar_url, website, is_seed, created_at
      from profiles
      where lower(username) like ${like} or lower(display_name) like ${like}
      order by is_seed desc, username
      limit 16
    `;
    const posts = await sql.query<PostRow>(
      `${POST_SELECT}
       from posts p
       join profiles pr on pr.user_id = p.user_id
       where lower(p.caption) like $2 or lower(coalesce(p.location,'')) like $2
          or lower(pr.username) like $2
       order by p.created_at desc
       limit 24`,
      [me, like],
    );
    const mappedPeople: Profile[] = [];
    for (const p of people) {
      mappedPeople.push(await hydrateProfile(sql, p, me));
    }
    return { people: mappedPeople, posts: posts.map(mapPost) };
  });

async function hydrateProfile(
  sql: Sql,
  p: {
    user_id: string;
    username: string;
    display_name: string;
    bio: string;
    avatar_url: string | null;
    website: string | null;
    is_seed: boolean;
    created_at: string | Date;
  },
  me: string | null,
): Promise<Profile> {
  const [posts, followers, following, followRow] = await Promise.all([
    sql<{ c: number }>`select count(*)::int as c from posts where user_id = ${p.user_id}`,
    sql<{ c: number }>`select count(*)::int as c from follows where following_id = ${p.user_id}`,
    sql<{ c: number }>`select count(*)::int as c from follows where follower_id = ${p.user_id}`,
    me && me !== p.user_id
      ? sql`select 1 from follows where follower_id = ${me} and following_id = ${p.user_id}`
      : Promise.resolve([]),
  ]);
  return {
    userId: p.user_id,
    username: p.username,
    displayName: p.display_name,
    bio: p.bio,
    avatarUrl: p.avatar_url,
    website: p.website,
    isSeed: Boolean(p.is_seed),
    createdAt: toIso(p.created_at),
    postsCount: Number(posts[0]?.c ?? 0),
    followersCount: Number(followers[0]?.c ?? 0),
    followingCount: Number(following[0]?.c ?? 0),
    isFollowing: followRow.length > 0,
    isMe: me === p.user_id,
  };
}

export const getProfile = createServerFn({ method: "GET" })
  .validator((username: string) => String(username).replace(/^@/, "").slice(0, 32))
  .handler(async ({ data: username }) => {
    const sql = await getSql();
    await ready(sql);
    const me = await optionalUserId();
    const rows = await sql<{
      user_id: string;
      username: string;
      display_name: string;
      bio: string;
      avatar_url: string | null;
      website: string | null;
      is_seed: boolean;
      created_at: string | Date;
    }>`
      select user_id, username, display_name, bio, avatar_url, website, is_seed, created_at
      from profiles where lower(username) = ${username.toLowerCase()}
    `;
    if (!rows[0]) return null;
    const profile = await hydrateProfile(sql, rows[0], me);
    const posts = await sql.query<PostRow>(
      `${POST_SELECT}
       from posts p
       join profiles pr on pr.user_id = p.user_id
       where p.user_id = $2
       order by p.created_at desc
       limit 60`,
      [me, rows[0].user_id],
    );
    return { profile, posts: posts.map(mapPost) };
  });

export const getMyProfile = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const sql = await getSql();
    await ready(sql);
    await ensureProfile(sql, context.userId);
    const rows = await sql<{
      user_id: string;
      username: string;
      display_name: string;
      bio: string;
      avatar_url: string | null;
      website: string | null;
      is_seed: boolean;
      created_at: string | Date;
    }>`
      select user_id, username, display_name, bio, avatar_url, website, is_seed, created_at
      from profiles where user_id = ${context.userId}
    `;
    if (!rows[0]) return null;
    return hydrateProfile(sql, rows[0], context.userId);
  });

export const bootstrapMe = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((hint: { name?: string | null; email?: string | null; image?: string | null }) => hint)
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    await ready(sql);
    await ensureProfile(sql, context.userId, data);
    const rows = await sql<{
      user_id: string;
      username: string;
      display_name: string;
      bio: string;
      avatar_url: string | null;
      website: string | null;
      is_seed: boolean;
      created_at: string | Date;
    }>`
      select user_id, username, display_name, bio, avatar_url, website, is_seed, created_at
      from profiles where user_id = ${context.userId}
    `;
    return rows[0] ? hydrateProfile(sql, rows[0], context.userId) : null;
  });

export const updateProfile = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator(
    (data: { username: string; displayName: string; bio: string; website: string; avatarUrl?: string | null }) => {
      const username = slugBase(data.username).slice(0, 20);
      const displayName = data.displayName.trim().slice(0, 40) || username;
      const bio = data.bio.trim().slice(0, 160);
      const website = data.website.trim().slice(0, 120);
      if (data.avatarUrl && data.avatarUrl.length > 550000) {
        throw new Error("La foto de perfil es demasiado pesada");
      }
      return { username, displayName, bio, website, avatarUrl: data.avatarUrl };
    },
  )
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    await ensureProfile(sql, context.userId);
    const taken = await sql<{ user_id: string }>`
      select user_id from profiles where username = ${data.username} and user_id <> ${context.userId}
    `;
    if (taken.length) throw new Error("Ese nombre de usuario ya existe");
    await sql`
      update profiles set
        username = ${data.username},
        display_name = ${data.displayName},
        bio = ${data.bio},
        website = ${data.website || null},
        avatar_url = coalesce(${data.avatarUrl ?? null}, avatar_url)
      where user_id = ${context.userId}
    `;
    return { ok: true as const };
  });

export const createPost = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator(
    (data: {
      imageUrl: string;
      caption: string;
      location: string;
      music?: {
        trackId: string;
        name: string;
        artist: string;
        previewUrl: string | null;
        artworkUrl: string | null;
      } | null;
    }) => {
      if (!data.imageUrl || data.imageUrl.length < 20) throw new Error("Falta la foto");
      if (data.imageUrl.length > 650000) throw new Error("La foto es demasiado pesada");
      return {
        imageUrl: data.imageUrl,
        caption: data.caption.trim().slice(0, 500),
        location: data.location.trim().slice(0, 80),
        music: data.music ?? null,
      };
    },
  )
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    await ensureProfile(sql, context.userId);
    const rows = await sql<{ id: number }>`
      insert into posts (
        user_id, image_url, caption, location,
        music_track_id, music_name, music_artist, music_preview_url, music_artwork_url
      ) values (
        ${context.userId},
        ${data.imageUrl},
        ${data.caption},
        ${data.location || null},
        ${data.music?.trackId ?? null},
        ${data.music?.name ?? null},
        ${data.music?.artist ?? null},
        ${data.music?.previewUrl ?? null},
        ${data.music?.artworkUrl ?? null}
      )
      returning id
    `;
    return { id: Number(rows[0].id) };
  });

export const createStory = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((imageUrl: string) => {
    if (!imageUrl || imageUrl.length > 650000) throw new Error("Foto no válida");
    return imageUrl;
  })
  .handler(async ({ context, data: imageUrl }) => {
    const sql = await getSql();
    await ensureProfile(sql, context.userId);
    await sql`
      insert into stories (user_id, image_url, expires_at)
      values (${context.userId}, ${imageUrl}, now() + interval '24 hours')
    `;
    return { ok: true as const };
  });

export const toggleLike = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((postId: number) => Number(postId))
  .handler(async ({ context, data: postId }) => {
    const sql = await getSql();
    await ensureProfile(sql, context.userId);
    const existing = await sql`
      select 1 from likes where post_id = ${postId} and user_id = ${context.userId}
    `;
    if (existing.length) {
      await sql`delete from likes where post_id = ${postId} and user_id = ${context.userId}`;
      return { liked: false };
    }
    await sql`insert into likes (post_id, user_id) values (${postId}, ${context.userId})`;
    const post = await sql<{ user_id: string }>`select user_id from posts where id = ${postId}`;
    const owner = post[0]?.user_id;
    if (owner && owner !== context.userId && !owner.startsWith("seed:")) {
      await sql`
        insert into notifications (user_id, actor_id, type, post_id)
        values (${owner}, ${context.userId}, 'like', ${postId})
      `;
    }
    return { liked: true };
  });

export const toggleSave = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((postId: number) => Number(postId))
  .handler(async ({ context, data: postId }) => {
    const sql = await getSql();
    await ensureProfile(sql, context.userId);
    const existing = await sql`
      select 1 from saves where post_id = ${postId} and user_id = ${context.userId}
    `;
    if (existing.length) {
      await sql`delete from saves where post_id = ${postId} and user_id = ${context.userId}`;
      return { saved: false };
    }
    await sql`insert into saves (post_id, user_id) values (${postId}, ${context.userId})`;
    return { saved: true };
  });

export const addComment = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((data: { postId: number; body: string }) => {
    const body = data.body.trim().slice(0, 280);
    if (!body) throw new Error("Escribe un comentario");
    return { postId: Number(data.postId), body };
  })
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    await ensureProfile(sql, context.userId);
    const rows = await sql<{ id: number; created_at: string | Date }>`
      insert into comments (post_id, user_id, body)
      values (${data.postId}, ${context.userId}, ${data.body})
      returning id, created_at
    `;
    const post = await sql<{ user_id: string }>`select user_id from posts where id = ${data.postId}`;
    const owner = post[0]?.user_id;
    if (owner && owner !== context.userId && !owner.startsWith("seed:")) {
      await sql`
        insert into notifications (user_id, actor_id, type, post_id)
        values (${owner}, ${context.userId}, 'comment', ${data.postId})
      `;
    }
    const me = await sql<{ username: string; display_name: string; avatar_url: string | null }>`
      select username, display_name, avatar_url from profiles where user_id = ${context.userId}
    `;
    const c: Comment = {
      id: Number(rows[0].id),
      postId: data.postId,
      userId: context.userId,
      username: me[0]?.username ?? "tu",
      displayName: me[0]?.display_name ?? "Tú",
      avatarUrl: me[0]?.avatar_url ?? null,
      body: data.body,
      createdAt: toIso(rows[0].created_at),
    };
    return c;
  });

export const toggleFollow = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((userId: string) => String(userId))
  .handler(async ({ context, data: userId }) => {
    if (userId === context.userId) return { following: false };
    const sql = await getSql();
    await ensureProfile(sql, context.userId);
    const existing = await sql`
      select 1 from follows where follower_id = ${context.userId} and following_id = ${userId}
    `;
    if (existing.length) {
      await sql`delete from follows where follower_id = ${context.userId} and following_id = ${userId}`;
      return { following: false };
    }
    await sql`
      insert into follows (follower_id, following_id)
      values (${context.userId}, ${userId})
      on conflict do nothing
    `;
    if (!userId.startsWith("seed:")) {
      await sql`
        insert into notifications (user_id, actor_id, type)
        values (${userId}, ${context.userId}, 'follow')
      `;
    }
    return { following: true };
  });

export const getSaved = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const sql = await getSql();
    await ready(sql);
    const rows = await sql.query<PostRow>(
      `${POST_SELECT}
       from saves sv
       join posts p on p.id = sv.post_id
       join profiles pr on pr.user_id = p.user_id
       where sv.user_id = $1
       order by sv.created_at desc
       limit 60`,
      [context.userId],
    );
    return rows.map(mapPost);
  });

export const getNotifications = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const sql = await getSql();
    const rows = await sql<{
      id: number;
      type: string;
      post_id: number | null;
      created_at: string | Date;
      is_read: boolean;
      actor_id: string;
      username: string;
      display_name: string;
      avatar_url: string | null;
    }>`
      select n.id, n.type, n.post_id, n.created_at, n.is_read,
             n.actor_id, pr.username, pr.display_name, pr.avatar_url
      from notifications n
      join profiles pr on pr.user_id = n.actor_id
      where n.user_id = ${context.userId}
      order by n.created_at desc
      limit 40
    `;
    return rows.map(
      (r): NotificationItem => ({
        id: Number(r.id),
        type: r.type,
        postId: r.post_id == null ? null : Number(r.post_id),
        createdAt: toIso(r.created_at),
        isRead: Boolean(r.is_read),
        actor: {
          userId: r.actor_id,
          username: r.username,
          displayName: r.display_name,
          avatarUrl: r.avatar_url,
        },
      }),
    );
  });

export const markNotificationsRead = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const sql = await getSql();
    await sql`update notifications set is_read = true where user_id = ${context.userId} and is_read = false`;
    return { ok: true as const };
  });

export const getConversations = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const sql = await getSql();
    await ensureProfile(sql, context.userId);
    const rows = await sql<{
      other_id: string;
      username: string;
      display_name: string;
      avatar_url: string | null;
      last_body: string;
      last_at: string | Date;
      unread: number;
    }>`
      with last as (
        select distinct on (
          case when sender_id = ${context.userId} then recipient_id else sender_id end
        )
          case when sender_id = ${context.userId} then recipient_id else sender_id end as other_id,
          body as last_body,
          created_at as last_at
        from messages
        where sender_id = ${context.userId} or recipient_id = ${context.userId}
        order by
          case when sender_id = ${context.userId} then recipient_id else sender_id end,
          created_at desc
      )
      select l.other_id, pr.username, pr.display_name, pr.avatar_url,
             l.last_body, l.last_at,
             (select count(*)::int from messages m
              where m.sender_id = l.other_id and m.recipient_id = ${context.userId} and m.read_at is null
             ) as unread
      from last l
      join profiles pr on pr.user_id = l.other_id
      order by l.last_at desc
    `;
    return rows.map(
      (r): Conversation => ({
        userId: r.other_id,
        username: r.username,
        displayName: r.display_name,
        avatarUrl: r.avatar_url,
        lastBody: r.last_body,
        lastAt: toIso(r.last_at),
        unread: Number(r.unread),
      }),
    );
  });

export const getMessages = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .validator((username: string) => String(username))
  .handler(async ({ context, data: username }) => {
    const sql = await getSql();
    await ensureProfile(sql, context.userId);
    const other = await sql<{ user_id: string; username: string; display_name: string; avatar_url: string | null }>`
      select user_id, username, display_name, avatar_url from profiles where lower(username) = ${username.toLowerCase()}
    `;
    if (!other[0]) return { peer: null, messages: [] as Message[] };
    const peerId = other[0].user_id;
    const rows = await sql<{
      id: number;
      sender_id: string;
      recipient_id: string;
      body: string;
      created_at: string | Date;
    }>`
      select id, sender_id, recipient_id, body, created_at
      from messages
      where (sender_id = ${context.userId} and recipient_id = ${peerId})
         or (sender_id = ${peerId} and recipient_id = ${context.userId})
      order by created_at asc
      limit 200
    `;
    await sql`
      update messages set read_at = now()
      where sender_id = ${peerId} and recipient_id = ${context.userId} and read_at is null
    `;
    return {
      peer: {
        userId: other[0].user_id,
        username: other[0].username,
        displayName: other[0].display_name,
        avatarUrl: other[0].avatar_url,
      },
      messages: rows.map(
        (r): Message => ({
          id: Number(r.id),
          senderId: r.sender_id,
          recipientId: r.recipient_id,
          body: r.body,
          createdAt: toIso(r.created_at),
          mine: r.sender_id === context.userId,
        }),
      ),
    };
  });

export const sendMessage = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((data: { username: string; body: string }) => {
    const body = data.body.trim().slice(0, 500);
    if (!body) throw new Error("Escribe un mensaje");
    return { username: data.username, body };
  })
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    await ensureProfile(sql, context.userId);
    const other = await sql<{ user_id: string }>`
      select user_id from profiles where lower(username) = ${data.username.toLowerCase()}
    `;
    if (!other[0]) throw new Error("No existe esa persona");
    if (other[0].user_id === context.userId) throw new Error("No puedes escribirte a ti");
    const rows = await sql<{ id: number; created_at: string | Date }>`
      insert into messages (sender_id, recipient_id, body)
      values (${context.userId}, ${other[0].user_id}, ${data.body})
      returning id, created_at
    `;
    const msg: Message = {
      id: Number(rows[0].id),
      senderId: context.userId,
      recipientId: other[0].user_id,
      body: data.body,
      createdAt: toIso(rows[0].created_at),
      mine: true,
    };
    return msg;
  });

export const deletePost = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((postId: number) => Number(postId))
  .handler(async ({ context, data: postId }) => {
    const sql = await getSql();
    await sql`delete from posts where id = ${postId} and user_id = ${context.userId}`;
    return { ok: true as const };
  });
