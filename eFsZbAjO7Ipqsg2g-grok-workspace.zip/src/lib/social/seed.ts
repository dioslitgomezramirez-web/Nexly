import type { Sql } from "@/lib/db";
import { fetchItunesSongs } from "./itunes";

type SeedPost = {
  image: string;
  caption: string;
  location: string;
  song: string;
  hoursAgo: number;
};

type SeedUser = {
  id: string;
  username: string;
  displayName: string;
  bio: string;
  avatar: string;
  posts: SeedPost[];
  story: string;
};

const img = (id: string, w = 900, h = 1125) =>
  `https://images.unsplash.com/${id}?auto=format&fit=crop&w=${w}&h=${h}&q=80`;

const av = (id: string) =>
  `https://images.unsplash.com/${id}?auto=format&fit=crop&w=240&h=240&q=80&facepad=2`;

const USERS: SeedUser[] = [
  {
    id: "seed:lunavera",
    username: "luna.vera",
    displayName: "Luna Vera",
    bio: "Viajo ligera. Luz de las seis. Película caducada a propósito.",
    avatar: av("photo-1524504388940-b1c1722653e1"),
    story: img("photo-1507525428034-b723cf961d3e", 720, 1280),
    posts: [
      {
        image: img("photo-1507525428034-b723cf961d3e"),
        caption: "El mar no pregunta a qué hora llegas.",
        location: "Formentera",
        song: "Rosalia MALAMENTE",
        hoursAgo: 4,
      },
      {
        image: img("photo-1469474968028-56623f02e42e"),
        caption: "Niebla en el valle y el termo aún caliente.",
        location: "Picos de Europa",
        song: "Natalia Lafourcade Hasta la Raiz",
        hoursAgo: 28,
      },
      {
        image: img("photo-1470071459604-3b5ec3a7fe05"),
        caption: "Caminé hasta que el GPS se rindió.",
        location: "Glencoe, Escocia",
        song: "Radiohead Creep",
        hoursAgo: 72,
      },
      {
        image: img("photo-1500534314209-a25ddb2bd429"),
        caption: "Arena, viento, y una idea que no se va.",
        location: "Atacama",
        song: "Tame Impala The Less I Know The Better",
        hoursAgo: 140,
      },
    ],
  },
  {
    id: "seed:marcoatlas",
    username: "marco.atlas",
    displayName: "Marco Atlas",
    bio: "Hormigón, sombra y geometría. Arquitectura que se deja retratar.",
    avatar: av("photo-1506794778202-cad84cf45f1d"),
    story: img("photo-1480714378408-67cf0d13bc1b", 720, 1280),
    posts: [
      {
        image: img("photo-1480714378408-67cf0d13bc1b"),
        caption: "La ciudad de noche es un circuito impreso.",
        location: "Tokio",
        song: "The Weeknd Blinding Lights",
        hoursAgo: 7,
      },
      {
        image: img("photo-1486325212027-8081e485255e"),
        caption: "Simetría que duele de tan limpia.",
        location: "Lisboa",
        song: "Daft Punk Get Lucky",
        hoursAgo: 40,
      },
      {
        image: img("photo-1441974231531-c6227db76b6e"),
        caption: "Entre el bosque y el edificio, elige ambos.",
        location: "Vancouver",
        song: "Bon Iver Holocene",
        hoursAgo: 96,
      },
      {
        image: img("photo-1493246507139-91e8fad9978e"),
        caption: "El horizonte es una línea que alguien dibujó mal.",
        location: "Islandia",
        song: "Sigur Ros Hoppipolla",
        hoursAgo: 180,
      },
    ],
  },
  {
    id: "seed:norafilm",
    username: "nora.film",
    displayName: "Nora Film",
    bio: "35 mm. Revelado en el fregadero. Nada de filtros: solo grano.",
    avatar: av("photo-1487412720507-e7ab37603c6f"),
    story: img("photo-1529626455594-4ff0802cfb7e", 720, 1280),
    posts: [
      {
        image: img("photo-1529626455594-4ff0802cfb7e"),
        caption: "El último rollo del verano.",
        location: "Estudio, Madrid",
        song: "Sade Smooth Operator",
        hoursAgo: 9,
      },
      {
        image: img("photo-1494790108377-be9c29b29330"),
        caption: "Luz de ventana, siempre.",
        location: "Malasaña",
        song: "Frank Ocean Pink White",
        hoursAgo: 50,
      },
      {
        image: img("photo-1539571696357-5a69c17a67c6"),
        caption: "Retrato a f/1.4 y una conversación larga.",
        location: "Barcelona",
        song: "Arctic Monkeys Do I Wanna Know",
        hoursAgo: 110,
      },
      {
        image: img("photo-1515886657613-9f3515e0c79f"),
        caption: "Rojo de estudio. No se discute.",
        location: "París",
        song: "The xx Intro",
        hoursAgo: 200,
      },
    ],
  },
  {
    id: "seed:kaiwaves",
    username: "kai.waves",
    displayName: "Kai Waves",
    bio: "Mareas, cera y madrugones. Si no hay olas, hay café.",
    avatar: av("photo-1507003211169-0a1dd7228f2d"),
    story: img("photo-1502680390469-be93e304b0dd", 720, 1280),
    posts: [
      {
        image: img("photo-1502680390469-be93e304b0dd"),
        caption: "Agua de 16 grados. El cuerpo ya lo sabe.",
        location: "Mundaka",
        song: "Jack Johnson Banana Pancakes",
        hoursAgo: 6,
      },
      {
        image: img("photo-1507525428034-b723cf961d3e"),
        caption: "El set de las 7:12. Nadie más en el pico.",
        location: "Ericeira",
        song: "Mac DeMarco Chamber of Reflection",
        hoursAgo: 33,
      },
      {
        image: img("photo-1439066615861-d1af74d74000"),
        caption: "Lago en calma, tabla en el techo.",
        location: "Annecy",
        song: "Khruangbin White Gloves",
        hoursAgo: 88,
      },
      {
        image: img("photo-1468413253725-0d518d4d1bb7"),
        caption: "El cielo hizo el resto.",
        location: "Byron Bay",
        song: "Tame Impala Let It Happen",
        hoursAgo: 160,
      },
    ],
  },
  {
    id: "seed:islakitchen",
    username: "isla.kitchen",
    displayName: "Isla Kitchen",
    bio: "Recetas de domingo. Mantequilla a temperatura ambiente.",
    avatar: av("photo-1438761681033-6461ffad8d80"),
    story: img("photo-1504674900247-0877df9cc836", 720, 1280),
    posts: [
      {
        image: img("photo-1504674900247-0877df9cc836"),
        caption: "Mesa para nadie y para todos.",
        location: "Casa",
        song: "Norah Jones Don't Know Why",
        hoursAgo: 3,
      },
      {
        image: img("photo-1540189549336-e6eac4ab0bb0"),
        caption: "Pasta, albahaca, y el último rayo de sol.",
        location: "Bolonia",
        song: "Andrea Bocelli Con Te Partiro",
        hoursAgo: 26,
      },
      {
        image: img("photo-1482049016687-2d3ff1b3fdcb"),
        caption: "Huevos, pan y un periódico que ya nadie compra.",
        location: "Oporto",
        song: "Cafe Tacvba Eres",
        hoursAgo: 70,
      },
      {
        image: img("photo-1414235077428-338989a2e8c0"),
        caption: "El primer plato de la noche.",
        location: "San Sebastián",
        song: "Buena Vista Social Club Chan Chan",
        hoursAgo: 130,
      },
    ],
  },
  {
    id: "seed:theonight",
    username: "theo.night",
    displayName: "Theo Night",
    bio: "Neón, lluvia y taxis. La ciudad cuando se quita el maquillaje.",
    avatar: av("photo-1472099645785-5658abf4ff4e"),
    story: img("photo-1492684223066-81342ee5ff30", 720, 1280),
    posts: [
      {
        image: img("photo-1492684223066-81342ee5ff30"),
        caption: "El concierto empezó antes de entrar.",
        location: "Berlin",
        song: "Daft Punk One More Time",
        hoursAgo: 8,
      },
      {
        image: img("photo-1514525253161-7a46d19cd819"),
        caption: "Luces que no piden permiso.",
        location: "Seúl",
        song: "The Weeknd Save Your Tears",
        hoursAgo: 44,
      },
      {
        image: img("photo-1519677100203-a0e668c92439"),
        caption: "Calle mojada, ISO alto, corazón rápido.",
        location: "Nueva York",
        song: "The xx Angels",
        hoursAgo: 102,
      },
      {
        image: img("photo-1511379938547-c1f69419868d"),
        caption: "Un piano abierto a las 2:13.",
        location: "Jazz club, Ciudad de México",
        song: "Norah Jones Come Away With Me",
        hoursAgo: 210,
      },
    ],
  },
  {
    id: "seed:amarabloom",
    username: "amara.bloom",
    displayName: "Amara Bloom",
    bio: "Flores que duran un día. Las fotografío para que duren más.",
    avatar: av("photo-1544005313-94ddf0286df2"),
    story: img("photo-1490750967868-88aa4a6bc3ea", 720, 1280),
    posts: [
      {
        image: img("photo-1490750967868-88aa4a6bc3ea"),
        caption: "El jardín no entiende de prisas.",
        location: "Kew Gardens",
        song: "Billie Eilish Birds of a Feather",
        hoursAgo: 11,
      },
      {
        image: img("photo-1462275646964-a0e3386b89fa"),
        caption: "Cerezos. Un minuto. Luego el viento.",
        location: "Kioto",
        song: "Joe Hisaishi Path of the Wind",
        hoursAgo: 55,
      },
      {
        image: img("photo-1501004318641-b39e6451bec6"),
        caption: "Verde que limpia la cabeza.",
        location: "Invernadero, Valencia",
        song: "Sade No Ordinary Love",
        hoursAgo: 118,
      },
      {
        image: img("photo-1416879595882-3373a0480b5b"),
        caption: "Campo de trigo, mano en el bolsillo.",
        location: "Toscana",
        song: "Jorge Drexler Todo se transforma",
        hoursAgo: 190,
      },
    ],
  },
  {
    id: "seed:julesstudio",
    username: "jules.studio",
    displayName: "Jules Studio",
    bio: "Moda sin pasarela. Tela, gesto, silencio.",
    avatar: av("photo-1534528741775-53994a69daeb"),
    story: img("photo-1469334031218-e382a71b716b", 720, 1280),
    posts: [
      {
        image: img("photo-1469334031218-e382a71b716b"),
        caption: "El abrigo pesa, la pose no.",
        location: "Milán",
        song: "The Weeknd Die For You",
        hoursAgo: 5,
      },
      {
        image: img("photo-1515886657613-9f3515e0c79f"),
        caption: "Rojo contra hormigón.",
        location: "Estudio 4",
        song: "Rauw Alejandro Todo de Ti",
        hoursAgo: 31,
      },
      {
        image: img("photo-1483985988355-763728e1935b"),
        caption: "Escaparate a las 9:40, antes de abrir.",
        location: "Londres",
        song: "Arctic Monkeys Why'd You Only Call Me",
        hoursAgo: 84,
      },
      {
        image: img("photo-1490481651871-ab68de25d43d"),
        caption: "Seda y una sola fuente de luz.",
        location: "Copenhague",
        song: "Sade Kiss of Life",
        hoursAgo: 150,
      },
    ],
  },
  {
    id: "seed:riotrails",
    username: "rio.trails",
    displayName: "Río Trails",
    bio: "Botas embarradas. Mapas doblados. Cimas que no salen en Google.",
    avatar: av("photo-1500648767791-00dcc994a43e"),
    story: img("photo-1464822759023-fed622ff2c3b", 720, 1280),
    posts: [
      {
        image: img("photo-1464822759023-fed622ff2c3b"),
        caption: "A 2.400 m el aire tiene otra densidad.",
        location: "Alpes suizos",
        song: "Bon Iver Skinny Love",
        hoursAgo: 12,
      },
      {
        image: img("photo-1500530855697-b586d89ba3ee"),
        caption: "Bosque que traga el ruido.",
        location: "Oregon",
        song: "Fleet Foxes White Winter Hymnal",
        hoursAgo: 47,
      },
      {
        image: img("photo-1483728642387-6c3bdd6c93e5"),
        caption: "Cima, nubes debajo, sándwich encima.",
        location: "Patagonia",
        song: "Sigur Ros Svefn-g-englar",
        hoursAgo: 99,
      },
      {
        image: img("photo-1519681393784-d120267933ba"),
        caption: "Dormimos bajo esto. No hay techo mejor.",
        location: "Desierto de Tabernas",
        song: "M83 Midnight City",
        hoursAgo: 170,
      },
    ],
  },
  {
    id: "seed:sofialens",
    username: "sofia.lens",
    displayName: "Sofía Lens",
    bio: "Retratos que no piden sonreír. Gente real, luz real.",
    avatar: av("photo-1531123897727-8f129e1688ce"),
    story: img("photo-1529156069898-49953e39b3ac", 720, 1280),
    posts: [
      {
        image: img("photo-1529156069898-49953e39b3ac"),
        caption: "La risa que no posó.",
        location: "Parque del Retiro",
        song: "Karol G Si Antes Te Hubiera Conocido",
        hoursAgo: 2,
      },
      {
        image: img("photo-1524504388940-b1c1722653e1"),
        caption: "Oro viejo y un jersey de lana.",
        location: "Estudio norte",
        song: "Billie Eilish What Was I Made For",
        hoursAgo: 38,
      },
      {
        image: img("photo-1537633552985-df874d359afe"),
        caption: "Manos. Siempre las manos.",
        location: "Sevilla",
        song: "Rosalia Beso",
        hoursAgo: 92,
      },
      {
        image: img("photo-1517841905240-472988babdf9"),
        caption: "Un retrato y un secreto.",
        location: "Oaxaca",
        song: "Natalia Lafourcade Nunca Es Suficiente",
        hoursAgo: 155,
      },
    ],
  },
  {
    id: "seed:edenceramic",
    username: "eden.ceramic",
    displayName: "Eden Ceramic",
    bio: "Arcilla, torno y paciencia. Lo que se cae se vuelve otra cosa.",
    avatar: av("photo-1508214751196-bcfd4ca60f91"),
    story: img("photo-1565193566173-7a0ee3dbe261", 720, 1280),
    posts: [
      {
        image: img("photo-1565193566173-7a0ee3dbe261"),
        caption: "El torno gira, la cabeza se calla.",
        location: "Taller, Granada",
        song: "Khruangbin Time This Time Tomorrow",
        hoursAgo: 15,
      },
      {
        image: img("photo-1578749556568-bc2c40e68b61"),
        caption: "Esmalte que no salió como esperaba. Mejor.",
        location: "Horno 2",
        song: "C Tangana Tu Me Dejaste De Querer",
        hoursAgo: 60,
      },
      {
        image: img("photo-1610701596007-11502861dcfa"),
        caption: "Estantería de errores hermosos.",
        location: "Taller",
        song: "Feist 1234",
        hoursAgo: 124,
      },
      {
        image: img("photo-1441986300917-64674bd600d8"),
        caption: "Luz de taller a las cuatro.",
        location: "Lisboa",
        song: "The xx Crystalised",
        hoursAgo: 188,
      },
    ],
  },
  {
    id: "seed:nicovinyl",
    username: "nico.vinyl",
    displayName: "Nico Vinyl",
    bio: "Colecciono discos y silencios entre pistas. Café a 33 rpm.",
    avatar: av("photo-1504257432389-52343af06ae3"),
    story: img("photo-1511671782779-c97d3d27a1d4", 720, 1280),
    posts: [
      {
        image: img("photo-1511671782779-c97d3d27a1d4"),
        caption: "La primera cara, siempre.",
        location: "Disquería, Buenos Aires",
        song: "Pink Floyd Wish You Were Here",
        hoursAgo: 1,
      },
      {
        image: img("photo-1511379938547-c1f69419868d"),
        caption: "Afinar es una forma de esperar.",
        location: "Sala de ensayo",
        song: "Radiohead No Surprises",
        hoursAgo: 29,
      },
      {
        image: img("photo-1470225620780-dba8ba36b745"),
        caption: "El público todavía no entra. El aire ya sí.",
        location: "Festival",
        song: "LCD Soundsystem Dance Yrself Clean",
        hoursAgo: 78,
      },
      {
        image: img("photo-1487215078519-e21cc028cb29"),
        caption: "Auriculares, lluvia, lado B.",
        location: "Casa",
        song: "Frank Ocean Ivy",
        hoursAgo: 145,
      },
    ],
  },
  {
    id: "seed:clairepages",
    username: "claire.pages",
    displayName: "Claire Pages",
    bio: "Libros subrayados y mesas junto a la ventana.",
    avatar: av("photo-1548142813-c348350df52b"),
    story: img("photo-1517248135467-4c7edcad34c4", 720, 1280),
    posts: [
      {
        image: img("photo-1517248135467-4c7edcad34c4"),
        caption: "La mesa de siempre. El café, distinto.",
        location: "Café Central, Viena",
        song: "Norah Jones Sunrise",
        hoursAgo: 10,
      },
      {
        image: img("photo-1512820790803-83ca734da794"),
        caption: "Capítulo 12. No molestar.",
        location: "Librería, Oporto",
        song: "Jose Gonzalez Heartbeats",
        hoursAgo: 42,
      },
      {
        image: img("photo-1493770348141-0ef56da6b14e"),
        caption: "Desayuno y una novela que no quiero que acabe.",
        location: "Casa",
        song: "Feist Mushaboom",
        hoursAgo: 86,
      },
      {
        image: img("photo-1524995997946-a1c2e315a42f"),
        caption: "Estanterías como horizonte.",
        location: "Biblioteca, Praga",
        song: "Sufjan Stevens Mystery of Love",
        hoursAgo: 166,
      },
    ],
  },
  {
    id: "seed:andresfuego",
    username: "andres.fuego",
    displayName: "Andrés Fuego",
    bio: "Calle, carbón y salsa que pica. Lo mejor no tiene mantel.",
    avatar: av("photo-1504257432389-52343af06ae3"),
    story: img("photo-1555939594-58d7cb561ad1", 720, 1280),
    posts: [
      {
        image: img("photo-1555939594-58d7cb561ad1"),
        caption: "Humo de carbón a las 14:00. Religión laica.",
        location: "Mercado de San Juan, CDMX",
        song: "Bad Bunny DtMF",
        hoursAgo: 6,
      },
      {
        image: img("photo-1565299624946-b28f40a0ae38"),
        caption: "Pizza que no pide disculpas.",
        location: "Nápoles",
        song: "Nathy Peluso Business Woman",
        hoursAgo: 35,
      },
      {
        image: img("photo-1544025162-d766d818bcd9"),
        caption: "Tacos de la esquina. Cinco. No se discute.",
        location: "Roma Norte",
        song: "Cafe Tacvba La Ingrata",
        hoursAgo: 80,
      },
      {
        image: img("photo-1473093295043-cdd812d0e601"),
        caption: "El último bocado, el mejor.",
        location: "Valencia",
        song: "Karol G Provenza",
        hoursAgo: 148,
      },
    ],
  },
  {
    id: "seed:micacoast",
    username: "mica.coast",
    displayName: "Mica Coast",
    bio: "Acantilados, faros y suéteres que huelen a sal.",
    avatar: av("photo-1524504388940-b1c1722653e1"),
    story: img("photo-1500375592092-40eb2168fd21", 720, 1280),
    posts: [
      {
        image: img("photo-1500375592092-40eb2168fd21"),
        caption: "La ola más alta del mes. Yo, más pequeña.",
        location: "Nazaré",
        song: "Lana Del Rey Summertime Sadness",
        hoursAgo: 13,
      },
      {
        image: img("photo-1473116763249-2faaef81ccda"),
        caption: "Pies en la orilla, cabeza lejos.",
        location: "Algarve",
        song: "The xx Intro",
        hoursAgo: 52,
      },
      {
        image: img("photo-1468413253725-0d518d4d1bb7"),
        caption: "Atardecer que no cabe en el rollo.",
        location: "Cádiz",
        song: "Rosalia Sakura",
        hoursAgo: 108,
      },
      {
        image: img("photo-1439066615861-d1af74d74000"),
        caption: "Agua quieta. Rara vez.",
        location: "Como",
        song: "Cigarettes After Sex Apocalypse",
        hoursAgo: 175,
      },
    ],
  },
  {
    id: "seed:yaragold",
    username: "yara.gold",
    displayName: "Yara Gold",
    bio: "Naturaleza muerta que no está muerta. Latón, tela, fruta.",
    avatar: av("photo-1531746020798-e6953c6e8e04"),
    story: img("photo-1519681393784-d120267933ba", 720, 1280),
    posts: [
      {
        image: img("photo-1490750967868-88aa4a6bc3ea"),
        caption: "Composición de martes. Luz rasante.",
        location: "Estudio",
        song: "Sade Smooth Operator",
        hoursAgo: 16,
      },
      {
        image: img("photo-1519741497674-611481863552"),
        caption: "Detalles que se miran de cerca.",
        location: "Amberes",
        song: "The xx Angels",
        hoursAgo: 58,
      },
      {
        image: img("photo-1515886657613-9f3515e0c79f"),
        caption: "Un rojo. Solo uno.",
        location: "Estudio",
        song: "Rauw Alejandro Todo de Ti",
        hoursAgo: 120,
      },
      {
        image: img("photo-1441986300917-64674bd600d8"),
        caption: "Interior con eco.",
        location: "Copenhagen",
        song: "Jose Gonzalez Heartbeats",
        hoursAgo: 198,
      },
    ],
  },
];

const COMMENTS = [
  "Esto se siente. Qué luz.",
  "Guardada. Voy a volver a mirarla.",
  "¿Qué cámara usaste?",
  "Me transportaste. En serio.",
  "El grano está perfecto.",
  "Quiero estar ahí ahora mismo.",
  "Composición impecable.",
  "Esa hora mágica no miente.",
  "Más de esto, por favor.",
  "Se oye el silencio de la foto.",
];

type TrackHit = {
  trackId: string;
  name: string;
  artist: string;
  previewUrl: string | null;
  artworkUrl: string | null;
};

async function lookupSongs(queries: string[]): Promise<Map<string, TrackHit>> {
  const unique = [...new Set(queries)];
  const map = new Map<string, TrackHit>();
  const chunk = 8;
  for (let i = 0; i < unique.length; i += chunk) {
    const slice = unique.slice(i, i + chunk);
    const results = await Promise.all(
      slice.map(async (q) => {
        try {
          const hits = await fetchItunesSongs(q, 1);
          return [q, hits[0] ?? null] as const;
        } catch {
          return [q, null] as const;
        }
      }),
    );
    for (const [q, track] of results) {
      if (track) map.set(q, track);
    }
  }
  return map;
}

const globalRef = globalThis as typeof globalThis & {
  __nexlySeed__?: Promise<void>;
};

export async function ensureSeed(sql: Sql): Promise<void> {
  globalRef.__nexlySeed__ ??= runSeed(sql).catch((err) => {
    globalRef.__nexlySeed__ = undefined;
    throw err;
  });
  return globalRef.__nexlySeed__;
}
export async function runSeed(sql: Sql): Promise<void> {
  const counted = await sql<{ c: number }>`select count(*)::int as c from profiles where is_seed = true`;
  const n = counted[0]?.c ?? 0;
  if (n >= USERS.length) {
    await sql`
      update stories
      set expires_at = now() + interval '20 days'
      where user_id like 'seed:%' and expires_at < now() + interval '2 days'
    `;
    return;
  }
  if (n > 0) {
    await sql`delete from profiles where is_seed = true`;
  }

  const songQueries = USERS.flatMap((u) => u.posts.map((p) => p.song));
  const tracks = new Map<string, TrackHit>();

  for (const user of USERS) {
    await sql`
      insert into profiles (user_id, username, display_name, bio, avatar_url, is_seed)
      values (
        ${user.id},
        ${user.username},
        ${user.displayName},
        ${user.bio},
        ${user.avatar},
        true
      )
      on conflict (user_id) do nothing
    `;
  }

  for (const user of USERS) {
    await sql`
      insert into stories (user_id, image_url, expires_at)
      values (${user.id}, ${user.story}, now() + interval '20 days')
    `;
    for (const post of user.posts) {
      const track = tracks.get(post.song);
      await sql`
        insert into posts (
          user_id, image_url, caption, location,
          music_track_id, music_name, music_artist, music_preview_url, music_artwork_url,
          created_at
        ) values (
          ${user.id},
          ${post.image},
          ${post.caption},
          ${post.location},
          ${track?.trackId ?? null},
          ${track?.name ?? null},
          ${track?.artist ?? null},
          ${track?.previewUrl ?? null},
          ${track?.artworkUrl ?? null},
          now() - (${post.hoursAgo}::text || ' hours')::interval
        )
      `;
    }
  }

  const posts = await sql<{ id: number; user_id: string }>`
    select id, user_id from posts where user_id like 'seed:%' order by id
  `;

  const followParts: string[] = [];
  const followVals: unknown[] = [];
  let fi = 1;
  for (let i = 0; i < USERS.length; i++) {
    const a = USERS[i];
    for (let j = 1; j <= 5; j++) {
      const b = USERS[(i + j) % USERS.length];
      if (a.id === b.id) continue;
      followParts.push(`($${fi++}, $${fi++})`);
      followVals.push(a.id, b.id);
    }
  }
  if (followParts.length) {
    await sql.query(
      `insert into follows (follower_id, following_id) values ${followParts.join(",")} on conflict do nothing`,
      followVals,
    );
  }

  const likeParts: string[] = [];
  const likeVals: unknown[] = [];
  let li = 1;
  const commentParts: string[] = [];
  const commentVals: unknown[] = [];
  let ci = 1;
  for (const post of posts) {
    const likers = USERS.filter((u) => u.id !== post.user_id).slice(0, 3 + (post.id % 6));
    for (const liker of likers) {
      likeParts.push(`($${li++}, $${li++})`);
      likeVals.push(post.id, liker.id);
    }
    const commenters = USERS.filter((u) => u.id !== post.user_id).slice(post.id % 4, (post.id % 4) + 2);
    for (const c of commenters) {
      const body = COMMENTS[(post.id + c.username.length) % COMMENTS.length];
      commentParts.push(`($${ci++}, $${ci++}, $${ci++})`);
      commentVals.push(post.id, c.id, body);
    }
  }
  if (likeParts.length) {
    await sql.query(
      `insert into likes (post_id, user_id) values ${likeParts.join(",")} on conflict do nothing`,
      likeVals,
    );
  }
  if (commentParts.length) {
    await sql.query(
      `insert into comments (post_id, user_id, body) values ${commentParts.join(",")}`,
      commentVals,
    );
  }

  void attachMusic(sql, songQueries);
}

async function attachMusic(sql: Sql, songQueries: string[]): Promise<void> {
  try {
    const tracks = await lookupSongs(songQueries);
    for (const user of USERS) {
      for (const post of user.posts) {
        const track = tracks.get(post.song);
        if (!track) continue;
        await sql`
          update posts set
            music_track_id = ${track.trackId},
            music_name = ${track.name},
            music_artist = ${track.artist},
            music_preview_url = ${track.previewUrl},
            music_artwork_url = ${track.artworkUrl}
          where user_id = ${user.id} and caption = ${post.caption} and music_track_id is null
        `;
      }
    }
  } catch {
    /* catalog stays without music rather than blocking the feed */
  }
}
