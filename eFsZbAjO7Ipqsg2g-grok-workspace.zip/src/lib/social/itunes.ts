import { createServerFn } from "@tanstack/react-start";
import type { MusicTrack } from "./types";

type ItunesResult = {
  trackId?: number;
  trackName?: string;
  artistName?: string;
  previewUrl?: string;
  artworkUrl100?: string;
  collectionName?: string;
};

function upgradeArt(url: string | undefined | null): string | null {
  if (!url) return null;
  return url.replace("100x100bb", "300x300bb").replace("100x100", "300x300");
}

export function mapItunes(row: ItunesResult): MusicTrack | null {
  if (!row.trackId || !row.trackName || !row.artistName) return null;
  return {
    trackId: String(row.trackId),
    name: row.trackName,
    artist: row.artistName,
    previewUrl: row.previewUrl ?? null,
    artworkUrl: upgradeArt(row.artworkUrl100),
  };
}

export async function fetchItunesSongs(
  term: string,
  limit = 20,
): Promise<MusicTrack[]> {
  const q = term.trim();
  if (!q) return [];
  const url = new URL("https://itunes.apple.com/search");
  url.searchParams.set("term", q);
  url.searchParams.set("media", "music");
  url.searchParams.set("entity", "song");
  url.searchParams.set("limit", String(Math.min(40, Math.max(1, limit))));
  url.searchParams.set("country", "es");
  const res = await fetch(url.toString(), {
    headers: { Accept: "application/json" },
    signal: AbortSignal.timeout(5000),
  });
  if (!res.ok) throw new Error("iTunes no respondió");
  const json = (await res.json()) as { results?: ItunesResult[] };
  const out: MusicTrack[] = [];
  for (const row of json.results ?? []) {
    const mapped = mapItunes(row);
    if (mapped) out.push(mapped);
  }
  return out;
}

type AppleChartItem = {
  id: string;
  name: string;
  artistName: string;
  artworkUrl100: string;
};

export async function fetchAppleChart(): Promise<MusicTrack[]> {
  const res = await fetch(
    "https://rss.applemarketingtools.com/api/v2/es/music/most-played/25/songs.json",
    { headers: { Accept: "application/json" }, signal: AbortSignal.timeout(5000) },
  );
  if (!res.ok) throw new Error("No se pudo leer el ranking de Apple");
  const json = (await res.json()) as {
    feed?: { results?: AppleChartItem[] };
  };
  return (json.feed?.results ?? []).map((item) => ({
    trackId: item.id,
    name: item.name,
    artist: item.artistName,
    previewUrl: null,
    artworkUrl: upgradeArt(item.artworkUrl100),
  }));
}

export const searchMusic = createServerFn({ method: "GET" })
  .validator((term: string) => String(term ?? "").slice(0, 80))
  .handler(async ({ data: term }) => {
    return fetchItunesSongs(term, 24);
  });

export const listTopMusic = createServerFn({ method: "GET" }).handler(
  async () => {
    try {
      return await fetchAppleChart();
    } catch {
      return fetchItunesSongs("pop latino", 20);
    }
  },
);

export const resolvePreview = createServerFn({ method: "GET" })
  .validator((payload: { name: string; artist: string }) => payload)
  .handler(async ({ data }) => {
    const hits = await fetchItunesSongs(`${data.artist} ${data.name}`, 5);
    return hits.find((t) => t.previewUrl)?.previewUrl ?? hits[0]?.previewUrl ?? null;
  });
