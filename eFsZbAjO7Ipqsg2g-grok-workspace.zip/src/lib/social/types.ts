export type Profile = {
  userId: string;
  username: string;
  displayName: string;
  bio: string;
  avatarUrl: string | null;
  website: string | null;
  isSeed: boolean;
  createdAt: string;
  postsCount: number;
  followersCount: number;
  followingCount: number;
  isFollowing: boolean;
  isMe: boolean;
};

export type MusicTrack = {
  trackId: string;
  name: string;
  artist: string;
  previewUrl: string | null;
  artworkUrl: string | null;
};

export type Post = {
  id: number;
  userId: string;
  username: string;
  displayName: string;
  avatarUrl: string | null;
  imageUrl: string;
  caption: string;
  location: string | null;
  music: MusicTrack | null;
  createdAt: string;
  likeCount: number;
  commentCount: number;
  likedByMe: boolean;
  savedByMe: boolean;
};

export type Comment = {
  id: number;
  postId: number;
  userId: string;
  username: string;
  displayName: string;
  avatarUrl: string | null;
  body: string;
  createdAt: string;
};

export type StoryGroup = {
  userId: string;
  username: string;
  displayName: string;
  avatarUrl: string | null;
  items: Array<{ id: number; imageUrl: string; createdAt: string }>;
};

export type Conversation = {
  userId: string;
  username: string;
  displayName: string;
  avatarUrl: string | null;
  lastBody: string;
  lastAt: string;
  unread: number;
};

export type Message = {
  id: number;
  senderId: string;
  recipientId: string;
  body: string;
  createdAt: string;
  mine: boolean;
};

export type NotificationItem = {
  id: number;
  type: string;
  postId: number | null;
  createdAt: string;
  isRead: boolean;
  actor: {
    userId: string;
    username: string;
    displayName: string;
    avatarUrl: string | null;
  };
};
