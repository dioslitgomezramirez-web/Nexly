import { create } from "zustand";
import type { MusicTrack } from "./types";

type PlayerState = {
  track: MusicTrack | null;
  playing: boolean;
  play: (track: MusicTrack) => void;
  pause: () => void;
  toggle: (track?: MusicTrack) => void;
  stop: () => void;
};

export const usePlayer = create<PlayerState>((set, get) => ({
  track: null,
  playing: false,
  play: (track) => set({ track, playing: true }),
  pause: () => set({ playing: false }),
  toggle: (track) => {
    const cur = get();
    if (track && cur.track?.trackId !== track.trackId) {
      set({ track, playing: true });
      return;
    }
    set({ playing: !cur.playing });
  },
  stop: () => set({ track: null, playing: false }),
}));
