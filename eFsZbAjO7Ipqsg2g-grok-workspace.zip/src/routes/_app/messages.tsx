import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { RedirectToSignIn } from "@/lib/auth/gates";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { getConversations } from "@/lib/social/server";
import { Avatar } from "@/components/avatar";
import { timeAgo } from "@/lib/utils";

export const Route = createFileRoute("/_app/messages")({ component: MessagesPage });

function MessagesPage() {
  const { user, isPending } = useCurrentUserState();
  const q = useQuery({
    queryKey: ["conversations"],
    queryFn: () => getConversations(),
    enabled: Boolean(user),
  });
  if (isPending) return <div className="h-40" />;
  if (!user) return <RedirectToSignIn />;

  const items = q.data ?? [];
  return (
    <div className="px-3 py-3">
      <h1 className="font-display text-2xl">Correspondencia</h1>
      {q.isLoading ? (
        <p className="py-12 text-center text-sm text-ink-soft">Abriendo el buzón…</p>
      ) : items.length === 0 ? (
        <p className="py-12 text-center text-sm text-ink-soft">
          Aún no hay cartas. Abre un perfil y pulsa el avión de papel.
        </p>
      ) : (
        <ul className="mt-3 space-y-2">
          {items.map((c) => (
            <li key={c.userId}>
              <Link
                to="/messages/$username"
                params={{ username: c.username }}
                className="flex items-center gap-3 rounded-2xl bg-polaroid px-3 py-3"
              >
                <Avatar src={c.avatarUrl} name={c.displayName} />
                <span className="min-w-0 flex-1">
                  <span className="flex items-center justify-between gap-2">
                    <span className="truncate text-sm font-semibold">{c.displayName}</span>
                    <span className="text-[11px] text-ink-soft">{timeAgo(c.lastAt)}</span>
                  </span>
                  <span className="block truncate text-sm text-ink-soft">{c.lastBody}</span>
                </span>
                {c.unread > 0 ? (
                  <span className="grid min-w-6 place-items-center rounded-full bg-ruby px-1.5 text-[11px] text-cream tabular-nums">
                    {c.unread}
                  </span>
                ) : null}
              </Link>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
