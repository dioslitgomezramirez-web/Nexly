import { useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { RedirectToSignIn } from "@/lib/auth/gates";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { getMessages, sendMessage } from "@/lib/social/server";
import { Avatar } from "@/components/avatar";
import { cn } from "@/lib/utils";
import { queryClient } from "@/lib/query-client";

export const Route = createFileRoute("/_app/messages/$username")({
  component: ThreadPage,
});

function ThreadPage() {
  const { username } = Route.useParams();
  const { user, isPending } = useCurrentUserState();
  const [body, setBody] = useState("");
  const [busy, setBusy] = useState(false);
  const q = useQuery({
    queryKey: ["thread", username],
    queryFn: () => getMessages({ data: username }),
    enabled: Boolean(user),
  });

  if (isPending) return <div className="h-40" />;
  if (!user) return <RedirectToSignIn />;

  async function send(e: React.FormEvent) {
    e.preventDefault();
    if (!body.trim() || busy) return;
    setBusy(true);
    try {
      const msg = await sendMessage({ data: { username, body } });
      queryClient.setQueryData(["thread", username], (old: typeof q.data) => {
        if (!old) return old;
        return { ...old, messages: [...old.messages, msg] };
      });
      setBody("");
    } finally {
      setBusy(false);
    }
  }

  const peer = q.data?.peer;
  return (
    <div className="flex min-h-[calc(100dvh-8rem)] flex-col px-3 py-3">
      <header className="mb-3 flex items-center gap-2">
        {peer ? (
          <Link to="/u/$username" params={{ username: peer.username }} className="flex items-center gap-2">
            <Avatar src={peer.avatarUrl} name={peer.displayName} size="sm" />
            <span className="font-display text-lg">{peer.displayName}</span>
          </Link>
        ) : (
          <span className="font-display text-lg">@{username}</span>
        )}
      </header>
      <div className="nex-scroll flex min-h-0 flex-1 flex-col gap-2 overflow-y-auto pb-3">
        {(q.data?.messages ?? []).map((m) => (
          <div
            key={m.id}
            className={cn(
              "max-w-[80%] rounded-2xl px-3 py-2 text-sm leading-snug",
              m.mine
                ? "ml-auto bg-leather text-cream"
                : "bg-polaroid text-ink shadow-[0_4px_12px_-8px_rgba(26,18,12,0.4)]",
            )}
          >
            {m.body}
          </div>
        ))}
        {!q.isLoading && (q.data?.messages ?? []).length === 0 ? (
          <p className="py-10 text-center text-sm text-ink-soft">Escribe la primera línea.</p>
        ) : null}
      </div>
      <form className="flex gap-2" onSubmit={(e) => void send(e)}>
        <input
          className="nex-input flex-1"
          placeholder="Mensaje"
          value={body}
          onChange={(e) => setBody(e.target.value)}
        />
        <button type="submit" className="nex-btn px-4" disabled={busy}>
          Enviar
        </button>
      </form>
    </div>
  );
}
