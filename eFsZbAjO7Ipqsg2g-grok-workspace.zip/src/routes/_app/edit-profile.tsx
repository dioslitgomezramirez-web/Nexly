import { useEffect, useState } from "react";
import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { RedirectToSignIn } from "@/lib/auth/gates";
import { useCurrentUser, useCurrentUserState } from "@/lib/auth/use-current-user";
import { compressImage } from "@/lib/social/image";
import { getMyProfile, updateProfile } from "@/lib/social/server";
import { Avatar } from "@/components/avatar";
import { queryClient } from "@/lib/query-client";

export const Route = createFileRoute("/_app/edit-profile")({ component: EditProfilePage });

function EditProfilePage() {
  const { user, isPending } = useCurrentUserState();
  const live = useCurrentUser();
  const navigate = useNavigate();
  const q = useQuery({
    queryKey: ["me-profile"],
    queryFn: () => getMyProfile(),
    enabled: Boolean(user),
  });
  const [username, setUsername] = useState("");
  const [displayName, setDisplayName] = useState("");
  const [bio, setBio] = useState("");
  const [website, setWebsite] = useState("");
  const [avatarUrl, setAvatarUrl] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!q.data) return;
    setUsername(q.data.username);
    setDisplayName(q.data.displayName);
    setBio(q.data.bio);
    setWebsite(q.data.website ?? "");
    setAvatarUrl(q.data.avatarUrl);
  }, [q.data]);

  if (isPending) return <div className="h-40" />;
  if (!user) return <RedirectToSignIn />;

  async function save(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      await updateProfile({
        data: { username, displayName, bio, website, avatarUrl },
      });
      await queryClient.invalidateQueries({ queryKey: ["me-profile"] });
      await navigate({ to: "/u/$username", params: { username } });
    } catch (err) {
      setError(err instanceof Error ? err.message : "No se pudo guardar");
    } finally {
      setBusy(false);
    }
  }

  return (
    <form className="space-y-3 px-4 py-4" onSubmit={(e) => void save(e)}>
      <h1 className="font-display text-2xl">Editar perfil</h1>
      <div className="flex flex-col items-center gap-2 py-2">
        <Avatar src={avatarUrl ?? live?.profileImageUrl} name={displayName || "Tú"} size="xl" />
        <label className="nex-btn-ghost text-sm">
          Cambiar retrato
          <input
            type="file"
            accept="image/*"
            className="hidden"
            onChange={async (e) => {
              const file = e.target.files?.[0];
              if (!file) return;
              try {
                setAvatarUrl(await compressImage(file, 480));
              } catch (err) {
                setError(err instanceof Error ? err.message : "Foto no válida");
              }
            }}
          />
        </label>
      </div>
      <input className="nex-input" placeholder="Usuario" value={username} onChange={(e) => setUsername(e.target.value)} />
      <input className="nex-input" placeholder="Nombre" value={displayName} onChange={(e) => setDisplayName(e.target.value)} />
      <textarea className="nex-input min-h-24 py-3" placeholder="Bio" value={bio} onChange={(e) => setBio(e.target.value)} maxLength={160} />
      <input className="nex-input" placeholder="Sitio web" value={website} onChange={(e) => setWebsite(e.target.value)} />
      {error ? <p className="text-sm text-ruby">{error}</p> : null}
      <button type="submit" className="nex-btn w-full" disabled={busy}>
        {busy ? "Guardando…" : "Guardar"}
      </button>
    </form>
  );
}
