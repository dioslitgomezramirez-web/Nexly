import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { getComments, getPost } from "@/lib/social/server";
import { PostCard } from "@/components/post-card";
import { queryClient } from "@/lib/query-client";
import { useCurrentUser } from "@/lib/auth/use-current-user";

export const Route = createFileRoute("/_app/p/$postId")({ component: PostPage });

function PostPage() {
  const { postId } = Route.useParams();
  const id = Number(postId);
  const user = useCurrentUser();
  const post = useQuery({
    queryKey: ["post", id],
    queryFn: () => getPost({ data: id }),
  });
  const comments = useQuery({
    queryKey: ["comments", id],
    queryFn: () => getComments({ data: id }),
    enabled: Number.isFinite(id),
  });

  if (post.isLoading) {
    return <p className="py-16 text-center text-sm text-ink-soft">Revelando…</p>;
  }
  if (!post.data) {
    return <p className="py-16 text-center text-sm text-ink-soft">Esta foto ya no está.</p>;
  }

  return (
    <div className="px-3 py-4">
      <PostCard
        post={post.data}
        comments={comments.data}
        canDelete={Boolean(user) && !post.data.userId.startsWith("seed:") && user?.id === post.data.userId}
        onChange={(next) => {
          if (next.id < 0) {
            queryClient.setQueryData(["post", id], null);
            return;
          }
          queryClient.setQueryData(["post", id], next);
          void comments.refetch();
        }}
      />
    </div>
  );
}
