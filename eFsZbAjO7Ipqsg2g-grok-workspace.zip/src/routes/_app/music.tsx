import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { Play, Search } from "lucide-react";
import { listTopMusic, searchMusic } from "@/lib/social/itunes";
import { usePlayer } from "@/lib/social/player";

export const Route = createFileRoute("/_app/music")({ component: MusicPage });

function MusicPage() {
  const [q, setQ] = useState("");
  const chart = useQuery({ queryKey: ["itunes-top"], queryFn: () => listTopMusic() });
  const search = useQuery({
    queryKey: ["itunes", q],
    queryFn: () => searchMusic({ data: q }),
    enabled: q.trim().length >= 2,
  });
  const play = usePlayer((s) => s.play);
  const tracks = q.trim().length >= 2 ? (search.data ?? []) : (chart.data ?? []);

  return (
    <div className="px-3 py-3">
      <h1 className="font-display text-2xl">Tocadiscos</h1>
      <p className="mb-3 text-sm text-ink-soft">Preescuchas de 30 s desde iTunes Store. Datos reales de Apple.</p>
      <label className="relative mb-4 block">
        <Search className="absolute left-3 top-1/2 size-4 -translate-y-1/2 text-ink-soft" />
        <input
          className="nex-input pl-10"
          placeholder="Buscar en iTunes"
          value={q}
          onChange={(e) => setQ(e.target.value)}
        />
      </label>
      <ul className="space-y-2">
        {tracks.map((t, i) => (
          <li key={t.trackId}>
            <button
              type="button"
              className="flex w-full items-center gap-3 rounded-2xl bg-polaroid px-3 py-2 text-left shadow-[0_6px_16px_-10px_rgba(26,18,12,0.4)]"
              onClick={() => play(t)}
            >
              <span className="w-6 text-center font-display text-brass-deep tabular-nums">{i + 1}</span>
              {t.artworkUrl ? (
                <img src={t.artworkUrl} alt="" className="size-12 rounded-md object-cover" />
              ) : (
                <span className="nex-vinyl" />
              )}
              <span className="min-w-0 flex-1">
                <span className="block truncate text-sm font-semibold">{t.name}</span>
                <span className="block truncate text-xs text-ink-soft">{t.artist}</span>
              </span>
              <Play className="size-4 text-brass-deep" />
            </button>
          </li>
        ))}
      </ul>
      {chart.isFetching || search.isFetching ? (
        <p className="py-8 text-center text-sm text-ink-soft">Consultando iTunes…</p>
      ) : null}
    </div>
  );
}
