import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { Bookmark, Send } from "lucide-react";
import { UserButton } from "@/lib/auth/gates";
import { useCurrentUser } from "@/lib/auth/use-current-user";
import { getProfile, toggleFollow } from "@/lib/social/server";
import { Avatar } from "@/components/avatar";
import { PostGrid } from "@/components/post-card";
import { formatCount, isUnauthorized } from "@/lib/utils";
import { queryClient } from "@/lib/query-client";

export const Route = createFileRoute("/_app/u/$username")({ component: ProfilePage });

function ProfilePage() {
  const { username } = Route.useParams();
  const user = useCurrentUser();
  const navigate = useNavigate();
  const q = useQuery({
    queryKey: ["profile", username],
    queryFn: () => getProfile({ data: username }),
  });

  const data = q.data;
  if (q.isLoading) {
    return <p className="py-16 text-center text-sm text-ink-soft">Abriendo el álbum…</p>;
  }
  if (!data) {
    return <p className="py-16 text-center text-sm text-ink-soft">No existe @{username}.</p>;
  }
  const { profile, posts } = data;

  async function follow() {
    try {
      const res = await toggleFollow({ data: profile.userId });
      queryClient.setQueryData(["profile", username], {
        ...data,
        profile: {
          ...profile,
          isFollowing: res.following,
          followersCount: profile.followersCount + (res.following ? 1 : -1),
        },
      });
    } catch (err) {
      if (isUnauthorized(err)) void navigate({ to: "/login" });
    }
  }

  return (
    <div className="pb-6">
      <div className="nex-leather px-4 pb-5 pt-4 text-cream">
        <div className="flex items-start gap-4">
          <Avatar src={profile.avatarUrl} name={profile.displayName} size="xl" className="size-20" />
          <div className="min-w-0 flex-1">
            <h1 className="font-display text-2xl text-cream">{profile.displayName}</h1>
            <p className="text-sm text-brass">@{profile.username}</p>
            <div className="mt-3 flex gap-4 text-center text-sm">
              <Stat n={profile.postsCount} label="fotos" />
              <Stat n={profile.followersCount} label="seguidores" />
              <Stat n={profile.followingCount} label="siguiendo" />
            </div>
          </div>
        </div>
        {profile.bio ? <p className="mt-3 text-sm leading-snug text-cream/90">{profile.bio}</p> : null}
        {profile.website ? (
          <a href={profile.website} className="mt-1 inline-block text-sm text-brass underline-offset-2 hover:underline">
            {profile.website}
          </a>
        ) : null}
        <div className="mt-4 flex flex-wrap gap-2">
          {profile.isMe ? (
            <>
              <Link to="/edit-profile" className="nex-btn-brass flex-1">
                Editar perfil
              </Link>
              <Link to="/saved" className="nex-btn-ghost text-ink">
                <Bookmark className="size-4" />
              </Link>
              <div className="nex-btn-ghost text-ink [&_button]:text-ink [&_span]:text-ink">
                <UserButton />
              </div>
            </>
          ) : (
            <>
              <button type="button" className={profile.isFollowing ? "nex-btn-ghost flex-1 text-ink" : "nex-btn flex-1"} onClick={() => void follow()}>
                {profile.isFollowing ? "Siguiendo" : "Seguir"}
              </button>
              {user ? (
                <Link
                  to="/messages/$username"
                  params={{ username: profile.username }}
                  className="nex-btn-brass"
                >
                  <Send className="size-4" />
                </Link>
              ) : (
                <Link to="/login" className="nex-btn-brass">
                  <Send className="size-4" />
                </Link>
              )}
            </>
          )}
        </div>
      </div>
      <PostGrid posts={posts} />
    </div>
  );
}

function Stat({ n, label }: { n: number; label: string }) {
  return (
    <div>
      <div className="font-display text-lg tabular-nums">{formatCount(n)}</div>
      <div className="text-[11px] uppercase tracking-wide text-brass">{label}</div>
    </div>
  );
}
