import { useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { Search } from "lucide-react";
import { searchAll } from "@/lib/social/server";
import { Avatar } from "@/components/avatar";
import { PostGrid } from "@/components/post-card";

export const Route = createFileRoute("/_app/search")({ component: SearchPage });

function SearchPage() {
  const [q, setQ] = useState("");
  const result = useQuery({
    queryKey: ["search", q],
    queryFn: () => searchAll({ data: q }),
    enabled: q.trim().length >= 1,
  });

  return (
    <div className="px-3 py-3">
      <label className="relative block">
        <Search className="absolute left-3 top-1/2 size-4 -translate-y-1/2 text-ink-soft" />
        <input
          className="nex-input pl-10"
          placeholder="Personas, lugares, pies de foto"
          value={q}
          onChange={(e) => setQ(e.target.value)}
          autoFocus
        />
      </label>

      {result.data ? (
        <div className="mt-4 space-y-6">
          <section>
            <h2 className="mb-2 font-display text-lg">Personas</h2>
            {result.data.people.length === 0 ? (
              <p className="text-sm text-ink-soft">Nadie con ese nombre.</p>
            ) : (
              <ul className="space-y-2">
                {result.data.people.map((p) => (
                  <li key={p.userId}>
                    <Link
                      to="/u/$username"
                      params={{ username: p.username }}
                      className="flex items-center gap-3 rounded-2xl bg-polaroid px-3 py-2"
                    >
                      <Avatar src={p.avatarUrl} name={p.displayName} />
                      <span>
                        <span className="block text-sm font-semibold">{p.username}</span>
                        <span className="block text-xs text-ink-soft">{p.displayName}</span>
                      </span>
                    </Link>
                  </li>
                ))}
              </ul>
            )}
          </section>
          <section>
            <h2 className="mb-2 font-display text-lg">Publicaciones</h2>
            <PostGrid posts={result.data.posts} />
          </section>
        </div>
      ) : (
        <p className="px-2 py-12 text-center text-sm text-ink-soft">
          Busca un usuario, un lugar o una frase del pie de foto.
        </p>
      )}
    </div>
  );
}
