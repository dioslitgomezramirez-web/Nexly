import { useEffect } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { RedirectToSignIn } from "@/lib/auth/gates";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { getNotifications, markNotificationsRead } from "@/lib/social/server";
import { Avatar } from "@/components/avatar";
import { timeAgo } from "@/lib/utils";

export const Route = createFileRoute("/_app/notifications")({ component: NotificationsPage });

function NotificationsPage() {
  const { user, isPending } = useCurrentUserState();
  const q = useQuery({
    queryKey: ["notifications"],
    queryFn: () => getNotifications(),
    enabled: Boolean(user),
  });

  useEffect(() => {
    if (user) void markNotificationsRead();
  }, [user]);

  if (isPending) return <div className="h-40" />;
  if (!user) return <RedirectToSignIn />;

  const items = q.data ?? [];
  return (
    <div className="px-3 py-3">
      <h1 className="font-display text-2xl">Avisos</h1>
      {q.isLoading ? (
        <p className="py-12 text-center text-sm text-ink-soft">Cargando…</p>
      ) : items.length === 0 ? (
        <p className="py-12 text-center text-sm text-ink-soft">
          Aquí aparecerán me gusta, comentarios y seguidores.
        </p>
      ) : (
        <ul className="mt-3 space-y-2">
          {items.map((n) => (
            <li key={n.id}>
              {n.postId ? (
                <Link
                  to="/p/$postId"
                  params={{ postId: String(n.postId) }}
                  className="flex items-center gap-3 rounded-2xl bg-polaroid px-3 py-3"
                >
                  <Avatar src={n.actor.avatarUrl} name={n.actor.displayName} />
                  <span className="min-w-0 flex-1 text-sm">
                    <span className="font-semibold">{n.actor.username}</span> {labelFor(n.type)}
                    <span className="mt-0.5 block text-xs text-ink-soft">{timeAgo(n.createdAt)}</span>
                  </span>
                </Link>
              ) : (
                <Link
                  to="/u/$username"
                  params={{ username: n.actor.username }}
                  className="flex items-center gap-3 rounded-2xl bg-polaroid px-3 py-3"
                >
                  <Avatar src={n.actor.avatarUrl} name={n.actor.displayName} />
                  <span className="min-w-0 flex-1 text-sm">
                    <span className="font-semibold">{n.actor.username}</span> {labelFor(n.type)}
                    <span className="mt-0.5 block text-xs text-ink-soft">{timeAgo(n.createdAt)}</span>
                  </span>
                </Link>
              )}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

function labelFor(type: string) {
  if (type === "like") return "le dio me gusta a tu foto.";
  if (type === "comment") return "comentó tu foto.";
  if (type === "follow") return "empezó a seguirte.";
  return "interactuó contigo.";
}
