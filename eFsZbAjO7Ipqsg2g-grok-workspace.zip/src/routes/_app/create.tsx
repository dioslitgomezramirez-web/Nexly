import { useState } from "react";
import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { Camera, ImagePlus } from "lucide-react";
import { RedirectToSignIn } from "@/lib/auth/gates";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { compressImage } from "@/lib/social/image";
import { createPost, createStory } from "@/lib/social/server";
import { MusicPicker } from "@/components/music-picker";
import type { MusicTrack } from "@/lib/social/types";
import { cn } from "@/lib/utils";
import { queryClient } from "@/lib/query-client";

export const Route = createFileRoute("/_app/create")({ component: CreatePage });

function CreatePage() {
  const { user, isPending } = useCurrentUserState();
  const navigate = useNavigate();
  const [mode, setMode] = useState<"post" | "story">("post");
  const [preview, setPreview] = useState<string | null>(null);
  const [caption, setCaption] = useState("");
  const [location, setLocation] = useState("");
  const [music, setMusic] = useState<MusicTrack | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (isPending) return <div className="h-40" />;
  if (!user) return <RedirectToSignIn />;

  async function onFile(file: File | undefined) {
    if (!file) return;
    setError(null);
    try {
      setPreview(await compressImage(file));
    } catch (err) {
      setError(err instanceof Error ? err.message : "No se pudo leer la foto");
    }
  }

  async function publish() {
    if (!preview) {
      setError("Elige una foto");
      return;
    }
    setBusy(true);
    setError(null);
    try {
      if (mode === "story") {
        await createStory({ data: preview });
        await queryClient.invalidateQueries({ queryKey: ["stories"] });
        await navigate({ to: "/" });
      } else {
        const { id } = await createPost({
          data: { imageUrl: preview, caption, location, music },
        });
        await queryClient.invalidateQueries({ queryKey: ["feed"] });
        await navigate({ to: "/p/$postId", params: { postId: String(id) } });
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "No se pudo publicar");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="px-4 py-4">
      <h1 className="font-display text-2xl">Nueva placa</h1>
      <div className="mt-3 grid grid-cols-2 gap-1 rounded-xl bg-walnut/10 p-1">
        <button
          type="button"
          className={cn("rounded-lg py-2 text-sm", mode === "post" && "nex-btn-brass")}
          onClick={() => setMode("post")}
        >
          Publicación
        </button>
        <button
          type="button"
          className={cn("rounded-lg py-2 text-sm", mode === "story" && "nex-btn-brass")}
          onClick={() => setMode("story")}
        >
          Historia
        </button>
      </div>

      <div className="nex-polaroid mx-auto mt-4 max-w-sm">
        {preview ? (
          <img src={preview} alt="" className="nex-polaroid-photo" />
        ) : (
          <label className="nex-polaroid-photo grid cursor-pointer place-items-center text-ink-soft">
            <span className="flex flex-col items-center gap-2">
              <ImagePlus className="size-8" />
              <span className="text-sm">Toca para elegir foto</span>
            </span>
            <input
              type="file"
              accept="image/*"
              className="hidden"
              onChange={(e) => void onFile(e.target.files?.[0])}
            />
          </label>
        )}
      </div>

      <div className="mt-3 flex gap-2">
        <label className="nex-btn-ghost flex-1">
          <ImagePlus className="size-4" />
          Galería
          <input type="file" accept="image/*" className="hidden" onChange={(e) => void onFile(e.target.files?.[0])} />
        </label>
        <label className="nex-btn-ghost flex-1">
          <Camera className="size-4" />
          Cámara
          <input
            type="file"
            accept="image/*"
            capture="environment"
            className="hidden"
            onChange={(e) => void onFile(e.target.files?.[0])}
          />
        </label>
      </div>

      {mode === "post" ? (
        <div className="mt-4 space-y-3">
          <textarea
            className="nex-input min-h-24 py-3"
            placeholder="Escribe un pie de foto…"
            value={caption}
            onChange={(e) => setCaption(e.target.value)}
            maxLength={500}
          />
          <input
            className="nex-input"
            placeholder="Lugar"
            value={location}
            onChange={(e) => setLocation(e.target.value)}
          />
          <MusicPicker value={music} onChange={setMusic} />
        </div>
      ) : (
        <p className="mt-4 text-sm text-ink-soft">Las historias se apagan a las 24 horas.</p>
      )}

      {error ? <p className="mt-3 text-sm text-ruby">{error}</p> : null}
      <button type="button" className="nex-btn mt-4 w-full" disabled={busy} onClick={() => void publish()}>
        {busy ? "Revelando…" : mode === "story" ? "Subir historia" : "Publicar"}
      </button>
    </div>
  );
}
