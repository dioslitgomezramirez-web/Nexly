import { useState } from "react";
import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useCurrentUser } from "@/lib/auth/use-current-user";
import { createStory, getComments, getFeed, getStories } from "@/lib/social/server";
import { compressImage } from "@/lib/social/image";
import { PostCard } from "@/components/post-card";
import { StoriesRail } from "@/components/stories";
import type { Post } from "@/lib/social/types";
import { cn, isUnauthorized } from "@/lib/utils";
import { queryClient } from "@/lib/query-client";

export const Route = createFileRoute("/_app/")({ component: FeedPage });

function FeedPage() {
  const [tab, setTab] = useState<"foryou" | "following">("foryou");
  const [openId, setOpenId] = useState<number | null>(null);
  const user = useCurrentUser();
  const navigate = useNavigate();

  const feed = useQuery({
    queryKey: ["feed", tab],
    queryFn: () => getFeed({ data: { tab } }),
  });
  const stories = useQuery({ queryKey: ["stories"], queryFn: () => getStories() });
  const comments = useQuery({
    queryKey: ["comments", openId],
    queryFn: () => getComments({ data: openId! }),
    enabled: openId != null,
  });

  function patch(next: Post) {
    queryClient.setQueryData<Post[]>(["feed", tab], (old) => {
      if (!old) return old;
      if (next.id < 0) return old.filter((p) => p.id !== -next.id);
      return old.map((p) => (p.id === next.id ? next : p));
    });
  }

  async function addStory() {
    if (!user) {
      void navigate({ to: "/login" });
      return;
    }
    const input = document.createElement("input");
    input.type = "file";
    input.accept = "image/*";
    input.capture = "environment";
    input.onchange = async () => {
      const file = input.files?.[0];
      if (!file) return;
      try {
        const url = await compressImage(file, 1080);
        await createStory({ data: url });
        await stories.refetch();
      } catch (err) {
        if (isUnauthorized(err)) void navigate({ to: "/login" });
        else window.alert(err instanceof Error ? err.message : "No se pudo publicar");
      }
    };
    input.click();
  }

  return (
    <div className="px-3 pb-6 pt-3">
      <div className="mb-3 grid grid-cols-2 gap-1 rounded-xl bg-walnut/10 p-1">
        {(
          [
            ["foryou", "Para ti"],
            ["following", "Siguiendo"],
          ] as const
        ).map(([id, label]) => (
          <button
            key={id}
            type="button"
            className={cn("rounded-lg py-2 text-sm font-medium", tab === id && "nex-btn-brass")}
            onClick={() => setTab(id)}
          >
            {label}
          </button>
        ))}
      </div>

      <StoriesRail groups={stories.data ?? []} meUsername={user?.displayName} onAdd={() => void addStory()} />

      {feed.isLoading ? (
        <LoadingReel />
      ) : feed.isError ? (
        <p className="px-2 py-10 text-center text-sm text-ruby">No se pudo revelar el carrete.</p>
      ) : (feed.data ?? []).length === 0 ? (
        <p className="px-4 py-12 text-center text-sm text-ink-soft">
          {tab === "following"
            ? "Sigue a alguien para llenar esta bandeja."
            : "Aún no hay publicaciones."}
        </p>
      ) : (
        <div className="mt-4 space-y-6">
          {(feed.data ?? []).map((post) => (
            <PostCard
              key={post.id}
              post={post}
              featured
              comments={openId === post.id ? comments.data : undefined}
              onChange={patch}
              onOpenComments={() => setOpenId(post.id)}
            />
          ))}
        </div>
      )}
    </div>
  );
}

function LoadingReel() {
  return (
    <div className="flex flex-col items-center gap-3 py-16">
      <span className="nex-vinyl spin size-14" />
      <p className="font-display text-lg text-ink-soft">Revelando el carrete…</p>
    </div>
  );
}
