import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { getExplore } from "@/lib/social/server";
import { PostGrid } from "@/components/post-card";

export const Route = createFileRoute("/_app/explore")({ component: ExplorePage });

function ExplorePage() {
  const q = useQuery({ queryKey: ["explore"], queryFn: () => getExplore() });
  return (
    <div className="pb-4">
      <header className="px-4 py-3">
        <h1 className="font-display text-2xl">Explorar</h1>
        <p className="text-sm text-ink-soft">Lo más mirado del carrete.</p>
      </header>
      {q.isLoading ? (
        <p className="py-16 text-center text-sm text-ink-soft">Buscando luz…</p>
      ) : (
        <PostGrid posts={q.data ?? []} />
      )}
    </div>
  );
}
