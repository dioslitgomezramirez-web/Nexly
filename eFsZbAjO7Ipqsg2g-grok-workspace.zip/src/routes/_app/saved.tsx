import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { RedirectToSignIn } from "@/lib/auth/gates";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { getSaved } from "@/lib/social/server";
import { PostGrid } from "@/components/post-card";

export const Route = createFileRoute("/_app/saved")({ component: SavedPage });

function SavedPage() {
  const { user, isPending } = useCurrentUserState();
  const q = useQuery({
    queryKey: ["saved"],
    queryFn: () => getSaved(),
    enabled: Boolean(user),
  });
  if (isPending) return <div className="h-40" />;
  if (!user) return <RedirectToSignIn />;
  return (
    <div className="pb-4">
      <header className="px-4 py-3">
        <h1 className="font-display text-2xl">Guardadas</h1>
      </header>
      <PostGrid posts={q.data ?? []} />
      {!q.isLoading && (q.data ?? []).length === 0 ? (
        <p className="px-4 py-12 text-center text-sm text-ink-soft">
          Marca el marcapáginas en una foto para encontrarla aquí.
        </p>
      ) : null}
    </div>
  );
}
