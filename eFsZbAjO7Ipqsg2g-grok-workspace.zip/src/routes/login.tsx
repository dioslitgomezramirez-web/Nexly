import { useEffect, useState } from "react";
import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { GROK_PROVIDERS, authClient, authEnabled, signIn } from "@/lib/auth/client";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { bootstrapMe } from "@/lib/social/server";

export const Route = createFileRoute("/login")({ component: Login });

function Login() {
  const navigate = useNavigate();
  const { user, isPending } = useCurrentUserState();
  const [mode, setMode] = useState<"in" | "up">("in");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (!isPending && user) void navigate({ to: "/" });
  }, [isPending, user, navigate]);

  async function onEmail(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setBusy(true);
    try {
      if (mode === "up") {
        const { error: err } = await authClient.signUp.email({
          email,
          password,
          name: name.trim() || email.split("@")[0] || "Nexly",
        });
        if (err) throw new Error(err.message || "No se pudo crear la cuenta");
      } else {
        const { error: err } = await authClient.signIn.email({ email, password });
        if (err) throw new Error(err.message || "No se pudo entrar");
      }
      await bootstrapMe({
        data: { name: name || null, email, image: null },
      }).catch(() => undefined);
      await navigate({ to: "/" });
    } catch (err) {
      setError(err instanceof Error ? err.message : "Algo falló");
    } finally {
      setBusy(false);
    }
  }

  return (
    <main className="nex-leather relative min-h-dvh overflow-hidden px-5 py-10">
      <div className="nex-grain pointer-events-none absolute inset-0" />
      <div className="relative mx-auto flex min-h-[calc(100dvh-5rem)] w-full max-w-sm flex-col justify-center">
        <div className="mb-8 text-center">
          <span className="nex-lens mx-auto mb-4">
            <span className="nex-lens-inner" />
          </span>
          <h1 className="nex-emboss font-display text-5xl tracking-tight">Nexly</h1>
          <p className="mt-2 text-sm text-cream/80">La red social que se siente en las manos.</p>
        </div>

        <div className="nex-linen rounded-3xl p-5 shadow-[0_24px_50px_-18px_rgba(0,0,0,0.55)]">
          {authEnabled ? (
            <>
              <div className="mb-4 grid grid-cols-2 gap-1 rounded-xl bg-walnut/10 p-1">
                <button
                  type="button"
                  className={mode === "in" ? "nex-btn-brass rounded-lg py-2 text-sm" : "rounded-lg py-2 text-sm"}
                  onClick={() => setMode("in")}
                >
                  Entrar
                </button>
                <button
                  type="button"
                  className={mode === "up" ? "nex-btn-brass rounded-lg py-2 text-sm" : "rounded-lg py-2 text-sm"}
                  onClick={() => setMode("up")}
                >
                  Crear cuenta
                </button>
              </div>

              <form className="space-y-3" onSubmit={onEmail}>
                {mode === "up" ? (
                  <input
                    className="nex-input"
                    placeholder="Nombre"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    autoComplete="name"
                  />
                ) : null}
                <input
                  className="nex-input"
                  placeholder="Correo"
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  autoComplete="email"
                />
                <input
                  className="nex-input"
                  placeholder="Contraseña (mín. 8)"
                  type="password"
                  required
                  minLength={8}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  autoComplete={mode === "up" ? "new-password" : "current-password"}
                />
                {error ? <p className="text-sm text-ruby">{error}</p> : null}
                <button type="submit" className="nex-btn w-full" disabled={busy}>
                  {busy ? "Revelando…" : mode === "up" ? "Unirme a Nexly" : "Abrir el carrete"}
                </button>
              </form>

              <p className="my-4 text-center text-xs tracking-wide text-ink-soft">o continúa con</p>
              <div className="space-y-2">
                {GROK_PROVIDERS.map((p) => (
                  <button
                    key={p.providerId}
                    type="button"
                    className="nex-btn-ghost w-full"
                    onClick={() => signIn(p.providerId, { callbackURL: "/" })}
                  >
                    Continuar con {p.label}
                  </button>
                ))}
              </div>
            </>
          ) : (
            <p className="text-sm text-ink-soft">El acceso está desactivado.</p>
          )}
        </div>

        <Link to="/" className="mt-6 text-center text-sm text-brass">
          Seguir como invitado
        </Link>
      </div>
    </main>
  );
}
