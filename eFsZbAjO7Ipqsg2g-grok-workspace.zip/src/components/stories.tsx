import { useState } from "react";
import { Plus, X } from "lucide-react";
import { Link } from "@tanstack/react-router";
import type { StoryGroup } from "@/lib/social/types";
import { Avatar } from "./avatar";
import { cn } from "@/lib/utils";

export function StoriesRail({
  groups,
  meUsername,
  onAdd,
}: {
  groups: StoryGroup[];
  meUsername?: string | null;
  onAdd?: () => void;
}) {
  const [open, setOpen] = useState<StoryGroup | null>(null);
  const [idx, setIdx] = useState(0);

  return (
    <>
      <div className="nex-scroll flex gap-3 overflow-x-auto px-1 pb-2 pt-1">
        <button
          type="button"
          onClick={onAdd}
          className="flex w-16 shrink-0 flex-col items-center gap-1.5"
        >
          <span className="relative">
            <span className="nex-story-ring block">
              <Avatar name={meUsername ?? "Tú"} size="md" className="size-14" />
            </span>
            <span className="absolute -bottom-0.5 -right-0.5 grid size-5 place-items-center rounded-full bg-ruby text-cream shadow-md">
              <Plus className="size-3" />
            </span>
          </span>
          <span className="w-16 truncate text-center text-[11px] font-medium text-ink-soft">
            Tu historia
          </span>
        </button>
        {groups.map((g) => (
          <button
            key={g.userId}
            type="button"
            className="flex w-16 shrink-0 flex-col items-center gap-1.5"
            onClick={() => {
              setOpen(g);
              setIdx(0);
            }}
          >
            <span className="nex-story-ring">
              <Avatar src={g.avatarUrl} name={g.displayName} size="md" className="size-14" />
            </span>
            <span className="w-16 truncate text-center text-[11px] font-medium text-ink-soft">
              {g.username}
            </span>
          </button>
        ))}
      </div>

      {open ? (
        <div className="fixed inset-0 z-50 flex flex-col bg-walnut">
          <div className="flex gap-1 px-3 pt-3">
            {open.items.map((item, i) => (
              <span
                key={item.id}
                className={cn(
                  "h-1 flex-1 rounded-full",
                  i <= idx ? "bg-brass" : "bg-cream/20",
                )}
              />
            ))}
          </div>
          <div className="flex items-center justify-between px-3 py-2">
            <Link
              to="/u/$username"
              params={{ username: open.username }}
              className="flex items-center gap-2 text-cream"
              onClick={() => setOpen(null)}
            >
              <Avatar src={open.avatarUrl} name={open.displayName} size="sm" />
              <span className="font-medium">{open.username}</span>
            </Link>
            <button
              type="button"
              className="grid size-11 place-items-center text-cream"
              onClick={() => setOpen(null)}
              aria-label="Cerrar historia"
            >
              <X className="size-5" />
            </button>
          </div>
          <button
            type="button"
            className="relative min-h-0 flex-1"
            onClick={() => {
              if (idx + 1 < open.items.length) setIdx(idx + 1);
              else setOpen(null);
            }}
          >
            <img
              src={open.items[idx]?.imageUrl}
              alt=""
              className="absolute inset-0 size-full object-contain"
            />
          </button>
        </div>
      ) : null}
    </>
  );
}
