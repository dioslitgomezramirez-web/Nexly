import { useEffect, useRef } from "react";
import { Pause, Play, X } from "lucide-react";
import { resolvePreview } from "@/lib/social/itunes";
import { usePlayer } from "@/lib/social/player";
import { cn } from "@/lib/utils";

export function AudioDock() {
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const { track, playing, pause, toggle, stop } = usePlayer();

  useEffect(() => {
    const el = audioRef.current;
    if (!el) return;
    if (!track) {
      el.pause();
      el.removeAttribute("src");
      return;
    }
    let cancelled = false;
    async function attach() {
      if (!track) return;
      let src = track.previewUrl;
      if (!src) {
        src = await resolvePreview({ data: { name: track.name, artist: track.artist } });
      }
      if (cancelled || !src || !el) return;
      if (el.src !== src) el.src = src;
      if (playing) {
        try {
          await el.play();
        } catch {
          pause();
        }
      } else {
        el.pause();
      }
    }
    void attach();
    return () => {
      cancelled = true;
    };
  }, [track, playing, pause]);

  return (
    <>
      <audio
        ref={audioRef}
        onEnded={() => pause()}
        onError={() => pause()}
      />
      {track ? (
        <div className="pointer-events-none fixed inset-x-0 bottom-[5.75rem] z-40 flex justify-center px-3 md:bottom-24">
          <div
            className={cn(
              "pointer-events-auto flex w-full max-w-md items-center gap-3 rounded-2xl px-3 py-2",
              "nex-leather text-cream shadow-[0_10px_30px_-12px_rgba(0,0,0,0.6)]",
            )}
          >
            <span className={cn("nex-vinyl shrink-0", playing && "spin")} />
            {track.artworkUrl ? (
              <img
                src={track.artworkUrl}
                alt=""
                className="size-10 rounded-md object-cover"
              />
            ) : null}
            <div className="min-w-0 flex-1">
              <p className="truncate font-display text-sm text-cream">{track.name}</p>
              <p className="truncate text-xs text-brass">{track.artist} · iTunes</p>
            </div>
            <button
              type="button"
              className="nex-btn-brass grid size-11 place-items-center rounded-full"
              onClick={() => toggle()}
              aria-label={playing ? "Pausar" : "Reproducir"}
            >
              {playing ? <Pause className="size-4" /> : <Play className="size-4 ml-0.5" />}
            </button>
            <button
              type="button"
              className="grid size-11 place-items-center text-cream/80"
              onClick={() => stop()}
              aria-label="Cerrar reproductor"
            >
              <X className="size-4" />
            </button>
          </div>
        </div>
      ) : null}
    </>
  );
}
