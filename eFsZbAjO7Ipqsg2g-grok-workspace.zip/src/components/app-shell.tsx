import { useEffect, type ReactNode } from "react";
import { Link, useRouterState } from "@tanstack/react-router";
import { Bell, Compass, Home, Music2, Search, Send, UserRound } from "lucide-react";
import { useCurrentUser, useCurrentUserState } from "@/lib/auth/use-current-user";
import { bootstrapMe, getMyProfile } from "@/lib/social/server";
import { useQuery } from "@tanstack/react-query";
import { cn } from "@/lib/utils";
import { AudioDock } from "./audio-dock";
import { Avatar } from "./avatar";

export function AppShell({ children }: { children: ReactNode }) {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const { user, isPending } = useCurrentUserState();

  useEffect(() => {
    if (!user) return;
    void bootstrapMe({
      data: {
        name: user.displayName,
        email: user.primaryEmail,
        image: user.profileImageUrl,
      },
    }).catch(() => undefined);
  }, [user]);

  return (
    <div className="nex-linen relative mx-auto flex min-h-dvh max-w-lg flex-col">
      <header className="nex-leather sticky top-0 z-30 px-3 pb-2 pt-[max(0.5rem,env(safe-area-inset-top))]">
        <div className="flex items-center gap-2">
          <Link to="/" className="flex items-center gap-2">
            <span className="nex-lens" aria-hidden>
              <span className="nex-lens-inner" />
            </span>
            <span className="nex-emboss font-display text-2xl tracking-tight">Nexly</span>
          </Link>
          <div className="ml-auto flex items-center">
            <Link to="/search" className="grid size-11 place-items-center text-cream" aria-label="Buscar">
              <Search className="size-5" />
            </Link>
            <Link to="/music" className="grid size-11 place-items-center text-cream" aria-label="Música">
              <Music2 className="size-5" />
            </Link>
            <Link to="/notifications" className="grid size-11 place-items-center text-cream" aria-label="Avisos">
              <Bell className="size-5" />
            </Link>
          </div>
        </div>
      </header>

      <main className="min-h-0 flex-1 pb-24">{children}</main>

      <nav className="nex-metal fixed inset-x-0 bottom-0 z-30 mx-auto flex max-w-lg items-end justify-around px-2 pb-[max(0.4rem,env(safe-area-inset-bottom))] pt-1">
        <NavIcon to="/" icon={Home} label="Inicio" active={pathname === "/"} />
        <NavIcon to="/explore" icon={Compass} label="Explorar" active={pathname.startsWith("/explore")} />
        <Link to="/create" className="nex-shutter" aria-label="Publicar">
          <span className="size-5 rounded-full border-2 border-cream/80" />
        </Link>
        <NavIcon to="/messages" icon={Send} label="Mensajes" active={pathname.startsWith("/messages")} />
        <ProfileTab active={pathname.startsWith("/u/") || pathname === "/edit-profile"} isPending={isPending} />
      </nav>

      <AudioDock />
    </div>
  );
}

function NavIcon({
  to,
  icon: Icon,
  label,
  active,
}: {
  to: string;
  icon: typeof Home;
  label: string;
  active: boolean;
}) {
  return (
    <Link to={to} className={cn("nex-dock-item", active && "is-active")} aria-label={label} aria-current={active ? "page" : undefined}>
      <Icon className="size-6" strokeWidth={active ? 2.4 : 1.8} />
    </Link>
  );
}

function ProfileTab({ active, isPending }: { active: boolean; isPending: boolean }) {
  const user = useCurrentUser();
  const me = useQuery({
    queryKey: ["me-profile"],
    queryFn: () => getMyProfile(),
    enabled: Boolean(user),
  });
  if (isPending) {
    return <span className="nex-dock-item"><span className="size-7 rounded-full bg-cream/20" /></span>;
  }
  if (!user) {
    return (
      <Link to="/login" className={cn("nex-dock-item", active && "is-active")} aria-label="Entrar">
        <UserRound className="size-6" />
      </Link>
    );
  }
  const username = me.data?.username;
  if (!username) {
    return (
      <Link to="/edit-profile" className={cn("nex-dock-item", active && "is-active")} aria-label="Perfil">
        <Avatar src={user.profileImageUrl} name={user.displayName ?? "Tú"} size="sm" className="size-7" />
      </Link>
    );
  }
  return (
    <Link
      to="/u/$username"
      params={{ username }}
      className={cn("nex-dock-item", active && "is-active")}
      aria-label="Perfil"
    >
      <Avatar src={me.data?.avatarUrl ?? user.profileImageUrl} name={me.data?.displayName ?? "Tú"} size="sm" className="size-7" />
    </Link>
  );
}
