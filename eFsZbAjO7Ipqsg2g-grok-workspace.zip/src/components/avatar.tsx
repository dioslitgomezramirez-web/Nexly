import { cn } from "@/lib/utils";

export function Avatar({
  src,
  name,
  size = "md",
  className,
}: {
  src?: string | null;
  name: string;
  size?: "sm" | "md" | "lg" | "xl";
  className?: string;
}) {
  const dim =
    size === "sm"
      ? "size-8 text-xs"
      : size === "lg"
        ? "size-16 text-xl"
        : size === "xl"
          ? "size-24 text-3xl"
          : "size-11 text-sm";
  const initial = (name.trim()[0] || "N").toUpperCase();
  return (
    <span
      className={cn(
        "relative inline-grid shrink-0 place-items-center overflow-hidden rounded-full",
        "bg-gradient-to-b from-brass to-brass-deep text-walnut font-display font-semibold",
        "shadow-[inset_0_1px_0_rgba(255,255,230,0.45),0_2px_4px_rgba(26,18,12,0.35)]",
        dim,
        className,
      )}
    >
      {src ? (
        <img src={src} alt="" className="size-full object-cover" />
      ) : (
        <span aria-hidden>{initial}</span>
      )}
    </span>
  );
}
