import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Music2, Search, X } from "lucide-react";
import { listTopMusic, searchMusic } from "@/lib/social/itunes";
import { usePlayer } from "@/lib/social/player";
import type { MusicTrack } from "@/lib/social/types";
import { cn } from "@/lib/utils";

export function MusicPicker({
  value,
  onChange,
}: {
  value: MusicTrack | null;
  onChange: (track: MusicTrack | null) => void;
}) {
  const [q, setQ] = useState("");
  const [open, setOpen] = useState(false);
  const chart = useQuery({ queryKey: ["itunes-top"], queryFn: () => listTopMusic() });
  const search = useQuery({
    queryKey: ["itunes", q],
    queryFn: () => searchMusic({ data: q }),
    enabled: q.trim().length >= 2,
  });
  const play = usePlayer((s) => s.toggle);
  const results = q.trim().length >= 2 ? (search.data ?? []) : (chart.data ?? []);

  return (
    <div>
      {value ? (
        <div className="flex items-center gap-2 rounded-xl bg-polaroid px-2 py-2 shadow-[inset_0_1px_3px_rgba(26,18,12,0.12)]">
          {value.artworkUrl ? (
            <img src={value.artworkUrl} alt="" className="size-10 rounded-md object-cover" />
          ) : (
            <Music2 className="size-5 text-brass-deep" />
          )}
          <div className="min-w-0 flex-1">
            <p className="truncate text-sm font-medium">{value.name}</p>
            <p className="truncate text-xs text-ink-soft">{value.artist}</p>
          </div>
          <button type="button" className="size-11 grid place-items-center" onClick={() => onChange(null)}>
            <X className="size-4" />
          </button>
        </div>
      ) : (
        <button type="button" className="nex-btn-ghost w-full" onClick={() => setOpen(true)}>
          <Music2 className="size-4" />
          Añadir canción de iTunes
        </button>
      )}

      {open ? (
        <div className="fixed inset-0 z-50 flex items-end justify-center bg-walnut/60 p-3 sm:items-center">
          <div className="nex-linen flex max-h-[80vh] w-full max-w-md flex-col overflow-hidden rounded-3xl p-4 shadow-[0_24px_50px_-20px_rgba(0,0,0,0.55)]">
            <div className="mb-3 flex items-center justify-between">
              <h2 className="font-display text-xl">iTunes Store</h2>
              <button type="button" className="grid size-11 place-items-center" onClick={() => setOpen(false)}>
                <X className="size-5" />
              </button>
            </div>
            <label className="relative mb-3 block">
              <Search className="absolute left-3 top-1/2 size-4 -translate-y-1/2 text-ink-soft" />
              <input
                className="nex-input pl-10"
                placeholder="Buscar canción o artista"
                value={q}
                onChange={(e) => setQ(e.target.value)}
              />
            </label>
            <div className="nex-scroll min-h-0 flex-1 space-y-1 overflow-y-auto">
              {results.map((t) => (
                <button
                  key={t.trackId}
                  type="button"
                  className={cn(
                    "flex w-full items-center gap-3 rounded-xl px-2 py-2 text-left",
                    "hover:bg-brass/15",
                  )}
                  onClick={() => {
                    onChange(t);
                    setOpen(false);
                  }}
                >
                  {t.artworkUrl ? (
                    <img src={t.artworkUrl} alt="" className="size-12 rounded-md object-cover" />
                  ) : (
                    <span className="nex-vinyl" />
                  )}
                  <span className="min-w-0 flex-1">
                    <span className="block truncate text-sm font-medium">{t.name}</span>
                    <span className="block truncate text-xs text-ink-soft">{t.artist}</span>
                  </span>
                  <span
                    role="presentation"
                    className="text-xs font-medium text-brass-deep underline-offset-2 hover:underline"
                    onClick={(e) => {
                      e.stopPropagation();
                      play(t);
                    }}
                  >
                    oír
                  </span>
                </button>
              ))}
              {search.isFetching || chart.isFetching ? (
                <p className="px-2 py-6 text-center text-sm text-ink-soft">Buscando en iTunes…</p>
              ) : null}
            </div>
          </div>
        </div>
      ) : null}
    </div>
  );
}
