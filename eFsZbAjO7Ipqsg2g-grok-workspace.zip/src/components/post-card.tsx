import { useRef, useState } from "react";
import { Link, useNavigate } from "@tanstack/react-router";
import { Bookmark, Heart, MessageCircle, Music2, Trash2 } from "lucide-react";
import { addComment, deletePost, toggleLike, toggleSave } from "@/lib/social/server";
import { usePlayer } from "@/lib/social/player";
import type { Comment, Post } from "@/lib/social/types";
import { cn, formatCount, isUnauthorized, timeAgo } from "@/lib/utils";
import { Avatar } from "./avatar";

export function PostCard({
  post,
  comments,
  onChange,
  onOpenComments,
  canDelete,
  featured,
}: {
  post: Post;
  comments?: Comment[];
  onChange?: (next: Post) => void;
  onOpenComments?: () => void;
  canDelete?: boolean;
  featured?: boolean;
}) {
  const navigate = useNavigate();
  const [busy, setBusy] = useState(false);
  const [draft, setDraft] = useState("");
  const [pop, setPop] = useState(false);
  const lastTap = useRef(0);
  const play = usePlayer((s) => s.toggle);
  const current = usePlayer((s) => s.track);
  const playing = usePlayer((s) => s.playing);

  async function needAuth<T>(fn: () => Promise<T>) {
    try {
      return await fn();
    } catch (err) {
      if (isUnauthorized(err)) {
        void navigate({ to: "/login" });
        return null;
      }
      throw err;
    }
  }

  async function like() {
    const res = await needAuth(() => toggleLike({ data: post.id }));
    if (!res) return;
    onChange?.({
      ...post,
      likedByMe: res.liked,
      likeCount: post.likeCount + (res.liked ? 1 : post.likedByMe ? -1 : 0),
    });
    if (res.liked) {
      setPop(true);
      window.setTimeout(() => setPop(false), 420);
    }
  }

  async function save() {
    const res = await needAuth(() => toggleSave({ data: post.id }));
    if (!res) return;
    onChange?.({ ...post, savedByMe: res.saved });
  }

  async function sendComment() {
    if (!draft.trim() || busy) return;
    setBusy(true);
    try {
      const c = await needAuth(() => addComment({ data: { postId: post.id, body: draft } }));
      if (c) {
        setDraft("");
        onChange?.({ ...post, commentCount: post.commentCount + 1 });
      }
    } finally {
      setBusy(false);
    }
  }

  function onPhotoClick() {
    const now = Date.now();
    if (now - lastTap.current < 280) {
      if (!post.likedByMe) void like();
    }
    lastTap.current = now;
  }

  const musicActive = playing && current?.trackId === post.music?.trackId;

  return (
    <article className={cn("nex-polaroid nex-card-enter", featured && "rotate-[-0.4deg]")}>
      <header className="mb-2 flex items-center gap-2 px-0.5">
        <Link to="/u/$username" params={{ username: post.username }} className="flex min-w-0 items-center gap-2">
          <Avatar src={post.avatarUrl} name={post.displayName} size="sm" />
          <span className="min-w-0">
            <span className="block truncate text-sm font-semibold text-ink">{post.username}</span>
            {post.location ? (
              <span className="block truncate text-[11px] text-ink-soft">{post.location}</span>
            ) : null}
          </span>
        </Link>
        <span className="ml-auto text-[11px] tabular-nums text-ink-soft">{timeAgo(post.createdAt)}</span>
        {canDelete ? (
          <button
            type="button"
            className="grid size-11 place-items-center text-ink-soft"
            aria-label="Eliminar"
            onClick={async () => {
              if (!window.confirm("¿Eliminar esta publicación?")) return;
              await needAuth(() => deletePost({ data: post.id }));
              onChange?.({ ...post, id: -post.id });
            }}
          >
            <Trash2 className="size-4" />
          </button>
        ) : null}
      </header>

      <button type="button" className="block w-full" onClick={onPhotoClick} aria-label="Me gusta con doble toque">
        <img src={post.imageUrl} alt="" className="nex-polaroid-photo" />
      </button>

      {post.music ? (
        <button
          type="button"
          className="mt-2 flex w-full items-center gap-2 rounded-lg bg-cream px-2 py-1.5 text-left"
          onClick={() => play(post.music!)}
        >
          <span className={cn("nex-vinyl shrink-0", musicActive && "spin")} />
          <Music2 className="size-3.5 text-brass-deep" />
          <span className="min-w-0 flex-1 truncate text-xs">
            <span className="font-medium">{post.music.name}</span>
            <span className="text-ink-soft"> · {post.music.artist}</span>
          </span>
        </button>
      ) : null}

      <div className="mt-1 flex items-center gap-1 px-0.5">
        <button
          type="button"
          className="relative grid size-11 place-items-center"
          onClick={() => void like()}
          aria-label="Me gusta"
        >
          <Heart
            className={cn(
              "nex-heart size-6",
              pop && "pop",
              post.likedByMe ? "fill-ruby text-ruby" : "text-ink",
            )}
          />
        </button>
        <button
          type="button"
          className="grid size-11 place-items-center"
          onClick={onOpenComments}
          aria-label="Comentarios"
        >
          <MessageCircle className="size-6 text-ink" />
        </button>
        <button
          type="button"
          className="ml-auto grid size-11 place-items-center"
          onClick={() => void save()}
          aria-label="Guardar"
        >
          <Bookmark
            className={cn("size-6", post.savedByMe ? "fill-brass-deep text-brass-deep" : "text-ink")}
          />
        </button>
      </div>

      <p className="px-0.5 text-sm font-semibold tabular-nums">{formatCount(post.likeCount)} me gusta</p>
      {post.caption ? (
        <p className="mt-1 px-0.5 text-sm leading-snug">
          <Link to="/u/$username" params={{ username: post.username }} className="mr-1 font-semibold">
            {post.username}
          </Link>
          {post.caption}
        </p>
      ) : null}
      {post.commentCount > 0 && !comments ? (
        <button
          type="button"
          className="mt-1 px-0.5 text-sm text-ink-soft"
          onClick={onOpenComments}
        >
          Ver los {post.commentCount} comentarios
        </button>
      ) : null}

      {comments?.slice(-3).map((c) => (
        <p key={c.id} className="mt-1 px-0.5 text-sm">
          <Link to="/u/$username" params={{ username: c.username }} className="mr-1 font-semibold">
            {c.username}
          </Link>
          {c.body}
        </p>
      ))}

      <form
        className="mt-2 flex items-center gap-2 border-t border-ink/10 pt-2"
        onSubmit={(e) => {
          e.preventDefault();
          void sendComment();
        }}
      >
        <input
          className="nex-input min-h-10 flex-1 text-sm"
          placeholder="Añade un comentario…"
          value={draft}
          onChange={(e) => setDraft(e.target.value)}
        />
        <button type="submit" className="nex-btn-brass min-h-10 px-3 text-sm" disabled={busy}>
          Enviar
        </button>
      </form>
    </article>
  );
}

export function PostGrid({ posts }: { posts: Post[] }) {
  return (
    <div className="grid grid-cols-3 gap-1">
      {posts.map((p) => (
        <Link
          key={p.id}
          to="/p/$postId"
          params={{ postId: String(p.id) }}
          className="relative block aspect-square overflow-hidden bg-paper-deep"
        >
          <img src={p.imageUrl} alt="" className="size-full object-cover" />
        </Link>
      ))}
    </div>
  );
}
