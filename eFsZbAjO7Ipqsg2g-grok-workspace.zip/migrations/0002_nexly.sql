-- Nexly social graph. user_id is Better Auth text id, or seed:<slug> for editorial.
create table if not exists profiles (
  user_id text primary key,
  username text not null unique,
  display_name text not null,
  bio text not null default '',
  avatar_url text,
  website text,
  is_seed boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists posts (
  id serial primary key,
  user_id text not null references profiles(user_id) on delete cascade,
  image_url text not null,
  caption text not null default '',
  location text,
  music_track_id text,
  music_name text,
  music_artist text,
  music_preview_url text,
  music_artwork_url text,
  created_at timestamptz not null default now()
);
create index if not exists posts_user_id_idx on posts (user_id);
create index if not exists posts_created_at_idx on posts (created_at desc);

create table if not exists stories (
  id serial primary key,
  user_id text not null references profiles(user_id) on delete cascade,
  image_url text not null,
  created_at timestamptz not null default now(),
  expires_at timestamptz not null
);
create index if not exists stories_user_idx on stories (user_id);
create index if not exists stories_expires_idx on stories (expires_at);

create table if not exists likes (
  post_id int not null references posts(id) on delete cascade,
  user_id text not null references profiles(user_id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (post_id, user_id)
);

create table if not exists comments (
  id serial primary key,
  post_id int not null references posts(id) on delete cascade,
  user_id text not null references profiles(user_id) on delete cascade,
  body text not null,
  created_at timestamptz not null default now()
);
create index if not exists comments_post_id_idx on comments (post_id, created_at);

create table if not exists saves (
  post_id int not null references posts(id) on delete cascade,
  user_id text not null references profiles(user_id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (post_id, user_id)
);

create table if not exists follows (
  follower_id text not null references profiles(user_id) on delete cascade,
  following_id text not null references profiles(user_id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (follower_id, following_id)
);
create index if not exists follows_following_idx on follows (following_id);

create table if not exists messages (
  id serial primary key,
  sender_id text not null references profiles(user_id) on delete cascade,
  recipient_id text not null references profiles(user_id) on delete cascade,
  body text not null,
  created_at timestamptz not null default now(),
  read_at timestamptz
);
create index if not exists messages_inbox_idx on messages (recipient_id, created_at desc);
create index if not exists messages_pair_idx on messages (sender_id, recipient_id, created_at);

create table if not exists notifications (
  id serial primary key,
  user_id text not null references profiles(user_id) on delete cascade,
  actor_id text not null references profiles(user_id) on delete cascade,
  type text not null,
  post_id int references posts(id) on delete cascade,
  created_at timestamptz not null default now(),
  is_read boolean not null default false
);
create index if not exists notifications_user_idx on notifications (user_id, created_at desc);
