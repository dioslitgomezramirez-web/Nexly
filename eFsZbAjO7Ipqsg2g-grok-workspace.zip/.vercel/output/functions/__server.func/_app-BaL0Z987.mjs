import { o as __toESM } from "./_runtime.mjs";
import { i as require_react, r as require_jsx_runtime, t as useQuery } from "./_libs/react+tanstack__react-query.mjs";
import { b as Link, g as Outlet, p as useRouterState } from "./_libs/@tanstack/react-router+[...].mjs";
import { a as Send, c as Play, h as Compass, l as Pause, n as UserRound, o as Search, p as House, t as X, u as Music2, v as Bell } from "./_libs/lucide-react.mjs";
import { n as useCurrentUserState, t as useCurrentUser } from "./_ssr/use-current-user-B2bKddY0.mjs";
import { d as getMyProfile, n as bootstrapMe } from "./_ssr/server-DOuEFaR7.mjs";
import { t as cn } from "./_ssr/utils-Ccwa5Si9.mjs";
import { t as Avatar } from "./_ssr/avatar-BoIYd6iS.mjs";
import { t as usePlayer } from "./_ssr/player-BHRTUmmJ.mjs";
import { r as resolvePreview } from "./_ssr/itunes-BF-gY6zr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_app-BaL0Z987.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function AudioDock() {
	const audioRef = (0, import_react.useRef)(null);
	const { track, playing, pause, toggle, stop } = usePlayer();
	(0, import_react.useEffect)(() => {
		const el = audioRef.current;
		if (!el) return;
		if (!track) {
			el.pause();
			el.removeAttribute("src");
			return;
		}
		let cancelled = false;
		async function attach() {
			if (!track) return;
			let src = track.previewUrl;
			if (!src) src = await resolvePreview({ data: {
				name: track.name,
				artist: track.artist
			} });
			if (cancelled || !src || !el) return;
			if (el.src !== src) el.src = src;
			if (playing) try {
				await el.play();
			} catch {
				pause();
			}
			else el.pause();
		}
		attach();
		return () => {
			cancelled = true;
		};
	}, [
		track,
		playing,
		pause
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("audio", {
		ref: audioRef,
		onEnded: () => pause(),
		onError: () => pause()
	}), track ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "pointer-events-none fixed inset-x-0 bottom-20 z-40 flex justify-center px-3 md:bottom-6",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: cn("pointer-events-auto flex w-full max-w-md items-center gap-3 rounded-2xl px-3 py-2", "nex-leather text-cream shadow-[0_10px_30px_-12px_rgba(0,0,0,0.6)]"),
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("nex-vinyl shrink-0", playing && "spin") }),
				track.artworkUrl ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: track.artworkUrl,
					alt: "",
					className: "size-10 rounded-md object-cover"
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0 flex-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "truncate font-display text-sm text-cream",
						children: track.name
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "truncate text-xs text-brass",
						children: [track.artist, " · iTunes"]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "nex-btn-brass grid size-11 place-items-center rounded-full",
					onClick: () => toggle(),
					"aria-label": playing ? "Pausar" : "Reproducir",
					children: playing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pause, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "size-4 ml-0.5" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "grid size-11 place-items-center text-cream/80",
					onClick: () => stop(),
					"aria-label": "Cerrar reproductor",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
				})
			]
		})
	}) : null] });
}
function AppShell({ children }) {
	const pathname = useRouterState({ select: (s) => s.location.pathname });
	const { user, isPending } = useCurrentUserState();
	(0, import_react.useEffect)(() => {
		if (!user) return;
		bootstrapMe({ data: {
			name: user.displayName,
			email: user.primaryEmail,
			image: user.profileImageUrl
		} }).catch(() => void 0);
	}, [user]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "nex-linen relative mx-auto flex min-h-dvh max-w-lg flex-col",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
				className: "nex-leather sticky top-0 z-30 px-3 pb-2 pt-[max(0.5rem,env(safe-area-inset-top))]",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/",
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "nex-lens",
							"aria-hidden": true,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "nex-lens-inner" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "nex-emboss font-display text-2xl tracking-tight",
							children: "Nexly"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "ml-auto flex items-center",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/search",
								className: "grid size-11 place-items-center text-cream",
								"aria-label": "Buscar",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "size-5" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/music",
								className: "grid size-11 place-items-center text-cream",
								"aria-label": "Música",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Music2, { className: "size-5" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/notifications",
								className: "grid size-11 place-items-center text-cream",
								"aria-label": "Avisos",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bell, { className: "size-5" })
							})
						]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
				className: "min-h-0 flex-1 pb-24",
				children
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
				className: "nex-metal fixed inset-x-0 bottom-0 z-30 mx-auto flex max-w-lg items-end justify-around px-2 pb-[max(0.4rem,env(safe-area-inset-bottom))] pt-1",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavIcon, {
						to: "/",
						icon: House,
						label: "Inicio",
						active: pathname === "/"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavIcon, {
						to: "/explore",
						icon: Compass,
						label: "Explorar",
						active: pathname.startsWith("/explore")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/create",
						className: "nex-shutter",
						"aria-label": "Publicar",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-5 rounded-full border-2 border-cream/80" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavIcon, {
						to: "/messages",
						icon: Send,
						label: "Mensajes",
						active: pathname.startsWith("/messages")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProfileTab, {
						active: pathname.startsWith("/u/") || pathname === "/edit-profile",
						isPending
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AudioDock, {})
		]
	});
}
function NavIcon({ to, icon: Icon, label, active }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
		to,
		className: cn("nex-dock-item", active && "is-active"),
		"aria-label": label,
		"aria-current": active ? "page" : void 0,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
			className: "size-6",
			strokeWidth: active ? 2.4 : 1.8
		})
	});
}
function ProfileTab({ active, isPending }) {
	const user = useCurrentUser();
	const me = useQuery({
		queryKey: ["me-profile"],
		queryFn: () => getMyProfile(),
		enabled: Boolean(user)
	});
	if (isPending) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "nex-dock-item",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-7 rounded-full bg-cream/20" })
	});
	if (!user) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
		to: "/login",
		className: cn("nex-dock-item", active && "is-active"),
		"aria-label": "Entrar",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserRound, { className: "size-6" })
	});
	const username = me.data?.username;
	if (!username) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
		to: "/edit-profile",
		className: cn("nex-dock-item", active && "is-active"),
		"aria-label": "Perfil",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Avatar, {
			src: user.profileImageUrl,
			name: user.displayName ?? "Tú",
			size: "sm",
			className: "size-7"
		})
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
		to: "/u/$username",
		params: { username },
		className: cn("nex-dock-item", active && "is-active"),
		"aria-label": "Perfil",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Avatar, {
			src: me.data?.avatarUrl ?? user.profileImageUrl,
			name: me.data?.displayName ?? "Tú",
			size: "sm",
			className: "size-7"
		})
	});
}
function AppLayout() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}) });
}
//#endregion
export { AppLayout as component };
