import { o as __toESM } from "./_runtime.mjs";
import { i as require_react, r as require_jsx_runtime, t as useQuery } from "./_libs/react+tanstack__react-query.mjs";
import { S as useNavigate, b as Link } from "./_libs/@tanstack/react-router+[...].mjs";
import { s as Plus, t as X } from "./_libs/lucide-react.mjs";
import { a as queryClient } from "./_ssr/router-Cy4vxgtI.mjs";
import { t as useCurrentUser } from "./_ssr/use-current-user-B2bKddY0.mjs";
import { g as getStories, i as createStory, l as getFeed, o as getComments } from "./_ssr/server-DOuEFaR7.mjs";
import { r as isUnauthorized, t as cn } from "./_ssr/utils-Ccwa5Si9.mjs";
import { t as Avatar } from "./_ssr/avatar-BoIYd6iS.mjs";
import { t as compressImage } from "./_ssr/image-CJIGJKC0.mjs";
import { t as PostCard } from "./_ssr/post-card-CEEK9XXp.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_app-B4BmISaz.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function StoriesRail({ groups, meUsername, onAdd }) {
	const [open, setOpen] = (0, import_react.useState)(null);
	const [idx, setIdx] = (0, import_react.useState)(0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "nex-scroll flex gap-3 overflow-x-auto px-1 pb-2 pt-1",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			type: "button",
			onClick: onAdd,
			className: "flex w-16 shrink-0 flex-col items-center gap-1.5",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "relative",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "nex-story-ring block",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Avatar, {
						name: meUsername ?? "Tú",
						size: "md",
						className: "size-14"
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "absolute -bottom-0.5 -right-0.5 grid size-5 place-items-center rounded-full bg-ruby text-cream shadow-md",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-3" })
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "w-16 truncate text-center text-[11px] font-medium text-ink-soft",
				children: "Tu historia"
			})]
		}), groups.map((g) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			type: "button",
			className: "flex w-16 shrink-0 flex-col items-center gap-1.5",
			onClick: () => {
				setOpen(g);
				setIdx(0);
			},
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "nex-story-ring",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Avatar, {
					src: g.avatarUrl,
					name: g.displayName,
					size: "md",
					className: "size-14"
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "w-16 truncate text-center text-[11px] font-medium text-ink-soft",
				children: g.username
			})]
		}, g.userId))]
	}), open ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "fixed inset-0 z-50 flex flex-col bg-walnut",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex gap-1 px-3 pt-3",
				children: open.items.map((item, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("h-1 flex-1 rounded-full", i <= idx ? "bg-brass" : "bg-cream/20") }, item.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between px-3 py-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/u/$username",
					params: { username: open.username },
					className: "flex items-center gap-2 text-cream",
					onClick: () => setOpen(null),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Avatar, {
						src: open.avatarUrl,
						name: open.displayName,
						size: "sm"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-medium",
						children: open.username
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "grid size-11 place-items-center text-cream",
					onClick: () => setOpen(null),
					"aria-label": "Cerrar historia",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" })
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "relative min-h-0 flex-1",
				onClick: () => {
					if (idx + 1 < open.items.length) setIdx(idx + 1);
					else setOpen(null);
				},
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: open.items[idx]?.imageUrl,
					alt: "",
					className: "absolute inset-0 size-full object-contain"
				})
			})
		]
	}) : null] });
}
function FeedPage() {
	const [tab, setTab] = (0, import_react.useState)("foryou");
	const [openId, setOpenId] = (0, import_react.useState)(null);
	const user = useCurrentUser();
	const navigate = useNavigate();
	const feed = useQuery({
		queryKey: ["feed", tab],
		queryFn: () => getFeed({ data: { tab } })
	});
	const stories = useQuery({
		queryKey: ["stories"],
		queryFn: () => getStories()
	});
	const comments = useQuery({
		queryKey: ["comments", openId],
		queryFn: () => getComments({ data: openId }),
		enabled: openId != null
	});
	function patch(next) {
		queryClient.setQueryData(["feed", tab], (old) => {
			if (!old) return old;
			if (next.id < 0) return old.filter((p) => p.id !== -next.id);
			return old.map((p) => p.id === next.id ? next : p);
		});
	}
	async function addStory() {
		if (!user) {
			navigate({ to: "/login" });
			return;
		}
		const input = document.createElement("input");
		input.type = "file";
		input.accept = "image/*";
		input.capture = "environment";
		input.onchange = async () => {
			const file = input.files?.[0];
			if (!file) return;
			try {
				const url = await compressImage(file, 1080);
				await createStory({ data: url });
				await stories.refetch();
			} catch (err) {
				if (isUnauthorized(err)) navigate({ to: "/login" });
				else window.alert(err instanceof Error ? err.message : "No se pudo publicar");
			}
		};
		input.click();
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "px-3 pb-6 pt-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mb-3 grid grid-cols-2 gap-1 rounded-xl bg-walnut/10 p-1",
				children: [["foryou", "Para ti"], ["following", "Siguiendo"]].map(([id, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: cn("rounded-lg py-2 text-sm font-medium", tab === id && "nex-btn-brass"),
					onClick: () => setTab(id),
					children: label
				}, id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StoriesRail, {
				groups: stories.data ?? [],
				meUsername: user?.displayName,
				onAdd: () => void addStory()
			}),
			feed.isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoadingReel, {}) : feed.isError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "px-2 py-10 text-center text-sm text-ruby",
				children: "No se pudo revelar el carrete."
			}) : (feed.data ?? []).length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "px-4 py-12 text-center text-sm text-ink-soft",
				children: tab === "following" ? "Sigue a alguien para llenar esta bandeja." : "Aún no hay publicaciones."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4 space-y-6",
				children: (feed.data ?? []).map((post) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PostCard, {
					post,
					featured: true,
					comments: openId === post.id ? comments.data : void 0,
					onChange: patch,
					onOpenComments: () => setOpenId(post.id)
				}, post.id))
			})
		]
	});
}
function LoadingReel() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col items-center gap-3 py-16",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "nex-vinyl spin size-14" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-display text-lg text-ink-soft",
			children: "Revelando el carrete…"
		})]
	});
}
//#endregion
export { FeedPage as component };
