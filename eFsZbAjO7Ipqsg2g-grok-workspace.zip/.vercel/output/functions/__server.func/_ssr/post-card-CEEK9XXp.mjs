import { o as __toESM } from "../_runtime.mjs";
import { i as require_react, r as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { S as useNavigate, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { _ as Bookmark, d as MessageCircle, i as Trash2, m as Heart, u as Music2 } from "../_libs/lucide-react.mjs";
import { S as toggleSave, a as deletePost, t as addComment, x as toggleLike } from "./server-DOuEFaR7.mjs";
import { i as timeAgo, n as formatCount, r as isUnauthorized, t as cn } from "./utils-Ccwa5Si9.mjs";
import { t as Avatar } from "./avatar-BoIYd6iS.mjs";
import { t as usePlayer } from "./player-BHRTUmmJ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/post-card-CEEK9XXp.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function PostCard({ post, comments, onChange, onOpenComments, canDelete, featured }) {
	const navigate = useNavigate();
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [draft, setDraft] = (0, import_react.useState)("");
	const [pop, setPop] = (0, import_react.useState)(false);
	const lastTap = (0, import_react.useRef)(0);
	const play = usePlayer((s) => s.toggle);
	const current = usePlayer((s) => s.track);
	const playing = usePlayer((s) => s.playing);
	async function needAuth(fn) {
		try {
			return await fn();
		} catch (err) {
			if (isUnauthorized(err)) {
				navigate({ to: "/login" });
				return null;
			}
			throw err;
		}
	}
	async function like() {
		const res = await needAuth(() => toggleLike({ data: post.id }));
		if (!res) return;
		onChange?.({
			...post,
			likedByMe: res.liked,
			likeCount: post.likeCount + (res.liked ? 1 : post.likedByMe ? -1 : 0)
		});
		if (res.liked) {
			setPop(true);
			window.setTimeout(() => setPop(false), 420);
		}
	}
	async function save() {
		const res = await needAuth(() => toggleSave({ data: post.id }));
		if (!res) return;
		onChange?.({
			...post,
			savedByMe: res.saved
		});
	}
	async function sendComment() {
		if (!draft.trim() || busy) return;
		setBusy(true);
		try {
			if (await needAuth(() => addComment({ data: {
				postId: post.id,
				body: draft
			} }))) {
				setDraft("");
				onChange?.({
					...post,
					commentCount: post.commentCount + 1
				});
			}
		} finally {
			setBusy(false);
		}
	}
	function onPhotoClick() {
		const now = Date.now();
		if (now - lastTap.current < 280) {
			if (!post.likedByMe) like();
		}
		lastTap.current = now;
	}
	const musicActive = playing && current?.trackId === post.music?.trackId;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: cn("nex-polaroid nex-card-enter", featured && "rotate-[-0.4deg]"),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "mb-2 flex items-center gap-2 px-0.5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/u/$username",
						params: { username: post.username },
						className: "flex min-w-0 items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Avatar, {
							src: post.avatarUrl,
							name: post.displayName,
							size: "sm"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "min-w-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block truncate text-sm font-semibold text-ink",
								children: post.username
							}), post.location ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block truncate text-[11px] text-ink-soft",
								children: post.location
							}) : null]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "ml-auto text-[11px] tabular-nums text-ink-soft",
						children: timeAgo(post.createdAt)
					}),
					canDelete ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "grid size-11 place-items-center text-ink-soft",
						"aria-label": "Eliminar",
						onClick: async () => {
							if (!window.confirm("¿Eliminar esta publicación?")) return;
							await needAuth(() => deletePost({ data: post.id }));
							onChange?.({
								...post,
								id: -post.id
							});
						},
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" })
					}) : null
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "block w-full",
				onClick: onPhotoClick,
				"aria-label": "Me gusta con doble toque",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: post.imageUrl,
					alt: "",
					className: "nex-polaroid-photo"
				})
			}),
			post.music ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				className: "mt-2 flex w-full items-center gap-2 rounded-lg bg-cream px-2 py-1.5 text-left",
				onClick: () => play(post.music),
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("nex-vinyl shrink-0", musicActive && "spin") }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Music2, { className: "size-3.5 text-brass-deep" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "min-w-0 flex-1 truncate text-xs",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-medium",
							children: post.music.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-ink-soft",
							children: [" · ", post.music.artist]
						})]
					})
				]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-1 flex items-center gap-1 px-0.5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "relative grid size-11 place-items-center",
						onClick: () => void like(),
						"aria-label": "Me gusta",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heart, { className: cn("nex-heart size-6", pop && "pop", post.likedByMe ? "fill-ruby text-ruby" : "text-ink") })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "grid size-11 place-items-center",
						onClick: onOpenComments,
						"aria-label": "Comentarios",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageCircle, { className: "size-6 text-ink" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "ml-auto grid size-11 place-items-center",
						onClick: () => void save(),
						"aria-label": "Guardar",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bookmark, { className: cn("size-6", post.savedByMe ? "fill-brass-deep text-brass-deep" : "text-ink") })
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "px-0.5 text-sm font-semibold tabular-nums",
				children: [formatCount(post.likeCount), " me gusta"]
			}),
			post.caption ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-1 px-0.5 text-sm leading-snug",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/u/$username",
					params: { username: post.username },
					className: "mr-1 font-semibold",
					children: post.username
				}), post.caption]
			}) : null,
			post.commentCount > 0 && !comments ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				className: "mt-1 px-0.5 text-sm text-ink-soft",
				onClick: onOpenComments,
				children: [
					"Ver los ",
					post.commentCount,
					" comentarios"
				]
			}) : null,
			comments?.slice(-3).map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-1 px-0.5 text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/u/$username",
					params: { username: c.username },
					className: "mr-1 font-semibold",
					children: c.username
				}), c.body]
			}, c.id)),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "mt-2 flex items-center gap-2 border-t border-ink/10 pt-2",
				onSubmit: (e) => {
					e.preventDefault();
					sendComment();
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: "nex-input min-h-10 flex-1 text-sm",
					placeholder: "Añade un comentario…",
					value: draft,
					onChange: (e) => setDraft(e.target.value)
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "submit",
					className: "nex-btn-brass min-h-10 px-3 text-sm",
					disabled: busy,
					children: "Enviar"
				})]
			})
		]
	});
}
function PostGrid({ posts }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid grid-cols-3 gap-1",
		children: posts.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/p/$postId",
			params: { postId: String(p.id) },
			className: "relative block aspect-square overflow-hidden bg-paper-deep",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: p.imageUrl,
				alt: "",
				className: "size-full object-cover"
			})
		}, p.id))
	});
}
//#endregion
export { PostGrid as n, PostCard as t };
