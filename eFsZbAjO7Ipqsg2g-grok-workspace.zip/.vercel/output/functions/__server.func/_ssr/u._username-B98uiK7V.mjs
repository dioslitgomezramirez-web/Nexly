import { r as require_jsx_runtime, t as useQuery } from "../_libs/react+tanstack__react-query.mjs";
import { S as useNavigate, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { _ as Bookmark, a as Send } from "../_libs/lucide-react.mjs";
import { a as queryClient, n as Route$1 } from "./router-Cy4vxgtI.mjs";
import { t as useCurrentUser } from "./use-current-user-B2bKddY0.mjs";
import { b as toggleFollow, m as getProfile } from "./server-DOuEFaR7.mjs";
import { n as formatCount, r as isUnauthorized } from "./utils-Ccwa5Si9.mjs";
import { t as Avatar } from "./avatar-BoIYd6iS.mjs";
import { n as PostGrid } from "./post-card-CEEK9XXp.mjs";
import { n as UserButton } from "./gates-q9-EKWXz.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/u._username-B98uiK7V.js
var import_jsx_runtime = require_jsx_runtime();
function ProfilePage() {
	const { username } = Route$1.useParams();
	const user = useCurrentUser();
	const navigate = useNavigate();
	const q = useQuery({
		queryKey: ["profile", username],
		queryFn: () => getProfile({ data: username })
	});
	const data = q.data;
	if (q.isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "py-16 text-center text-sm text-ink-soft",
		children: "Abriendo el álbum…"
	});
	if (!data) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
		className: "py-16 text-center text-sm text-ink-soft",
		children: [
			"No existe @",
			username,
			"."
		]
	});
	const { profile, posts } = data;
	async function follow() {
		try {
			const res = await toggleFollow({ data: profile.userId });
			queryClient.setQueryData(["profile", username], {
				...data,
				profile: {
					...profile,
					isFollowing: res.following,
					followersCount: profile.followersCount + (res.following ? 1 : -1)
				}
			});
		} catch (err) {
			if (isUnauthorized(err)) navigate({ to: "/login" });
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "pb-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "nex-leather px-4 pb-5 pt-4 text-cream",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start gap-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Avatar, {
						src: profile.avatarUrl,
						name: profile.displayName,
						size: "xl",
						className: "size-20"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0 flex-1",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
								className: "font-display text-2xl text-cream",
								children: profile.displayName
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-sm text-brass",
								children: ["@", profile.username]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-3 flex gap-4 text-center text-sm",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
										n: profile.postsCount,
										label: "fotos"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
										n: profile.followersCount,
										label: "seguidores"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
										n: profile.followingCount,
										label: "siguiendo"
									})
								]
							})
						]
					})]
				}),
				profile.bio ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-sm leading-snug text-cream/90",
					children: profile.bio
				}) : null,
				profile.website ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					href: profile.website,
					className: "mt-1 inline-block text-sm text-brass underline-offset-2 hover:underline",
					children: profile.website
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-4 flex flex-wrap gap-2",
					children: profile.isMe ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/edit-profile",
							className: "nex-btn-brass flex-1",
							children: "Editar perfil"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/saved",
							className: "nex-btn-ghost text-ink",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bookmark, { className: "size-4" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "nex-btn-ghost text-ink [&_button]:text-ink [&_span]:text-ink",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserButton, {})
						})
					] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: profile.isFollowing ? "nex-btn-ghost flex-1 text-ink" : "nex-btn flex-1",
						onClick: () => void follow(),
						children: profile.isFollowing ? "Siguiendo" : "Seguir"
					}), user ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/messages/$username",
						params: { username: profile.username },
						className: "nex-btn-brass",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, { className: "size-4" })
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/login",
						className: "nex-btn-brass",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, { className: "size-4" })
					})] })
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PostGrid, { posts })]
	});
}
function Stat({ n, label }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "font-display text-lg tabular-nums",
		children: formatCount(n)
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "text-[11px] uppercase tracking-wide text-brass",
		children: label
	})] });
}
//#endregion
export { ProfilePage as component };
