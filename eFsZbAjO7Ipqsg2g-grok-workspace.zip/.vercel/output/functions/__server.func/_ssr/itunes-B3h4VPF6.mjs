import { r as createServerFn } from "./ssr.mjs";
import { t as createServerRpc } from "./createServerRpc-CcvdN_gc.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/itunes-B3h4VPF6.js
function upgradeArt(url) {
	if (!url) return null;
	return url.replace("100x100bb", "300x300bb").replace("100x100", "300x300");
}
function mapItunes(row) {
	if (!row.trackId || !row.trackName || !row.artistName) return null;
	return {
		trackId: String(row.trackId),
		name: row.trackName,
		artist: row.artistName,
		previewUrl: row.previewUrl ?? null,
		artworkUrl: upgradeArt(row.artworkUrl100)
	};
}
async function fetchItunesSongs(term, limit = 20) {
	const q = term.trim();
	if (!q) return [];
	const url = new URL("https://itunes.apple.com/search");
	url.searchParams.set("term", q);
	url.searchParams.set("media", "music");
	url.searchParams.set("entity", "song");
	url.searchParams.set("limit", String(Math.min(40, Math.max(1, limit))));
	url.searchParams.set("country", "es");
	const res = await fetch(url.toString(), { headers: { Accept: "application/json" } });
	if (!res.ok) throw new Error("iTunes no respondió");
	const json = await res.json();
	const out = [];
	for (const row of json.results ?? []) {
		const mapped = mapItunes(row);
		if (mapped) out.push(mapped);
	}
	return out;
}
async function fetchAppleChart() {
	const res = await fetch("https://rss.applemarketingtools.com/api/v2/es/music/most-played/25/songs.json", { headers: { Accept: "application/json" } });
	if (!res.ok) throw new Error("No se pudo leer el ranking de Apple");
	return ((await res.json()).feed?.results ?? []).map((item) => ({
		trackId: item.id,
		name: item.name,
		artist: item.artistName,
		previewUrl: null,
		artworkUrl: upgradeArt(item.artworkUrl100)
	}));
}
var searchMusic_createServerFn_handler = createServerRpc({
	id: "d27625b87d4cd11c8c2e5db5f16e3a21ab63a42053c3202776c662d4938a6b3b",
	name: "searchMusic",
	filename: "src/lib/social/itunes.ts"
}, (opts) => searchMusic.__executeServer(opts));
var searchMusic = createServerFn({ method: "GET" }).validator((term) => String(term ?? "").slice(0, 80)).handler(searchMusic_createServerFn_handler, async ({ data: term }) => {
	return fetchItunesSongs(term, 24);
});
var listTopMusic_createServerFn_handler = createServerRpc({
	id: "867ca90233a1d76ef2f1a7cd27ad5ab9ca3e4ba6188bcc56cd743d3d95e325da",
	name: "listTopMusic",
	filename: "src/lib/social/itunes.ts"
}, (opts) => listTopMusic.__executeServer(opts));
var listTopMusic = createServerFn({ method: "GET" }).handler(listTopMusic_createServerFn_handler, async () => {
	try {
		return await fetchAppleChart();
	} catch {
		return fetchItunesSongs("pop latino", 20);
	}
});
var resolvePreview_createServerFn_handler = createServerRpc({
	id: "a9e2d9130f7fed4cb70e0ccd4ce567f746e702bc4f2a426d2ad78b12c5847abe",
	name: "resolvePreview",
	filename: "src/lib/social/itunes.ts"
}, (opts) => resolvePreview.__executeServer(opts));
var resolvePreview = createServerFn({ method: "GET" }).validator((payload) => payload).handler(resolvePreview_createServerFn_handler, async ({ data }) => {
	const hits = await fetchItunesSongs(`${data.artist} ${data.name}`, 5);
	return hits.find((t) => t.previewUrl)?.previewUrl ?? hits[0]?.previewUrl ?? null;
});
//#endregion
export { listTopMusic_createServerFn_handler, resolvePreview_createServerFn_handler, searchMusic_createServerFn_handler };
