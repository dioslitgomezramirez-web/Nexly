import { t as clsx } from "../_libs/clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/utils-Ccwa5Si9.js
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function timeAgo(iso) {
	const then = new Date(iso).getTime();
	if (Number.isNaN(then)) return "";
	const sec = Math.max(0, Math.floor((Date.now() - then) / 1e3));
	if (sec < 45) return "ahora";
	const min = Math.floor(sec / 60);
	if (min < 60) return `hace ${min} min`;
	const hr = Math.floor(min / 60);
	if (hr < 24) return `hace ${hr} h`;
	const day = Math.floor(hr / 24);
	if (day < 7) return `hace ${day} d`;
	const week = Math.floor(day / 7);
	if (week < 5) return `hace ${week} sem`;
	const month = Math.floor(day / 30);
	if (month < 12) return `hace ${month} mes`;
	return `hace ${Math.floor(day / 365)} a`;
}
function formatCount(n) {
	if (n < 1e3) return String(n);
	if (n < 1e4) return `${(n / 1e3).toFixed(1).replace(".0", "")} mil`;
	if (n < 1e6) return `${Math.round(n / 1e3)} mil`;
	return `${(n / 1e6).toFixed(1).replace(".0", "")} M`;
}
function isUnauthorized(err) {
	return err instanceof Error && err.message === "Unauthorized";
}
//#endregion
export { timeAgo as i, formatCount as n, isUnauthorized as r, cn as t };
