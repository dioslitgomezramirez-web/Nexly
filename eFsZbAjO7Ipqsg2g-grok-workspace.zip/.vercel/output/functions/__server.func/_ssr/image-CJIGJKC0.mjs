//#region node_modules/.nitro/vite/services/ssr/assets/image-CJIGJKC0.js
async function compressImage(file, maxEdge = 1080) {
	const bitmap = await loadImage(file);
	const scale = Math.min(1, maxEdge / Math.max(bitmap.width, bitmap.height));
	const width = Math.max(1, Math.round(bitmap.width * scale));
	const height = Math.max(1, Math.round(bitmap.height * scale));
	const canvas = document.createElement("canvas");
	canvas.width = width;
	canvas.height = height;
	const ctx = canvas.getContext("2d");
	if (!ctx) throw new Error("No se pudo procesar la foto");
	ctx.fillStyle = "#1a120c";
	ctx.fillRect(0, 0, width, height);
	ctx.drawImage(bitmap, 0, 0, width, height);
	let q = .82;
	let url = canvas.toDataURL("image/jpeg", q);
	while (url.length > 48e4 && q > .48) {
		q -= .08;
		url = canvas.toDataURL("image/jpeg", q);
	}
	if (url.length > 62e4) throw new Error("La foto es demasiado pesada");
	return url;
}
function loadImage(file) {
	return new Promise((resolve, reject) => {
		const url = URL.createObjectURL(file);
		const img = new Image();
		img.onload = () => {
			URL.revokeObjectURL(url);
			resolve(img);
		};
		img.onerror = () => {
			URL.revokeObjectURL(url);
			reject(/* @__PURE__ */ new Error("No se pudo leer la foto"));
		};
		img.src = url;
	});
}
//#endregion
export { compressImage as t };
