import { t as create } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/player-BHRTUmmJ.js
var usePlayer = create((set, get) => ({
	track: null,
	playing: false,
	play: (track) => set({
		track,
		playing: true
	}),
	pause: () => set({ playing: false }),
	toggle: (track) => {
		const cur = get();
		if (track && cur.track?.trackId !== track.trackId) {
			set({
				track,
				playing: true
			});
			return;
		}
		set({ playing: !cur.playing });
	},
	stop: () => set({
		track: null,
		playing: false
	})
}));
//#endregion
export { usePlayer as t };
