import { o as __toESM } from "../_runtime.mjs";
import { i as require_react, r as require_jsx_runtime, t as useQuery } from "../_libs/react+tanstack__react-query.mjs";
import { c as Play, o as Search } from "../_libs/lucide-react.mjs";
import { t as usePlayer } from "./player-BHRTUmmJ.mjs";
import { i as searchMusic, n as listTopMusic } from "./itunes-BF-gY6zr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/music-i1GXqNu2.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function MusicPage() {
	const [q, setQ] = (0, import_react.useState)("");
	const chart = useQuery({
		queryKey: ["itunes-top"],
		queryFn: () => listTopMusic()
	});
	const search = useQuery({
		queryKey: ["itunes", q],
		queryFn: () => searchMusic({ data: q }),
		enabled: q.trim().length >= 2
	});
	const play = usePlayer((s) => s.play);
	const tracks = q.trim().length >= 2 ? search.data ?? [] : chart.data ?? [];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "px-3 py-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-2xl",
				children: "Tocadiscos"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-3 text-sm text-ink-soft",
				children: "Preescuchas de 30 s desde iTunes Store. Datos reales de Apple."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "relative mb-4 block",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "absolute left-3 top-1/2 size-4 -translate-y-1/2 text-ink-soft" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: "nex-input pl-10",
					placeholder: "Buscar en iTunes",
					value: q,
					onChange: (e) => setQ(e.target.value)
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "space-y-2",
				children: tracks.map((t, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					className: "flex w-full items-center gap-3 rounded-2xl bg-polaroid px-3 py-2 text-left shadow-[0_6px_16px_-10px_rgba(26,18,12,0.4)]",
					onClick: () => play(t),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "w-6 text-center font-display text-brass-deep tabular-nums",
							children: i + 1
						}),
						t.artworkUrl ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: t.artworkUrl,
							alt: "",
							className: "size-12 rounded-md object-cover"
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "nex-vinyl" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "min-w-0 flex-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block truncate text-sm font-semibold",
								children: t.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block truncate text-xs text-ink-soft",
								children: t.artist
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "size-4 text-brass-deep" })
					]
				}) }, t.trackId))
			}),
			chart.isFetching || search.isFetching ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "py-8 text-center text-sm text-ink-soft",
				children: "Consultando iTunes…"
			}) : null
		]
	});
}
//#endregion
export { MusicPage as component };
