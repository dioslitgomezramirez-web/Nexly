import { o as __toESM } from "../_runtime.mjs";
import { i as require_react, r as require_jsx_runtime, t as useQuery } from "../_libs/react+tanstack__react-query.mjs";
import { S as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { f as ImagePlus, g as Camera, o as Search, t as X, u as Music2 } from "../_libs/lucide-react.mjs";
import { a as queryClient } from "./router-Cy4vxgtI.mjs";
import { n as useCurrentUserState } from "./use-current-user-B2bKddY0.mjs";
import { i as createStory, r as createPost } from "./server-DOuEFaR7.mjs";
import { t as cn } from "./utils-Ccwa5Si9.mjs";
import { t as compressImage } from "./image-CJIGJKC0.mjs";
import { t as usePlayer } from "./player-BHRTUmmJ.mjs";
import { i as searchMusic, n as listTopMusic } from "./itunes-BF-gY6zr.mjs";
import { t as RedirectToSignIn } from "./gates-q9-EKWXz.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/create-DqtxgzTw.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function MusicPicker({ value, onChange }) {
	const [q, setQ] = (0, import_react.useState)("");
	const [open, setOpen] = (0, import_react.useState)(false);
	const chart = useQuery({
		queryKey: ["itunes-top"],
		queryFn: () => listTopMusic()
	});
	const search = useQuery({
		queryKey: ["itunes", q],
		queryFn: () => searchMusic({ data: q }),
		enabled: q.trim().length >= 2
	});
	const play = usePlayer((s) => s.toggle);
	const results = q.trim().length >= 2 ? search.data ?? [] : chart.data ?? [];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [value ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center gap-2 rounded-xl bg-polaroid px-2 py-2 shadow-[inset_0_1px_3px_rgba(26,18,12,0.12)]",
		children: [
			value.artworkUrl ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: value.artworkUrl,
				alt: "",
				className: "size-10 rounded-md object-cover"
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Music2, { className: "size-5 text-brass-deep" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0 flex-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "truncate text-sm font-medium",
					children: value.name
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "truncate text-xs text-ink-soft",
					children: value.artist
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "size-11 grid place-items-center",
				onClick: () => onChange(null),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
			})
		]
	}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		className: "nex-btn-ghost w-full",
		onClick: () => setOpen(true),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Music2, { className: "size-4" }), "Añadir canción de iTunes"]
	}), open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-50 flex items-end justify-center bg-walnut/60 p-3 sm:items-center",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "nex-linen flex max-h-[80vh] w-full max-w-md flex-col overflow-hidden rounded-3xl p-4 shadow-[0_24px_50px_-20px_rgba(0,0,0,0.55)]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-3 flex items-center justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-xl",
						children: "iTunes Store"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "grid size-11 place-items-center",
						onClick: () => setOpen(false),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" })
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "relative mb-3 block",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "absolute left-3 top-1/2 size-4 -translate-y-1/2 text-ink-soft" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "nex-input pl-10",
						placeholder: "Buscar canción o artista",
						value: q,
						onChange: (e) => setQ(e.target.value)
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "nex-scroll min-h-0 flex-1 space-y-1 overflow-y-auto",
					children: [results.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: cn("flex w-full items-center gap-3 rounded-xl px-2 py-2 text-left", "hover:bg-brass/15"),
						onClick: () => {
							onChange(t);
							setOpen(false);
						},
						children: [
							t.artworkUrl ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: t.artworkUrl,
								alt: "",
								className: "size-12 rounded-md object-cover"
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "nex-vinyl" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "min-w-0 flex-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block truncate text-sm font-medium",
									children: t.name
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block truncate text-xs text-ink-soft",
									children: t.artist
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								role: "presentation",
								className: "text-xs font-medium text-brass-deep underline-offset-2 hover:underline",
								onClick: (e) => {
									e.stopPropagation();
									play(t);
								},
								children: "oír"
							})
						]
					}, t.trackId)), search.isFetching || chart.isFetching ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "px-2 py-6 text-center text-sm text-ink-soft",
						children: "Buscando en iTunes…"
					}) : null]
				})
			]
		})
	}) : null] });
}
function CreatePage() {
	const { user, isPending } = useCurrentUserState();
	const navigate = useNavigate();
	const [mode, setMode] = (0, import_react.useState)("post");
	const [preview, setPreview] = (0, import_react.useState)(null);
	const [caption, setCaption] = (0, import_react.useState)("");
	const [location, setLocation] = (0, import_react.useState)("");
	const [music, setMusic] = (0, import_react.useState)(null);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)(null);
	if (isPending) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-40" });
	if (!user) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RedirectToSignIn, {});
	async function onFile(file) {
		if (!file) return;
		setError(null);
		try {
			setPreview(await compressImage(file));
		} catch (err) {
			setError(err instanceof Error ? err.message : "No se pudo leer la foto");
		}
	}
	async function publish() {
		if (!preview) {
			setError("Elige una foto");
			return;
		}
		setBusy(true);
		setError(null);
		try {
			if (mode === "story") {
				await createStory({ data: preview });
				await queryClient.invalidateQueries({ queryKey: ["stories"] });
				await navigate({ to: "/" });
			} else {
				const { id } = await createPost({ data: {
					imageUrl: preview,
					caption,
					location,
					music
				} });
				await queryClient.invalidateQueries({ queryKey: ["feed"] });
				await navigate({
					to: "/p/$postId",
					params: { postId: String(id) }
				});
			}
		} catch (err) {
			setError(err instanceof Error ? err.message : "No se pudo publicar");
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "px-4 py-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-2xl",
				children: "Nueva placa"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 grid grid-cols-2 gap-1 rounded-xl bg-walnut/10 p-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: cn("rounded-lg py-2 text-sm", mode === "post" && "nex-btn-brass"),
					onClick: () => setMode("post"),
					children: "Publicación"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: cn("rounded-lg py-2 text-sm", mode === "story" && "nex-btn-brass"),
					onClick: () => setMode("story"),
					children: "Historia"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "nex-polaroid mx-auto mt-4 max-w-sm",
				children: preview ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: preview,
					alt: "",
					className: "nex-polaroid-photo"
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "nex-polaroid-photo grid cursor-pointer place-items-center text-ink-soft",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "flex flex-col items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImagePlus, { className: "size-8" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-sm",
							children: "Toca para elegir foto"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "file",
						accept: "image/*",
						className: "hidden",
						onChange: (e) => void onFile(e.target.files?.[0])
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 flex gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "nex-btn-ghost flex-1",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImagePlus, { className: "size-4" }),
						"Galería",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "file",
							accept: "image/*",
							className: "hidden",
							onChange: (e) => void onFile(e.target.files?.[0])
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "nex-btn-ghost flex-1",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Camera, { className: "size-4" }),
						"Cámara",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "file",
							accept: "image/*",
							capture: "environment",
							className: "hidden",
							onChange: (e) => void onFile(e.target.files?.[0])
						})
					]
				})]
			}),
			mode === "post" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 space-y-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						className: "nex-input min-h-24 py-3",
						placeholder: "Escribe un pie de foto…",
						value: caption,
						onChange: (e) => setCaption(e.target.value),
						maxLength: 500
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "nex-input",
						placeholder: "Lugar",
						value: location,
						onChange: (e) => setLocation(e.target.value)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MusicPicker, {
						value: music,
						onChange: setMusic
					})
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-sm text-ink-soft",
				children: "Las historias se apagan a las 24 horas."
			}),
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-sm text-ruby",
				children: error
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "nex-btn mt-4 w-full",
				disabled: busy,
				onClick: () => void publish(),
				children: busy ? "Revelando…" : mode === "story" ? "Subir historia" : "Publicar"
			})
		]
	});
}
//#endregion
export { CreatePage as component };
