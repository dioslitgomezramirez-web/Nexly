import { o as __toESM } from "../_runtime.mjs";
import { i as require_react, r as require_jsx_runtime, t as useQuery } from "../_libs/react+tanstack__react-query.mjs";
import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as queryClient, i as Route$3 } from "./router-Cy4vxgtI.mjs";
import { n as useCurrentUserState } from "./use-current-user-B2bKddY0.mjs";
import { u as getMessages, y as sendMessage } from "./server-DOuEFaR7.mjs";
import { t as cn } from "./utils-Ccwa5Si9.mjs";
import { t as Avatar } from "./avatar-BoIYd6iS.mjs";
import { t as RedirectToSignIn } from "./gates-q9-EKWXz.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/messages._username-DJHsgOCs.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ThreadPage() {
	const { username } = Route$3.useParams();
	const { user, isPending } = useCurrentUserState();
	const [body, setBody] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	const q = useQuery({
		queryKey: ["thread", username],
		queryFn: () => getMessages({ data: username }),
		enabled: Boolean(user)
	});
	if (isPending) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-40" });
	if (!user) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RedirectToSignIn, {});
	async function send(e) {
		e.preventDefault();
		if (!body.trim() || busy) return;
		setBusy(true);
		try {
			const msg = await sendMessage({ data: {
				username,
				body
			} });
			queryClient.setQueryData(["thread", username], (old) => {
				if (!old) return old;
				return {
					...old,
					messages: [...old.messages, msg]
				};
			});
			setBody("");
		} finally {
			setBusy(false);
		}
	}
	const peer = q.data?.peer;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-[calc(100dvh-8rem)] flex-col px-3 py-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
				className: "mb-3 flex items-center gap-2",
				children: peer ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/u/$username",
					params: { username: peer.username },
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Avatar, {
						src: peer.avatarUrl,
						name: peer.displayName,
						size: "sm"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-display text-lg",
						children: peer.displayName
					})]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "font-display text-lg",
					children: ["@", username]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "nex-scroll flex min-h-0 flex-1 flex-col gap-2 overflow-y-auto pb-3",
				children: [(q.data?.messages ?? []).map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: cn("max-w-[80%] rounded-2xl px-3 py-2 text-sm leading-snug", m.mine ? "ml-auto bg-leather text-cream" : "bg-polaroid text-ink shadow-[0_4px_12px_-8px_rgba(26,18,12,0.4)]"),
					children: m.body
				}, m.id)), !q.isLoading && (q.data?.messages ?? []).length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "py-10 text-center text-sm text-ink-soft",
					children: "Escribe la primera línea."
				}) : null]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "flex gap-2",
				onSubmit: (e) => void send(e),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: "nex-input flex-1",
					placeholder: "Mensaje",
					value: body,
					onChange: (e) => setBody(e.target.value)
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "submit",
					className: "nex-btn px-4",
					disabled: busy,
					children: "Enviar"
				})]
			})
		]
	});
}
//#endregion
export { ThreadPage as component };
