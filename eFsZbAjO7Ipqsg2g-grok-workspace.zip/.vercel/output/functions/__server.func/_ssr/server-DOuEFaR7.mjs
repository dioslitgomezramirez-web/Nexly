import { r as createServerFn } from "./ssr.mjs";
import { t as authMiddleware } from "./middleware-Dm6n349X.mjs";
import { t as createSsrRpc } from "./createSsrRpc-B2Izd0c7.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/server-DOuEFaR7.js
function slugBase(input) {
	return input.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().replace(/[^a-z0-9]+/g, "").slice(0, 16) || "nexly";
}
var getFeed = createServerFn({ method: "GET" }).validator((payload) => payload ?? { tab: "foryou" }).handler(createSsrRpc("c167f789dced6ceeb7e53b5771aacbcdfe7b9d2238f8c4c16b093acce6c33bd7"));
var getExplore = createServerFn({ method: "GET" }).handler(createSsrRpc("4ba78b3362c1f354bafc24b4e1209ae480facf38d552cba5550960fc3ae2452b"));
var getPost = createServerFn({ method: "GET" }).validator((id) => Number(id)).handler(createSsrRpc("d1806a7998772b3b21f61ae15ddac7fae93c9580d2484214eaa6db3ddaef993d"));
var getStories = createServerFn({ method: "GET" }).handler(createSsrRpc("45a4271be6a7a325ed38eedf35f42524ce6537602234188e2edd958c6c1093c7"));
var getComments = createServerFn({ method: "GET" }).validator((postId) => Number(postId)).handler(createSsrRpc("af80b23960cc36e920dc093c5b63bfb95abcf5b812f15ed216b7d9e638e5297b"));
var searchAll = createServerFn({ method: "GET" }).validator((q) => String(q ?? "").trim().slice(0, 60)).handler(createSsrRpc("b7cbe95836c28f9463a37c924f9195e0d59df744df016c07dc246a63d5d3ff34"));
var getProfile = createServerFn({ method: "GET" }).validator((username) => String(username).replace(/^@/, "").slice(0, 32)).handler(createSsrRpc("c9bd8e12d6ebbe0ee7d91ac002adf46ab12a7aa684875d79580e030858704d17"));
var getMyProfile = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("7cdf8eb461c63e16a950fe2223aa7db7a0cc7838d212c2c01b764d9247086bbf"));
var bootstrapMe = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((hint) => hint).handler(createSsrRpc("cccd4576f2b6a77d7b589b0cd32eec3008a0ea0a008c5f80bf7937a53ea88e86"));
var updateProfile = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((data) => {
	const username = slugBase(data.username).slice(0, 20);
	const displayName = data.displayName.trim().slice(0, 40) || username;
	const bio = data.bio.trim().slice(0, 160);
	const website = data.website.trim().slice(0, 120);
	if (data.avatarUrl && data.avatarUrl.length > 55e4) throw new Error("La foto de perfil es demasiado pesada");
	return {
		username,
		displayName,
		bio,
		website,
		avatarUrl: data.avatarUrl
	};
}).handler(createSsrRpc("4ba048d1e93461497dd2eaa0ba2f2ee5b065e67f181c64e6023a4fbb042cff46"));
var createPost = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((data) => {
	if (!data.imageUrl || data.imageUrl.length < 20) throw new Error("Falta la foto");
	if (data.imageUrl.length > 65e4) throw new Error("La foto es demasiado pesada");
	return {
		imageUrl: data.imageUrl,
		caption: data.caption.trim().slice(0, 500),
		location: data.location.trim().slice(0, 80),
		music: data.music ?? null
	};
}).handler(createSsrRpc("b87a705d21f422de288a8796a3a6e9b0268ad02a7374945222dd6406bf4ba8f7"));
var createStory = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((imageUrl) => {
	if (!imageUrl || imageUrl.length > 65e4) throw new Error("Foto no válida");
	return imageUrl;
}).handler(createSsrRpc("49b0026646737295b4e6df98978fdcf926612dc0cb415e4d7f7f8559f3b91b97"));
var toggleLike = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((postId) => Number(postId)).handler(createSsrRpc("1b8af2494860ca80616e7faaada76bfcbef858024f999fc72a445432117333ce"));
var toggleSave = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((postId) => Number(postId)).handler(createSsrRpc("8b852b6129e7a41204e8a7a5f813634d8c6da8fb88dba109ca5188a2eedb1d2c"));
var addComment = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((data) => {
	const body = data.body.trim().slice(0, 280);
	if (!body) throw new Error("Escribe un comentario");
	return {
		postId: Number(data.postId),
		body
	};
}).handler(createSsrRpc("5a4bcd2b26204949406c10415a201856d9a60bd958d36651480f9add31105937"));
var toggleFollow = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((userId) => String(userId)).handler(createSsrRpc("1db790904ce6c20ca8804701e96705809940131a8da5dcf048a2602a0acaea7d"));
var getSaved = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("980b39be5d77767cd647c570cb9b65b8e6cdebe52446fd73b58ac09d931fb8e9"));
var getNotifications = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("da58e89f107d7e0ceda73ca11ff0c9f559244f83fd6aee702dc09d6cca41a4f9"));
var markNotificationsRead = createServerFn({ method: "POST" }).middleware([authMiddleware]).handler(createSsrRpc("184d9c5c457f62a3ad94e06fbbf3043c0ce7ef48afdc93ab38829f0683a37c1a"));
var getConversations = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("ef5388f1a742b08813768607a3d9e0e7c0477fba273c3b9faec5c7874656a13f"));
var getMessages = createServerFn({ method: "GET" }).middleware([authMiddleware]).validator((username) => String(username)).handler(createSsrRpc("45d741f91732e0e34119fe06b23554043bd99435df4b988d56cb926b438ca6af"));
var sendMessage = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((data) => {
	const body = data.body.trim().slice(0, 500);
	if (!body) throw new Error("Escribe un mensaje");
	return {
		username: data.username,
		body
	};
}).handler(createSsrRpc("1aa8e9da95a4494f9ebe4722b1f2a73360ea6de8b2bb716516399f71f92b53e9"));
var deletePost = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((postId) => Number(postId)).handler(createSsrRpc("114cda324b05ca867cd9e6d34965b5dbbade340e531b97c7d35dd23920a78462"));
//#endregion
export { updateProfile as C, toggleSave as S, markNotificationsRead as _, deletePost as a, toggleFollow as b, getExplore as c, getMyProfile as d, getNotifications as f, getStories as g, getSaved as h, createStory as i, getFeed as l, getProfile as m, bootstrapMe as n, getComments as o, getPost as p, createPost as r, getConversations as s, addComment as t, getMessages as u, searchAll as v, toggleLike as x, sendMessage as y };
