import { o as __toESM } from "../_runtime.mjs";
import { i as require_react, r as require_jsx_runtime, t as useQuery } from "../_libs/react+tanstack__react-query.mjs";
import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { o as Search } from "../_libs/lucide-react.mjs";
import { v as searchAll } from "./server-DOuEFaR7.mjs";
import { t as Avatar } from "./avatar-BoIYd6iS.mjs";
import { n as PostGrid } from "./post-card-CEEK9XXp.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/search-BBTv2h1m.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function SearchPage() {
	const [q, setQ] = (0, import_react.useState)("");
	const result = useQuery({
		queryKey: ["search", q],
		queryFn: () => searchAll({ data: q }),
		enabled: q.trim().length >= 1
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "px-3 py-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
			className: "relative block",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "absolute left-3 top-1/2 size-4 -translate-y-1/2 text-ink-soft" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				className: "nex-input pl-10",
				placeholder: "Personas, lugares, pies de foto",
				value: q,
				onChange: (e) => setQ(e.target.value),
				autoFocus: true
			})]
		}), result.data ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-4 space-y-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mb-2 font-display text-lg",
				children: "Personas"
			}), result.data.people.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-ink-soft",
				children: "Nadie con ese nombre."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "space-y-2",
				children: result.data.people.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/u/$username",
					params: { username: p.username },
					className: "flex items-center gap-3 rounded-2xl bg-polaroid px-3 py-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Avatar, {
						src: p.avatarUrl,
						name: p.displayName
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block text-sm font-semibold",
						children: p.username
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block text-xs text-ink-soft",
						children: p.displayName
					})] })]
				}) }, p.userId))
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mb-2 font-display text-lg",
				children: "Publicaciones"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PostGrid, { posts: result.data.posts })] })]
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "px-2 py-12 text-center text-sm text-ink-soft",
			children: "Busca un usuario, un lugar o una frase del pie de foto."
		})]
	});
}
//#endregion
export { SearchPage as component };
