import { o as __toESM } from "../_runtime.mjs";
import { i as require_react, r as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { S as useNavigate, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as GROK_PROVIDERS } from "./server-Bcsa6CyA.mjs";
import { r as signIn, t as authClient } from "./client-C4Vz-GON.mjs";
import { n as useCurrentUserState } from "./use-current-user-B2bKddY0.mjs";
import { n as bootstrapMe } from "./server-DOuEFaR7.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/login-CJtcldIF.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Login() {
	const navigate = useNavigate();
	const { user, isPending } = useCurrentUserState();
	const [mode, setMode] = (0, import_react.useState)("in");
	const [name, setName] = (0, import_react.useState)("");
	const [email, setEmail] = (0, import_react.useState)("");
	const [password, setPassword] = (0, import_react.useState)("");
	const [error, setError] = (0, import_react.useState)(null);
	const [busy, setBusy] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (!isPending && user) navigate({ to: "/" });
	}, [
		isPending,
		user,
		navigate
	]);
	async function onEmail(e) {
		e.preventDefault();
		setError(null);
		setBusy(true);
		try {
			if (mode === "up") {
				const { error: err } = await authClient.signUp.email({
					email,
					password,
					name: name.trim() || email.split("@")[0] || "Nexly"
				});
				if (err) throw new Error(err.message || "No se pudo crear la cuenta");
			} else {
				const { error: err } = await authClient.signIn.email({
					email,
					password
				});
				if (err) throw new Error(err.message || "No se pudo entrar");
			}
			await bootstrapMe({ data: {
				name: name || null,
				email,
				image: null
			} }).catch(() => void 0);
			await navigate({ to: "/" });
		} catch (err) {
			setError(err instanceof Error ? err.message : "Algo falló");
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "nex-leather relative min-h-dvh overflow-hidden px-5 py-10",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "nex-grain pointer-events-none absolute inset-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative mx-auto flex min-h-[calc(100dvh-5rem)] w-full max-w-sm flex-col justify-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-8 text-center",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "nex-lens mx-auto mb-4",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "nex-lens-inner" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "nex-emboss font-display text-5xl tracking-tight",
							children: "Nexly"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm text-cream/80",
							children: "La red social que se siente en las manos."
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "nex-linen rounded-3xl p-5 shadow-[0_24px_50px_-18px_rgba(0,0,0,0.55)]",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mb-4 grid grid-cols-2 gap-1 rounded-xl bg-walnut/10 p-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: mode === "in" ? "nex-btn-brass rounded-lg py-2 text-sm" : "rounded-lg py-2 text-sm",
								onClick: () => setMode("in"),
								children: "Entrar"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: mode === "up" ? "nex-btn-brass rounded-lg py-2 text-sm" : "rounded-lg py-2 text-sm",
								onClick: () => setMode("up"),
								children: "Crear cuenta"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
							className: "space-y-3",
							onSubmit: onEmail,
							children: [
								mode === "up" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									className: "nex-input",
									placeholder: "Nombre",
									value: name,
									onChange: (e) => setName(e.target.value),
									autoComplete: "name"
								}) : null,
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									className: "nex-input",
									placeholder: "Correo",
									type: "email",
									required: true,
									value: email,
									onChange: (e) => setEmail(e.target.value),
									autoComplete: "email"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									className: "nex-input",
									placeholder: "Contraseña (mín. 8)",
									type: "password",
									required: true,
									minLength: 8,
									value: password,
									onChange: (e) => setPassword(e.target.value),
									autoComplete: mode === "up" ? "new-password" : "current-password"
								}),
								error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm text-ruby",
									children: error
								}) : null,
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "submit",
									className: "nex-btn w-full",
									disabled: busy,
									children: busy ? "Revelando…" : mode === "up" ? "Unirme a Nexly" : "Abrir el carrete"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "my-4 text-center text-xs tracking-wide text-ink-soft",
							children: "o continúa con"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "space-y-2",
							children: GROK_PROVIDERS.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								className: "nex-btn-ghost w-full",
								onClick: () => signIn(p.providerId, { callbackURL: "/" }),
								children: ["Continuar con ", p.label]
							}, p.providerId))
						})
					] })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/",
					className: "mt-6 text-center text-sm text-brass",
					children: "Seguir como invitado"
				})
			]
		})]
	});
}
//#endregion
export { Login as component };
