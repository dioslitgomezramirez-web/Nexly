import { r as createServerFn } from "./ssr.mjs";
import { t as createSsrRpc } from "./createSsrRpc-B2Izd0c7.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/itunes-BF-gY6zr.js
function upgradeArt(url) {
	if (!url) return null;
	return url.replace("100x100bb", "300x300bb").replace("100x100", "300x300");
}
function mapItunes(row) {
	if (!row.trackId || !row.trackName || !row.artistName) return null;
	return {
		trackId: String(row.trackId),
		name: row.trackName,
		artist: row.artistName,
		previewUrl: row.previewUrl ?? null,
		artworkUrl: upgradeArt(row.artworkUrl100)
	};
}
async function fetchItunesSongs(term, limit = 20) {
	const q = term.trim();
	if (!q) return [];
	const url = new URL("https://itunes.apple.com/search");
	url.searchParams.set("term", q);
	url.searchParams.set("media", "music");
	url.searchParams.set("entity", "song");
	url.searchParams.set("limit", String(Math.min(40, Math.max(1, limit))));
	url.searchParams.set("country", "es");
	const res = await fetch(url.toString(), { headers: { Accept: "application/json" } });
	if (!res.ok) throw new Error("iTunes no respondió");
	const json = await res.json();
	const out = [];
	for (const row of json.results ?? []) {
		const mapped = mapItunes(row);
		if (mapped) out.push(mapped);
	}
	return out;
}
var searchMusic = createServerFn({ method: "GET" }).validator((term) => String(term ?? "").slice(0, 80)).handler(createSsrRpc("d27625b87d4cd11c8c2e5db5f16e3a21ab63a42053c3202776c662d4938a6b3b"));
var listTopMusic = createServerFn({ method: "GET" }).handler(createSsrRpc("867ca90233a1d76ef2f1a7cd27ad5ab9ca3e4ba6188bcc56cd743d3d95e325da"));
var resolvePreview = createServerFn({ method: "GET" }).validator((payload) => payload).handler(createSsrRpc("a9e2d9130f7fed4cb70e0ccd4ce567f746e702bc4f2a426d2ad78b12c5847abe"));
//#endregion
export { searchMusic as i, listTopMusic as n, resolvePreview as r, fetchItunesSongs as t };
