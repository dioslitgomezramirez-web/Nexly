import { r as require_jsx_runtime, t as useQuery } from "../_libs/react+tanstack__react-query.mjs";
import { c as getExplore } from "./server-DOuEFaR7.mjs";
import { n as PostGrid } from "./post-card-CEEK9XXp.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/explore-DTLwkxKg.js
var import_jsx_runtime = require_jsx_runtime();
function ExplorePage() {
	const q = useQuery({
		queryKey: ["explore"],
		queryFn: () => getExplore()
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "pb-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "px-4 py-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-2xl",
				children: "Explorar"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-ink-soft",
				children: "Lo más mirado del carrete."
			})]
		}), q.isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "py-16 text-center text-sm text-ink-soft",
			children: "Buscando luz…"
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PostGrid, { posts: q.data ?? [] })]
	});
}
//#endregion
export { ExplorePage as component };
