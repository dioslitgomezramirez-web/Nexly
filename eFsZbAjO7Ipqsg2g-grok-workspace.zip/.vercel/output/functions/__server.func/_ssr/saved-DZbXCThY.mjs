import { r as require_jsx_runtime, t as useQuery } from "../_libs/react+tanstack__react-query.mjs";
import { n as useCurrentUserState } from "./use-current-user-B2bKddY0.mjs";
import { h as getSaved } from "./server-DOuEFaR7.mjs";
import { n as PostGrid } from "./post-card-CEEK9XXp.mjs";
import { t as RedirectToSignIn } from "./gates-q9-EKWXz.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/saved-DZbXCThY.js
var import_jsx_runtime = require_jsx_runtime();
function SavedPage() {
	const { user, isPending } = useCurrentUserState();
	const q = useQuery({
		queryKey: ["saved"],
		queryFn: () => getSaved(),
		enabled: Boolean(user)
	});
	if (isPending) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-40" });
	if (!user) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RedirectToSignIn, {});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "pb-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
				className: "px-4 py-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-2xl",
					children: "Guardadas"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PostGrid, { posts: q.data ?? [] }),
			!q.isLoading && (q.data ?? []).length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "px-4 py-12 text-center text-sm text-ink-soft",
				children: "Marca el marcapáginas en una foto para encontrarla aquí."
			}) : null
		]
	});
}
//#endregion
export { SavedPage as component };
