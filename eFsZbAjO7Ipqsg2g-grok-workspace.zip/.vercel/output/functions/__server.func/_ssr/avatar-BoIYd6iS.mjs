import { r as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { t as cn } from "./utils-Ccwa5Si9.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/avatar-BoIYd6iS.js
var import_jsx_runtime = require_jsx_runtime();
function Avatar({ src, name, size = "md", className }) {
	const dim = size === "sm" ? "size-8 text-xs" : size === "lg" ? "size-16 text-xl" : size === "xl" ? "size-24 text-3xl" : "size-11 text-sm";
	const initial = (name.trim()[0] || "N").toUpperCase();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn("relative inline-grid shrink-0 place-items-center overflow-hidden rounded-full", "bg-gradient-to-b from-brass to-brass-deep text-walnut font-display font-semibold", "shadow-[inset_0_1px_0_rgba(255,255,230,0.45),0_2px_4px_rgba(26,18,12,0.35)]", dim, className),
		children: src ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
			src,
			alt: "",
			className: "size-full object-cover"
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			"aria-hidden": true,
			children: initial
		})
	});
}
//#endregion
export { Avatar as t };
