import { r as require_jsx_runtime, t as useQuery } from "../_libs/react+tanstack__react-query.mjs";
import { a as queryClient, r as Route$2 } from "./router-Cy4vxgtI.mjs";
import { t as useCurrentUser } from "./use-current-user-B2bKddY0.mjs";
import { o as getComments, p as getPost } from "./server-DOuEFaR7.mjs";
import { t as PostCard } from "./post-card-CEEK9XXp.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/p._postId-Cz_5L9X1.js
var import_jsx_runtime = require_jsx_runtime();
function PostPage() {
	const { postId } = Route$2.useParams();
	const id = Number(postId);
	const user = useCurrentUser();
	const post = useQuery({
		queryKey: ["post", id],
		queryFn: () => getPost({ data: id })
	});
	const comments = useQuery({
		queryKey: ["comments", id],
		queryFn: () => getComments({ data: id }),
		enabled: Number.isFinite(id)
	});
	if (post.isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "py-16 text-center text-sm text-ink-soft",
		children: "Revelando…"
	});
	if (!post.data) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "py-16 text-center text-sm text-ink-soft",
		children: "Esta foto ya no está."
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "px-3 py-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PostCard, {
			post: post.data,
			comments: comments.data,
			canDelete: Boolean(user) && !post.data.userId.startsWith("seed:") && user?.id === post.data.userId,
			onChange: (next) => {
				if (next.id < 0) {
					queryClient.setQueryData(["post", id], null);
					return;
				}
				queryClient.setQueryData(["post", id], next);
				comments.refetch();
			}
		})
	});
}
//#endregion
export { PostPage as component };
