import { r as require_jsx_runtime, t as useQuery } from "../_libs/react+tanstack__react-query.mjs";
import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as useCurrentUserState } from "./use-current-user-B2bKddY0.mjs";
import { s as getConversations } from "./server-DOuEFaR7.mjs";
import { i as timeAgo } from "./utils-Ccwa5Si9.mjs";
import { t as Avatar } from "./avatar-BoIYd6iS.mjs";
import { t as RedirectToSignIn } from "./gates-q9-EKWXz.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/messages-CUHxbnm8.js
var import_jsx_runtime = require_jsx_runtime();
function MessagesPage() {
	const { user, isPending } = useCurrentUserState();
	const q = useQuery({
		queryKey: ["conversations"],
		queryFn: () => getConversations(),
		enabled: Boolean(user)
	});
	if (isPending) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-40" });
	if (!user) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RedirectToSignIn, {});
	const items = q.data ?? [];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "px-3 py-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "font-display text-2xl",
			children: "Correspondencia"
		}), q.isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "py-12 text-center text-sm text-ink-soft",
			children: "Abriendo el buzón…"
		}) : items.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "py-12 text-center text-sm text-ink-soft",
			children: "Aún no hay cartas. Abre un perfil y pulsa el avión de papel."
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-3 space-y-2",
			children: items.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/messages/$username",
				params: { username: c.username },
				className: "flex items-center gap-3 rounded-2xl bg-polaroid px-3 py-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Avatar, {
						src: c.avatarUrl,
						name: c.displayName
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "min-w-0 flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "flex items-center justify-between gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "truncate text-sm font-semibold",
								children: c.displayName
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[11px] text-ink-soft",
								children: timeAgo(c.lastAt)
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block truncate text-sm text-ink-soft",
							children: c.lastBody
						})]
					}),
					c.unread > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "grid min-w-6 place-items-center rounded-full bg-ruby px-1.5 text-[11px] text-cream tabular-nums",
						children: c.unread
					}) : null
				]
			}) }, c.userId))
		})]
	});
}
//#endregion
export { MessagesPage as component };
