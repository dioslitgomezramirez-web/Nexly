import { o as __toESM } from "../_runtime.mjs";
import { i as require_react, r as require_jsx_runtime, t as useQuery } from "../_libs/react+tanstack__react-query.mjs";
import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as useCurrentUserState } from "./use-current-user-B2bKddY0.mjs";
import { _ as markNotificationsRead, f as getNotifications } from "./server-DOuEFaR7.mjs";
import { i as timeAgo } from "./utils-Ccwa5Si9.mjs";
import { t as Avatar } from "./avatar-BoIYd6iS.mjs";
import { t as RedirectToSignIn } from "./gates-q9-EKWXz.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/notifications-BHryOSoX.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function NotificationsPage() {
	const { user, isPending } = useCurrentUserState();
	const q = useQuery({
		queryKey: ["notifications"],
		queryFn: () => getNotifications(),
		enabled: Boolean(user)
	});
	(0, import_react.useEffect)(() => {
		if (user) markNotificationsRead();
	}, [user]);
	if (isPending) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-40" });
	if (!user) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RedirectToSignIn, {});
	const items = q.data ?? [];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "px-3 py-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "font-display text-2xl",
			children: "Avisos"
		}), q.isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "py-12 text-center text-sm text-ink-soft",
			children: "Cargando…"
		}) : items.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "py-12 text-center text-sm text-ink-soft",
			children: "Aquí aparecerán me gusta, comentarios y seguidores."
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-3 space-y-2",
			children: items.map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: n.postId ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/p/$postId",
				params: { postId: String(n.postId) },
				className: "flex items-center gap-3 rounded-2xl bg-polaroid px-3 py-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Avatar, {
					src: n.actor.avatarUrl,
					name: n.actor.displayName
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "min-w-0 flex-1 text-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-semibold",
							children: n.actor.username
						}),
						" ",
						labelFor(n.type),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mt-0.5 block text-xs text-ink-soft",
							children: timeAgo(n.createdAt)
						})
					]
				})]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/u/$username",
				params: { username: n.actor.username },
				className: "flex items-center gap-3 rounded-2xl bg-polaroid px-3 py-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Avatar, {
					src: n.actor.avatarUrl,
					name: n.actor.displayName
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "min-w-0 flex-1 text-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-semibold",
							children: n.actor.username
						}),
						" ",
						labelFor(n.type),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mt-0.5 block text-xs text-ink-soft",
							children: timeAgo(n.createdAt)
						})
					]
				})]
			}) }, n.id))
		})]
	});
}
function labelFor(type) {
	if (type === "like") return "le dio me gusta a tu foto.";
	if (type === "comment") return "comentó tu foto.";
	if (type === "follow") return "empezó a seguirte.";
	return "interactuó contigo.";
}
//#endregion
export { NotificationsPage as component };
