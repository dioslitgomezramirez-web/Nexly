import { r as createServerFn } from "./ssr.mjs";
import { c as getSql } from "./server-Bcsa6CyA.mjs";
import { t as authMiddleware } from "./middleware-Dm6n349X.mjs";
import { t as fetchItunesSongs } from "./itunes-BF-gY6zr.mjs";
import { t as createServerRpc } from "./createServerRpc-CcvdN_gc.mjs";
import { getSessionUser } from "./verify.server-CBP2r4yF.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/server-CIHO7Y7P.js
var img = (id, w = 900, h = 1125) => `https://images.unsplash.com/${id}?auto=format&fit=crop&w=${w}&h=${h}&q=80`;
var av = (id) => `https://images.unsplash.com/${id}?auto=format&fit=crop&w=240&h=240&q=80&facepad=2`;
var USERS = [
	{
		id: "seed:lunavera",
		username: "luna.vera",
		displayName: "Luna Vera",
		bio: "Viajo ligera. Luz de las seis. Película caducada a propósito.",
		avatar: av("photo-1524504388940-b1c1722653e1"),
		story: img("photo-1507525428034-b723cf961d3e", 720, 1280),
		posts: [
			{
				image: img("photo-1507525428034-b723cf961d3e"),
				caption: "El mar no pregunta a qué hora llegas.",
				location: "Formentera",
				song: "Rosalia MALAMENTE",
				hoursAgo: 4
			},
			{
				image: img("photo-1469474968028-56623f02e42e"),
				caption: "Niebla en el valle y el termo aún caliente.",
				location: "Picos de Europa",
				song: "Natalia Lafourcade Hasta la Raiz",
				hoursAgo: 28
			},
			{
				image: img("photo-1470071459604-3b5ec3a7fe05"),
				caption: "Caminé hasta que el GPS se rindió.",
				location: "Glencoe, Escocia",
				song: "Radiohead Creep",
				hoursAgo: 72
			},
			{
				image: img("photo-1500534314209-a25ddb2bd429"),
				caption: "Arena, viento, y una idea que no se va.",
				location: "Atacama",
				song: "Tame Impala The Less I Know The Better",
				hoursAgo: 140
			}
		]
	},
	{
		id: "seed:marcoatlas",
		username: "marco.atlas",
		displayName: "Marco Atlas",
		bio: "Hormigón, sombra y geometría. Arquitectura que se deja retratar.",
		avatar: av("photo-1506794778202-cad84cf45f1d"),
		story: img("photo-1480714378408-67cf0d13bc1b", 720, 1280),
		posts: [
			{
				image: img("photo-1480714378408-67cf0d13bc1b"),
				caption: "La ciudad de noche es un circuito impreso.",
				location: "Tokio",
				song: "The Weeknd Blinding Lights",
				hoursAgo: 7
			},
			{
				image: img("photo-1486325212027-8081e485255e"),
				caption: "Simetría que duele de tan limpia.",
				location: "Lisboa",
				song: "Daft Punk Get Lucky",
				hoursAgo: 40
			},
			{
				image: img("photo-1441974231531-c6227db76b6e"),
				caption: "Entre el bosque y el edificio, elige ambos.",
				location: "Vancouver",
				song: "Bon Iver Holocene",
				hoursAgo: 96
			},
			{
				image: img("photo-1493246507139-91e8fad9978e"),
				caption: "El horizonte es una línea que alguien dibujó mal.",
				location: "Islandia",
				song: "Sigur Ros Hoppipolla",
				hoursAgo: 180
			}
		]
	},
	{
		id: "seed:norafilm",
		username: "nora.film",
		displayName: "Nora Film",
		bio: "35 mm. Revelado en el fregadero. Nada de filtros: solo grano.",
		avatar: av("photo-1487412720507-e7ab37603c6f"),
		story: img("photo-1529626455594-4ff0802cfb7e", 720, 1280),
		posts: [
			{
				image: img("photo-1529626455594-4ff0802cfb7e"),
				caption: "El último rollo del verano.",
				location: "Estudio, Madrid",
				song: "Sade Smooth Operator",
				hoursAgo: 9
			},
			{
				image: img("photo-1494790108377-be9c29b29330"),
				caption: "Luz de ventana, siempre.",
				location: "Malasaña",
				song: "Frank Ocean Pink White",
				hoursAgo: 50
			},
			{
				image: img("photo-1539571696357-5a69c17a67c6"),
				caption: "Retrato a f/1.4 y una conversación larga.",
				location: "Barcelona",
				song: "Arctic Monkeys Do I Wanna Know",
				hoursAgo: 110
			},
			{
				image: img("photo-1515886657613-9f3515e0c79f"),
				caption: "Rojo de estudio. No se discute.",
				location: "París",
				song: "The xx Intro",
				hoursAgo: 200
			}
		]
	},
	{
		id: "seed:kaiwaves",
		username: "kai.waves",
		displayName: "Kai Waves",
		bio: "Mareas, cera y madrugones. Si no hay olas, hay café.",
		avatar: av("photo-1507003211169-0a1dd7228f2d"),
		story: img("photo-1502680390469-be93e304b0dd", 720, 1280),
		posts: [
			{
				image: img("photo-1502680390469-be93e304b0dd"),
				caption: "Agua de 16 grados. El cuerpo ya lo sabe.",
				location: "Mundaka",
				song: "Jack Johnson Banana Pancakes",
				hoursAgo: 6
			},
			{
				image: img("photo-1507525428034-b723cf961d3e"),
				caption: "El set de las 7:12. Nadie más en el pico.",
				location: "Ericeira",
				song: "Mac DeMarco Chamber of Reflection",
				hoursAgo: 33
			},
			{
				image: img("photo-1439066615861-d1af74d74000"),
				caption: "Lago en calma, tabla en el techo.",
				location: "Annecy",
				song: "Khruangbin White Gloves",
				hoursAgo: 88
			},
			{
				image: img("photo-1468413253725-0d518d4d1bb7"),
				caption: "El cielo hizo el resto.",
				location: "Byron Bay",
				song: "Tame Impala Let It Happen",
				hoursAgo: 160
			}
		]
	},
	{
		id: "seed:islakitchen",
		username: "isla.kitchen",
		displayName: "Isla Kitchen",
		bio: "Recetas de domingo. Mantequilla a temperatura ambiente.",
		avatar: av("photo-1438761681033-6461ffad8d80"),
		story: img("photo-1504674900247-0877df9cc836", 720, 1280),
		posts: [
			{
				image: img("photo-1504674900247-0877df9cc836"),
				caption: "Mesa para nadie y para todos.",
				location: "Casa",
				song: "Norah Jones Don't Know Why",
				hoursAgo: 3
			},
			{
				image: img("photo-1540189549336-e6eac4ab0bb0"),
				caption: "Pasta, albahaca, y el último rayo de sol.",
				location: "Bolonia",
				song: "Andrea Bocelli Con Te Partiro",
				hoursAgo: 26
			},
			{
				image: img("photo-1482049016687-2d3ff1b3fdcb"),
				caption: "Huevos, pan y un periódico que ya nadie compra.",
				location: "Oporto",
				song: "Cafe Tacvba Eres",
				hoursAgo: 70
			},
			{
				image: img("photo-1414235077428-338989a2e8c0"),
				caption: "El primer plato de la noche.",
				location: "San Sebastián",
				song: "Buena Vista Social Club Chan Chan",
				hoursAgo: 130
			}
		]
	},
	{
		id: "seed:theonight",
		username: "theo.night",
		displayName: "Theo Night",
		bio: "Neón, lluvia y taxis. La ciudad cuando se quita el maquillaje.",
		avatar: av("photo-1472099645785-5658abf4ff4e"),
		story: img("photo-1492684223066-81342ee5ff30", 720, 1280),
		posts: [
			{
				image: img("photo-1492684223066-81342ee5ff30"),
				caption: "El concierto empezó antes de entrar.",
				location: "Berlin",
				song: "Daft Punk One More Time",
				hoursAgo: 8
			},
			{
				image: img("photo-1514525253161-7a46d19cd819"),
				caption: "Luces que no piden permiso.",
				location: "Seúl",
				song: "The Weeknd Save Your Tears",
				hoursAgo: 44
			},
			{
				image: img("photo-1519677100203-a0e668c92439"),
				caption: "Calle mojada, ISO alto, corazón rápido.",
				location: "Nueva York",
				song: "The xx Angels",
				hoursAgo: 102
			},
			{
				image: img("photo-1511379938547-c1f69419868d"),
				caption: "Un piano abierto a las 2:13.",
				location: "Jazz club, Ciudad de México",
				song: "Norah Jones Come Away With Me",
				hoursAgo: 210
			}
		]
	},
	{
		id: "seed:amarabloom",
		username: "amara.bloom",
		displayName: "Amara Bloom",
		bio: "Flores que duran un día. Las fotografío para que duren más.",
		avatar: av("photo-1544005313-94ddf0286df2"),
		story: img("photo-1490750967868-88aa4a6bc3ea", 720, 1280),
		posts: [
			{
				image: img("photo-1490750967868-88aa4a6bc3ea"),
				caption: "El jardín no entiende de prisas.",
				location: "Kew Gardens",
				song: "Billie Eilish Birds of a Feather",
				hoursAgo: 11
			},
			{
				image: img("photo-1462275646964-a0e3386b89fa"),
				caption: "Cerezos. Un minuto. Luego el viento.",
				location: "Kioto",
				song: "Joe Hisaishi Path of the Wind",
				hoursAgo: 55
			},
			{
				image: img("photo-1501004318641-b39e6451bec6"),
				caption: "Verde que limpia la cabeza.",
				location: "Invernadero, Valencia",
				song: "Sade No Ordinary Love",
				hoursAgo: 118
			},
			{
				image: img("photo-1416879595882-3373a0480b5b"),
				caption: "Campo de trigo, mano en el bolsillo.",
				location: "Toscana",
				song: "Jorge Drexler Todo se transforma",
				hoursAgo: 190
			}
		]
	},
	{
		id: "seed:julesstudio",
		username: "jules.studio",
		displayName: "Jules Studio",
		bio: "Moda sin pasarela. Tela, gesto, silencio.",
		avatar: av("photo-1534528741775-53994a69daeb"),
		story: img("photo-1469334031218-e382a71b716b", 720, 1280),
		posts: [
			{
				image: img("photo-1469334031218-e382a71b716b"),
				caption: "El abrigo pesa, la pose no.",
				location: "Milán",
				song: "The Weeknd Die For You",
				hoursAgo: 5
			},
			{
				image: img("photo-1515886657613-9f3515e0c79f"),
				caption: "Rojo contra hormigón.",
				location: "Estudio 4",
				song: "Rauw Alejandro Todo de Ti",
				hoursAgo: 31
			},
			{
				image: img("photo-1483985988355-763728e1935b"),
				caption: "Escaparate a las 9:40, antes de abrir.",
				location: "Londres",
				song: "Arctic Monkeys Why'd You Only Call Me",
				hoursAgo: 84
			},
			{
				image: img("photo-1490481651871-ab68de25d43d"),
				caption: "Seda y una sola fuente de luz.",
				location: "Copenhague",
				song: "Sade Kiss of Life",
				hoursAgo: 150
			}
		]
	},
	{
		id: "seed:riotrails",
		username: "rio.trails",
		displayName: "Río Trails",
		bio: "Botas embarradas. Mapas doblados. Cimas que no salen en Google.",
		avatar: av("photo-1500648767791-00dcc994a43e"),
		story: img("photo-1464822759023-fed622ff2c3b", 720, 1280),
		posts: [
			{
				image: img("photo-1464822759023-fed622ff2c3b"),
				caption: "A 2.400 m el aire tiene otra densidad.",
				location: "Alpes suizos",
				song: "Bon Iver Skinny Love",
				hoursAgo: 12
			},
			{
				image: img("photo-1500530855697-b586d89ba3ee"),
				caption: "Bosque que traga el ruido.",
				location: "Oregon",
				song: "Fleet Foxes White Winter Hymnal",
				hoursAgo: 47
			},
			{
				image: img("photo-1483728642387-6c3bdd6c93e5"),
				caption: "Cima, nubes debajo, sándwich encima.",
				location: "Patagonia",
				song: "Sigur Ros Svefn-g-englar",
				hoursAgo: 99
			},
			{
				image: img("photo-1519681393784-d120267933ba"),
				caption: "Dormimos bajo esto. No hay techo mejor.",
				location: "Desierto de Tabernas",
				song: "M83 Midnight City",
				hoursAgo: 170
			}
		]
	},
	{
		id: "seed:sofialens",
		username: "sofia.lens",
		displayName: "Sofía Lens",
		bio: "Retratos que no piden sonreír. Gente real, luz real.",
		avatar: av("photo-1531123897727-8f129e1688ce"),
		story: img("photo-1529156069898-49953e39b3ac", 720, 1280),
		posts: [
			{
				image: img("photo-1529156069898-49953e39b3ac"),
				caption: "La risa que no posó.",
				location: "Parque del Retiro",
				song: "Karol G Si Antes Te Hubiera Conocido",
				hoursAgo: 2
			},
			{
				image: img("photo-1524504388940-b1c1722653e1"),
				caption: "Oro viejo y un jersey de lana.",
				location: "Estudio norte",
				song: "Billie Eilish What Was I Made For",
				hoursAgo: 38
			},
			{
				image: img("photo-1537633552985-df874d359afe"),
				caption: "Manos. Siempre las manos.",
				location: "Sevilla",
				song: "Rosalia Beso",
				hoursAgo: 92
			},
			{
				image: img("photo-1517841905240-472988babdf9"),
				caption: "Un retrato y un secreto.",
				location: "Oaxaca",
				song: "Natalia Lafourcade Nunca Es Suficiente",
				hoursAgo: 155
			}
		]
	},
	{
		id: "seed:edenceramic",
		username: "eden.ceramic",
		displayName: "Eden Ceramic",
		bio: "Arcilla, torno y paciencia. Lo que se cae se vuelve otra cosa.",
		avatar: av("photo-1508214751196-bcfd4ca60f91"),
		story: img("photo-1565193566173-7a0ee3dbe261", 720, 1280),
		posts: [
			{
				image: img("photo-1565193566173-7a0ee3dbe261"),
				caption: "El torno gira, la cabeza se calla.",
				location: "Taller, Granada",
				song: "Khruangbin Time This Time Tomorrow",
				hoursAgo: 15
			},
			{
				image: img("photo-1578749556568-bc2c40e68b61"),
				caption: "Esmalte que no salió como esperaba. Mejor.",
				location: "Horno 2",
				song: "C Tangana Tu Me Dejaste De Querer",
				hoursAgo: 60
			},
			{
				image: img("photo-1610701596007-11502861dcfa"),
				caption: "Estantería de errores hermosos.",
				location: "Taller",
				song: "Feist 1234",
				hoursAgo: 124
			},
			{
				image: img("photo-1441986300917-64674bd600d8"),
				caption: "Luz de taller a las cuatro.",
				location: "Lisboa",
				song: "The xx Crystalised",
				hoursAgo: 188
			}
		]
	},
	{
		id: "seed:nicovinyl",
		username: "nico.vinyl",
		displayName: "Nico Vinyl",
		bio: "Colecciono discos y silencios entre pistas. Café a 33 rpm.",
		avatar: av("photo-1504257432389-52343af06ae3"),
		story: img("photo-1511671782779-c97d3d27a1d4", 720, 1280),
		posts: [
			{
				image: img("photo-1511671782779-c97d3d27a1d4"),
				caption: "La primera cara, siempre.",
				location: "Disquería, Buenos Aires",
				song: "Pink Floyd Wish You Were Here",
				hoursAgo: 1
			},
			{
				image: img("photo-1511379938547-c1f69419868d"),
				caption: "Afinar es una forma de esperar.",
				location: "Sala de ensayo",
				song: "Radiohead No Surprises",
				hoursAgo: 29
			},
			{
				image: img("photo-1470225620780-dba8ba36b745"),
				caption: "El público todavía no entra. El aire ya sí.",
				location: "Festival",
				song: "LCD Soundsystem Dance Yrself Clean",
				hoursAgo: 78
			},
			{
				image: img("photo-1487215078519-e21cc028cb29"),
				caption: "Auriculares, lluvia, lado B.",
				location: "Casa",
				song: "Frank Ocean Ivy",
				hoursAgo: 145
			}
		]
	},
	{
		id: "seed:clairepages",
		username: "claire.pages",
		displayName: "Claire Pages",
		bio: "Libros subrayados y mesas junto a la ventana.",
		avatar: av("photo-1548142813-c348350df52b"),
		story: img("photo-1517248135467-4c7edcad34c4", 720, 1280),
		posts: [
			{
				image: img("photo-1517248135467-4c7edcad34c4"),
				caption: "La mesa de siempre. El café, distinto.",
				location: "Café Central, Viena",
				song: "Norah Jones Sunrise",
				hoursAgo: 10
			},
			{
				image: img("photo-1512820790803-83ca734da794"),
				caption: "Capítulo 12. No molestar.",
				location: "Librería, Oporto",
				song: "Jose Gonzalez Heartbeats",
				hoursAgo: 42
			},
			{
				image: img("photo-1493770348141-0ef56da6b14e"),
				caption: "Desayuno y una novela que no quiero que acabe.",
				location: "Casa",
				song: "Feist Mushaboom",
				hoursAgo: 86
			},
			{
				image: img("photo-1524995997946-a1c2e315a42f"),
				caption: "Estanterías como horizonte.",
				location: "Biblioteca, Praga",
				song: "Sufjan Stevens Mystery of Love",
				hoursAgo: 166
			}
		]
	},
	{
		id: "seed:andresfuego",
		username: "andres.fuego",
		displayName: "Andrés Fuego",
		bio: "Calle, carbón y salsa que pica. Lo mejor no tiene mantel.",
		avatar: av("photo-1504257432389-52343af06ae3"),
		story: img("photo-1555939594-58d7cb561ad1", 720, 1280),
		posts: [
			{
				image: img("photo-1555939594-58d7cb561ad1"),
				caption: "Humo de carbón a las 14:00. Religión laica.",
				location: "Mercado de San Juan, CDMX",
				song: "Bad Bunny DtMF",
				hoursAgo: 6
			},
			{
				image: img("photo-1565299624946-b28f40a0ae38"),
				caption: "Pizza que no pide disculpas.",
				location: "Nápoles",
				song: "Nathy Peluso Business Woman",
				hoursAgo: 35
			},
			{
				image: img("photo-1544025162-d766d818bcd9"),
				caption: "Tacos de la esquina. Cinco. No se discute.",
				location: "Roma Norte",
				song: "Cafe Tacvba La Ingrata",
				hoursAgo: 80
			},
			{
				image: img("photo-1473093295043-cdd812d0e601"),
				caption: "El último bocado, el mejor.",
				location: "Valencia",
				song: "Karol G Provenza",
				hoursAgo: 148
			}
		]
	},
	{
		id: "seed:micacoast",
		username: "mica.coast",
		displayName: "Mica Coast",
		bio: "Acantilados, faros y suéteres que huelen a sal.",
		avatar: av("photo-1524504388940-b1c1722653e1"),
		story: img("photo-1500375592092-40eb2168fd21", 720, 1280),
		posts: [
			{
				image: img("photo-1500375592092-40eb2168fd21"),
				caption: "La ola más alta del mes. Yo, más pequeña.",
				location: "Nazaré",
				song: "Lana Del Rey Summertime Sadness",
				hoursAgo: 13
			},
			{
				image: img("photo-1473116763249-2faaef81ccda"),
				caption: "Pies en la orilla, cabeza lejos.",
				location: "Algarve",
				song: "The xx Intro",
				hoursAgo: 52
			},
			{
				image: img("photo-1468413253725-0d518d4d1bb7"),
				caption: "Atardecer que no cabe en el rollo.",
				location: "Cádiz",
				song: "Rosalia Sakura",
				hoursAgo: 108
			},
			{
				image: img("photo-1439066615861-d1af74d74000"),
				caption: "Agua quieta. Rara vez.",
				location: "Como",
				song: "Cigarettes After Sex Apocalypse",
				hoursAgo: 175
			}
		]
	},
	{
		id: "seed:yaragold",
		username: "yara.gold",
		displayName: "Yara Gold",
		bio: "Naturaleza muerta que no está muerta. Latón, tela, fruta.",
		avatar: av("photo-1531746020798-e6953c6e8e04"),
		story: img("photo-1519681393784-d120267933ba", 720, 1280),
		posts: [
			{
				image: img("photo-1490750967868-88aa4a6bc3ea"),
				caption: "Composición de martes. Luz rasante.",
				location: "Estudio",
				song: "Sade Smooth Operator",
				hoursAgo: 16
			},
			{
				image: img("photo-1519741497674-611481863552"),
				caption: "Detalles que se miran de cerca.",
				location: "Amberes",
				song: "The xx Angels",
				hoursAgo: 58
			},
			{
				image: img("photo-1515886657613-9f3515e0c79f"),
				caption: "Un rojo. Solo uno.",
				location: "Estudio",
				song: "Rauw Alejandro Todo de Ti",
				hoursAgo: 120
			},
			{
				image: img("photo-1441986300917-64674bd600d8"),
				caption: "Interior con eco.",
				location: "Copenhagen",
				song: "Jose Gonzalez Heartbeats",
				hoursAgo: 198
			}
		]
	}
];
var COMMENTS = [
	"Esto se siente. Qué luz.",
	"Guardada. Voy a volver a mirarla.",
	"¿Qué cámara usaste?",
	"Me transportaste. En serio.",
	"El grano está perfecto.",
	"Quiero estar ahí ahora mismo.",
	"Composición impecable.",
	"Esa hora mágica no miente.",
	"Más de esto, por favor.",
	"Se oye el silencio de la foto."
];
async function lookupSongs(queries) {
	const unique = [...new Set(queries)];
	const map = /* @__PURE__ */ new Map();
	const chunk = 8;
	for (let i = 0; i < unique.length; i += chunk) {
		const slice = unique.slice(i, i + chunk);
		const results = await Promise.all(slice.map(async (q) => {
			try {
				return [q, (await fetchItunesSongs(q, 1))[0] ?? null];
			} catch {
				return [q, null];
			}
		}));
		for (const [q, track] of results) if (track) map.set(q, track);
	}
	return map;
}
var globalRef = globalThis;
async function ensureSeed(sql) {
	globalRef.__nexlySeed__ ??= runSeed(sql).catch((err) => {
		globalRef.__nexlySeed__ = void 0;
		throw err;
	});
	return globalRef.__nexlySeed__;
}
async function runSeed(sql) {
	const n = (await sql`select count(*)::int as c from profiles where is_seed = true`)[0]?.c ?? 0;
	if (n >= USERS.length) {
		await sql`
      update stories
      set expires_at = now() + interval '20 days'
      where user_id like 'seed:%' and expires_at < now() + interval '2 days'
    `;
		return;
	}
	if (n > 0) await sql`delete from profiles where is_seed = true`;
	const tracks = await lookupSongs(USERS.flatMap((u) => u.posts.map((p) => p.song)));
	for (const user of USERS) await sql`
      insert into profiles (user_id, username, display_name, bio, avatar_url, is_seed)
      values (
        ${user.id},
        ${user.username},
        ${user.displayName},
        ${user.bio},
        ${user.avatar},
        true
      )
      on conflict (user_id) do nothing
    `;
	for (const user of USERS) {
		await sql`
      insert into stories (user_id, image_url, expires_at)
      values (${user.id}, ${user.story}, now() + interval '20 days')
    `;
		for (const post of user.posts) {
			const track = tracks.get(post.song);
			await sql`
        insert into posts (
          user_id, image_url, caption, location,
          music_track_id, music_name, music_artist, music_preview_url, music_artwork_url,
          created_at
        ) values (
          ${user.id},
          ${post.image},
          ${post.caption},
          ${post.location},
          ${track?.trackId ?? null},
          ${track?.name ?? null},
          ${track?.artist ?? null},
          ${track?.previewUrl ?? null},
          ${track?.artworkUrl ?? null},
          now() - (${post.hoursAgo}::text || ' hours')::interval
        )
      `;
		}
	}
	const posts = await sql`
    select id, user_id from posts where user_id like 'seed:%' order by id
  `;
	for (let i = 0; i < USERS.length; i++) {
		const a = USERS[i];
		for (let j = 1; j <= 5; j++) {
			const b = USERS[(i + j) % USERS.length];
			if (a.id === b.id) continue;
			await sql`
        insert into follows (follower_id, following_id)
        values (${a.id}, ${b.id})
        on conflict do nothing
      `;
		}
	}
	for (const post of posts) {
		const likers = USERS.filter((u) => u.id !== post.user_id).slice(0, 3 + post.id % 6);
		for (const liker of likers) await sql`
        insert into likes (post_id, user_id)
        values (${post.id}, ${liker.id})
        on conflict do nothing
      `;
		const commenters = USERS.filter((u) => u.id !== post.user_id).slice(post.id % 4, post.id % 4 + 2);
		for (const c of commenters) {
			const body = COMMENTS[(post.id + c.username.length) % COMMENTS.length];
			await sql`
        insert into comments (post_id, user_id, body, created_at)
        values (
          ${post.id},
          ${c.id},
          ${body},
          now() - ((${post.id % 20})::text || ' hours')::interval
        )
      `;
		}
	}
}
async function optionalUserId() {
	try {
		return (await getSessionUser())?.id ?? null;
	} catch {
		return null;
	}
}
function slugBase(input) {
	return input.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().replace(/[^a-z0-9]+/g, "").slice(0, 16) || "nexly";
}
async function uniqueUsername(sql, base, userId) {
	let candidate = base;
	for (let i = 0; i < 40; i++) {
		const rows = await sql`
      select user_id from profiles where username = ${candidate}
    `;
		if (rows.length === 0 || rows[0].user_id === userId) return candidate;
		candidate = `${base.slice(0, 12)}${Math.floor(10 + Math.random() * 89)}`;
	}
	return `${base.slice(0, 10)}${Date.now().toString(36).slice(-4)}`;
}
async function ensureProfile(sql, userId, hint) {
	if ((await sql`select user_id from profiles where user_id = ${userId}`).length) return;
	const username = await uniqueUsername(sql, slugBase(hint?.name || hint?.email?.split("@")[0] || "nexly"), userId);
	await sql`
    insert into profiles (user_id, username, display_name, avatar_url)
    values (${userId}, ${username}, ${hint?.name && hint.name.trim() || username}, ${hint?.image ?? null})
    on conflict (user_id) do nothing
  `;
}
async function ready(sql) {
	await ensureSeed(sql);
}
function toIso(v) {
	if (v instanceof Date) return v.toISOString();
	if (typeof v === "string") return v;
	return (/* @__PURE__ */ new Date()).toISOString();
}
function mapPost(row) {
	return {
		id: Number(row.id),
		userId: row.user_id,
		username: row.username,
		displayName: row.display_name,
		avatarUrl: row.avatar_url,
		imageUrl: row.image_url,
		caption: row.caption,
		location: row.location,
		music: row.music_name && row.music_artist ? {
			trackId: row.music_track_id ?? row.music_name,
			name: row.music_name,
			artist: row.music_artist,
			previewUrl: row.music_preview_url,
			artworkUrl: row.music_artwork_url
		} : null,
		createdAt: toIso(row.created_at),
		likeCount: Number(row.like_count),
		commentCount: Number(row.comment_count),
		likedByMe: Boolean(row.liked_by_me),
		savedByMe: Boolean(row.saved_by_me)
	};
}
var POST_SELECT = `
  select
    p.id, p.user_id, p.image_url, p.caption, p.location,
    p.music_track_id, p.music_name, p.music_artist, p.music_preview_url, p.music_artwork_url,
    p.created_at,
    pr.username, pr.display_name, pr.avatar_url,
    (select count(*)::int from likes l where l.post_id = p.id) as like_count,
    (select count(*)::int from comments c where c.post_id = p.id) as comment_count,
    case when $1::text is null then 0
         when exists (select 1 from likes l2 where l2.post_id = p.id and l2.user_id = $1) then 1
         else 0 end as liked_by_me,
    case when $1::text is null then 0
         when exists (select 1 from saves s where s.post_id = p.id and s.user_id = $1) then 1
         else 0 end as saved_by_me
`;
var getFeed_createServerFn_handler = createServerRpc({
	id: "c167f789dced6ceeb7e53b5771aacbcdfe7b9d2238f8c4c16b093acce6c33bd7",
	name: "getFeed",
	filename: "src/lib/social/server.ts"
}, (opts) => getFeed.__executeServer(opts));
var getFeed = createServerFn({ method: "GET" }).validator((payload) => payload ?? { tab: "foryou" }).handler(getFeed_createServerFn_handler, async ({ data }) => {
	const sql = await getSql();
	await ready(sql);
	const me = await optionalUserId();
	return ((data?.tab === "following" ? "following" : "foryou") === "following" && me ? await sql.query(`${POST_SELECT}
             from posts p
             join profiles pr on pr.user_id = p.user_id
             where p.user_id in (select following_id from follows where follower_id = $2)
                or p.user_id = $2
             order by p.created_at desc
             limit 60`, [me, me]) : await sql.query(`${POST_SELECT}
             from posts p
             join profiles pr on pr.user_id = p.user_id
             order by p.created_at desc
             limit 60`, [me])).map(mapPost);
});
var getExplore_createServerFn_handler = createServerRpc({
	id: "4ba78b3362c1f354bafc24b4e1209ae480facf38d552cba5550960fc3ae2452b",
	name: "getExplore",
	filename: "src/lib/social/server.ts"
}, (opts) => getExplore.__executeServer(opts));
var getExplore = createServerFn({ method: "GET" }).handler(getExplore_createServerFn_handler, async () => {
	const sql = await getSql();
	await ready(sql);
	const me = await optionalUserId();
	return (await sql.query(`${POST_SELECT}
     from posts p
     join profiles pr on pr.user_id = p.user_id
     order by like_count desc, p.created_at desc
     limit 48`, [me])).map(mapPost);
});
var getPost_createServerFn_handler = createServerRpc({
	id: "d1806a7998772b3b21f61ae15ddac7fae93c9580d2484214eaa6db3ddaef993d",
	name: "getPost",
	filename: "src/lib/social/server.ts"
}, (opts) => getPost.__executeServer(opts));
var getPost = createServerFn({ method: "GET" }).validator((id) => Number(id)).handler(getPost_createServerFn_handler, async ({ data: id }) => {
	const sql = await getSql();
	await ready(sql);
	const me = await optionalUserId();
	const rows = await sql.query(`${POST_SELECT}
       from posts p
       join profiles pr on pr.user_id = p.user_id
       where p.id = $2`, [me, id]);
	return rows[0] ? mapPost(rows[0]) : null;
});
var getStories_createServerFn_handler = createServerRpc({
	id: "45a4271be6a7a325ed38eedf35f42524ce6537602234188e2edd958c6c1093c7",
	name: "getStories",
	filename: "src/lib/social/server.ts"
}, (opts) => getStories.__executeServer(opts));
var getStories = createServerFn({ method: "GET" }).handler(getStories_createServerFn_handler, async () => {
	const sql = await getSql();
	await ready(sql);
	const rows = await sql`
    select s.id, s.user_id, s.image_url, s.created_at,
           pr.username, pr.display_name, pr.avatar_url
    from stories s
    join profiles pr on pr.user_id = s.user_id
    where s.expires_at > now()
    order by s.created_at desc
  `;
	const map = /* @__PURE__ */ new Map();
	for (const r of rows) {
		let g = map.get(r.user_id);
		if (!g) {
			g = {
				userId: r.user_id,
				username: r.username,
				displayName: r.display_name,
				avatarUrl: r.avatar_url,
				items: []
			};
			map.set(r.user_id, g);
		}
		g.items.push({
			id: Number(r.id),
			imageUrl: r.image_url,
			createdAt: toIso(r.created_at)
		});
	}
	return [...map.values()];
});
var getComments_createServerFn_handler = createServerRpc({
	id: "af80b23960cc36e920dc093c5b63bfb95abcf5b812f15ed216b7d9e638e5297b",
	name: "getComments",
	filename: "src/lib/social/server.ts"
}, (opts) => getComments.__executeServer(opts));
var getComments = createServerFn({ method: "GET" }).validator((postId) => Number(postId)).handler(getComments_createServerFn_handler, async ({ data: postId }) => {
	return (await (await getSql())`
      select c.id, c.post_id, c.user_id, c.body, c.created_at,
             pr.username, pr.display_name, pr.avatar_url
      from comments c
      join profiles pr on pr.user_id = c.user_id
      where c.post_id = ${postId}
      order by c.created_at asc
      limit 80
    `).map((r) => ({
		id: Number(r.id),
		postId: Number(r.post_id),
		userId: r.user_id,
		username: r.username,
		displayName: r.display_name,
		avatarUrl: r.avatar_url,
		body: r.body,
		createdAt: toIso(r.created_at)
	}));
});
var searchAll_createServerFn_handler = createServerRpc({
	id: "b7cbe95836c28f9463a37c924f9195e0d59df744df016c07dc246a63d5d3ff34",
	name: "searchAll",
	filename: "src/lib/social/server.ts"
}, (opts) => searchAll.__executeServer(opts));
var searchAll = createServerFn({ method: "GET" }).validator((q) => String(q ?? "").trim().slice(0, 60)).handler(searchAll_createServerFn_handler, async ({ data: q }) => {
	const sql = await getSql();
	await ready(sql);
	const me = await optionalUserId();
	if (!q) return {
		people: [],
		posts: []
	};
	const like = `%${q.toLowerCase()}%`;
	const people = await sql`
      select user_id, username, display_name, bio, avatar_url, website, is_seed, created_at
      from profiles
      where lower(username) like ${like} or lower(display_name) like ${like}
      order by is_seed desc, username
      limit 16
    `;
	const posts = await sql.query(`${POST_SELECT}
       from posts p
       join profiles pr on pr.user_id = p.user_id
       where lower(p.caption) like $2 or lower(coalesce(p.location,'')) like $2
          or lower(pr.username) like $2
       order by p.created_at desc
       limit 24`, [me, like]);
	const mappedPeople = [];
	for (const p of people) mappedPeople.push(await hydrateProfile(sql, p, me));
	return {
		people: mappedPeople,
		posts: posts.map(mapPost)
	};
});
async function hydrateProfile(sql, p, me) {
	const [posts, followers, following, followRow] = await Promise.all([
		sql`select count(*)::int as c from posts where user_id = ${p.user_id}`,
		sql`select count(*)::int as c from follows where following_id = ${p.user_id}`,
		sql`select count(*)::int as c from follows where follower_id = ${p.user_id}`,
		me && me !== p.user_id ? sql`select 1 from follows where follower_id = ${me} and following_id = ${p.user_id}` : Promise.resolve([])
	]);
	return {
		userId: p.user_id,
		username: p.username,
		displayName: p.display_name,
		bio: p.bio,
		avatarUrl: p.avatar_url,
		website: p.website,
		isSeed: Boolean(p.is_seed),
		createdAt: toIso(p.created_at),
		postsCount: Number(posts[0]?.c ?? 0),
		followersCount: Number(followers[0]?.c ?? 0),
		followingCount: Number(following[0]?.c ?? 0),
		isFollowing: followRow.length > 0,
		isMe: me === p.user_id
	};
}
var getProfile_createServerFn_handler = createServerRpc({
	id: "c9bd8e12d6ebbe0ee7d91ac002adf46ab12a7aa684875d79580e030858704d17",
	name: "getProfile",
	filename: "src/lib/social/server.ts"
}, (opts) => getProfile.__executeServer(opts));
var getProfile = createServerFn({ method: "GET" }).validator((username) => String(username).replace(/^@/, "").slice(0, 32)).handler(getProfile_createServerFn_handler, async ({ data: username }) => {
	const sql = await getSql();
	await ready(sql);
	const me = await optionalUserId();
	const rows = await sql`
      select user_id, username, display_name, bio, avatar_url, website, is_seed, created_at
      from profiles where lower(username) = ${username.toLowerCase()}
    `;
	if (!rows[0]) return null;
	return {
		profile: await hydrateProfile(sql, rows[0], me),
		posts: (await sql.query(`${POST_SELECT}
       from posts p
       join profiles pr on pr.user_id = p.user_id
       where p.user_id = $2
       order by p.created_at desc
       limit 60`, [me, rows[0].user_id])).map(mapPost)
	};
});
var getMyProfile_createServerFn_handler = createServerRpc({
	id: "7cdf8eb461c63e16a950fe2223aa7db7a0cc7838d212c2c01b764d9247086bbf",
	name: "getMyProfile",
	filename: "src/lib/social/server.ts"
}, (opts) => getMyProfile.__executeServer(opts));
var getMyProfile = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(getMyProfile_createServerFn_handler, async ({ context }) => {
	const sql = await getSql();
	await ready(sql);
	await ensureProfile(sql, context.userId);
	const rows = await sql`
      select user_id, username, display_name, bio, avatar_url, website, is_seed, created_at
      from profiles where user_id = ${context.userId}
    `;
	if (!rows[0]) return null;
	return hydrateProfile(sql, rows[0], context.userId);
});
var bootstrapMe_createServerFn_handler = createServerRpc({
	id: "cccd4576f2b6a77d7b589b0cd32eec3008a0ea0a008c5f80bf7937a53ea88e86",
	name: "bootstrapMe",
	filename: "src/lib/social/server.ts"
}, (opts) => bootstrapMe.__executeServer(opts));
var bootstrapMe = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((hint) => hint).handler(bootstrapMe_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	await ready(sql);
	await ensureProfile(sql, context.userId, data);
	const rows = await sql`
      select user_id, username, display_name, bio, avatar_url, website, is_seed, created_at
      from profiles where user_id = ${context.userId}
    `;
	return rows[0] ? hydrateProfile(sql, rows[0], context.userId) : null;
});
var updateProfile_createServerFn_handler = createServerRpc({
	id: "4ba048d1e93461497dd2eaa0ba2f2ee5b065e67f181c64e6023a4fbb042cff46",
	name: "updateProfile",
	filename: "src/lib/social/server.ts"
}, (opts) => updateProfile.__executeServer(opts));
var updateProfile = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((data) => {
	const username = slugBase(data.username).slice(0, 20);
	const displayName = data.displayName.trim().slice(0, 40) || username;
	const bio = data.bio.trim().slice(0, 160);
	const website = data.website.trim().slice(0, 120);
	if (data.avatarUrl && data.avatarUrl.length > 55e4) throw new Error("La foto de perfil es demasiado pesada");
	return {
		username,
		displayName,
		bio,
		website,
		avatarUrl: data.avatarUrl
	};
}).handler(updateProfile_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	await ensureProfile(sql, context.userId);
	if ((await sql`
      select user_id from profiles where username = ${data.username} and user_id <> ${context.userId}
    `).length) throw new Error("Ese nombre de usuario ya existe");
	await sql`
      update profiles set
        username = ${data.username},
        display_name = ${data.displayName},
        bio = ${data.bio},
        website = ${data.website || null},
        avatar_url = coalesce(${data.avatarUrl ?? null}, avatar_url)
      where user_id = ${context.userId}
    `;
	return { ok: true };
});
var createPost_createServerFn_handler = createServerRpc({
	id: "b87a705d21f422de288a8796a3a6e9b0268ad02a7374945222dd6406bf4ba8f7",
	name: "createPost",
	filename: "src/lib/social/server.ts"
}, (opts) => createPost.__executeServer(opts));
var createPost = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((data) => {
	if (!data.imageUrl || data.imageUrl.length < 20) throw new Error("Falta la foto");
	if (data.imageUrl.length > 65e4) throw new Error("La foto es demasiado pesada");
	return {
		imageUrl: data.imageUrl,
		caption: data.caption.trim().slice(0, 500),
		location: data.location.trim().slice(0, 80),
		music: data.music ?? null
	};
}).handler(createPost_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	await ensureProfile(sql, context.userId);
	const rows = await sql`
      insert into posts (
        user_id, image_url, caption, location,
        music_track_id, music_name, music_artist, music_preview_url, music_artwork_url
      ) values (
        ${context.userId},
        ${data.imageUrl},
        ${data.caption},
        ${data.location || null},
        ${data.music?.trackId ?? null},
        ${data.music?.name ?? null},
        ${data.music?.artist ?? null},
        ${data.music?.previewUrl ?? null},
        ${data.music?.artworkUrl ?? null}
      )
      returning id
    `;
	return { id: Number(rows[0].id) };
});
var createStory_createServerFn_handler = createServerRpc({
	id: "49b0026646737295b4e6df98978fdcf926612dc0cb415e4d7f7f8559f3b91b97",
	name: "createStory",
	filename: "src/lib/social/server.ts"
}, (opts) => createStory.__executeServer(opts));
var createStory = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((imageUrl) => {
	if (!imageUrl || imageUrl.length > 65e4) throw new Error("Foto no válida");
	return imageUrl;
}).handler(createStory_createServerFn_handler, async ({ context, data: imageUrl }) => {
	const sql = await getSql();
	await ensureProfile(sql, context.userId);
	await sql`
      insert into stories (user_id, image_url, expires_at)
      values (${context.userId}, ${imageUrl}, now() + interval '24 hours')
    `;
	return { ok: true };
});
var toggleLike_createServerFn_handler = createServerRpc({
	id: "1b8af2494860ca80616e7faaada76bfcbef858024f999fc72a445432117333ce",
	name: "toggleLike",
	filename: "src/lib/social/server.ts"
}, (opts) => toggleLike.__executeServer(opts));
var toggleLike = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((postId) => Number(postId)).handler(toggleLike_createServerFn_handler, async ({ context, data: postId }) => {
	const sql = await getSql();
	await ensureProfile(sql, context.userId);
	if ((await sql`
      select 1 from likes where post_id = ${postId} and user_id = ${context.userId}
    `).length) {
		await sql`delete from likes where post_id = ${postId} and user_id = ${context.userId}`;
		return { liked: false };
	}
	await sql`insert into likes (post_id, user_id) values (${postId}, ${context.userId})`;
	const owner = (await sql`select user_id from posts where id = ${postId}`)[0]?.user_id;
	if (owner && owner !== context.userId && !owner.startsWith("seed:")) await sql`
        insert into notifications (user_id, actor_id, type, post_id)
        values (${owner}, ${context.userId}, 'like', ${postId})
      `;
	return { liked: true };
});
var toggleSave_createServerFn_handler = createServerRpc({
	id: "8b852b6129e7a41204e8a7a5f813634d8c6da8fb88dba109ca5188a2eedb1d2c",
	name: "toggleSave",
	filename: "src/lib/social/server.ts"
}, (opts) => toggleSave.__executeServer(opts));
var toggleSave = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((postId) => Number(postId)).handler(toggleSave_createServerFn_handler, async ({ context, data: postId }) => {
	const sql = await getSql();
	await ensureProfile(sql, context.userId);
	if ((await sql`
      select 1 from saves where post_id = ${postId} and user_id = ${context.userId}
    `).length) {
		await sql`delete from saves where post_id = ${postId} and user_id = ${context.userId}`;
		return { saved: false };
	}
	await sql`insert into saves (post_id, user_id) values (${postId}, ${context.userId})`;
	return { saved: true };
});
var addComment_createServerFn_handler = createServerRpc({
	id: "5a4bcd2b26204949406c10415a201856d9a60bd958d36651480f9add31105937",
	name: "addComment",
	filename: "src/lib/social/server.ts"
}, (opts) => addComment.__executeServer(opts));
var addComment = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((data) => {
	const body = data.body.trim().slice(0, 280);
	if (!body) throw new Error("Escribe un comentario");
	return {
		postId: Number(data.postId),
		body
	};
}).handler(addComment_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	await ensureProfile(sql, context.userId);
	const rows = await sql`
      insert into comments (post_id, user_id, body)
      values (${data.postId}, ${context.userId}, ${data.body})
      returning id, created_at
    `;
	const owner = (await sql`select user_id from posts where id = ${data.postId}`)[0]?.user_id;
	if (owner && owner !== context.userId && !owner.startsWith("seed:")) await sql`
        insert into notifications (user_id, actor_id, type, post_id)
        values (${owner}, ${context.userId}, 'comment', ${data.postId})
      `;
	const me = await sql`
      select username, display_name, avatar_url from profiles where user_id = ${context.userId}
    `;
	return {
		id: Number(rows[0].id),
		postId: data.postId,
		userId: context.userId,
		username: me[0]?.username ?? "tu",
		displayName: me[0]?.display_name ?? "Tú",
		avatarUrl: me[0]?.avatar_url ?? null,
		body: data.body,
		createdAt: toIso(rows[0].created_at)
	};
});
var toggleFollow_createServerFn_handler = createServerRpc({
	id: "1db790904ce6c20ca8804701e96705809940131a8da5dcf048a2602a0acaea7d",
	name: "toggleFollow",
	filename: "src/lib/social/server.ts"
}, (opts) => toggleFollow.__executeServer(opts));
var toggleFollow = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((userId) => String(userId)).handler(toggleFollow_createServerFn_handler, async ({ context, data: userId }) => {
	if (userId === context.userId) return { following: false };
	const sql = await getSql();
	await ensureProfile(sql, context.userId);
	if ((await sql`
      select 1 from follows where follower_id = ${context.userId} and following_id = ${userId}
    `).length) {
		await sql`delete from follows where follower_id = ${context.userId} and following_id = ${userId}`;
		return { following: false };
	}
	await sql`
      insert into follows (follower_id, following_id)
      values (${context.userId}, ${userId})
      on conflict do nothing
    `;
	if (!userId.startsWith("seed:")) await sql`
        insert into notifications (user_id, actor_id, type)
        values (${userId}, ${context.userId}, 'follow')
      `;
	return { following: true };
});
var getSaved_createServerFn_handler = createServerRpc({
	id: "980b39be5d77767cd647c570cb9b65b8e6cdebe52446fd73b58ac09d931fb8e9",
	name: "getSaved",
	filename: "src/lib/social/server.ts"
}, (opts) => getSaved.__executeServer(opts));
var getSaved = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(getSaved_createServerFn_handler, async ({ context }) => {
	const sql = await getSql();
	await ready(sql);
	return (await sql.query(`${POST_SELECT}
       from saves sv
       join posts p on p.id = sv.post_id
       join profiles pr on pr.user_id = p.user_id
       where sv.user_id = $1
       order by sv.created_at desc
       limit 60`, [context.userId])).map(mapPost);
});
var getNotifications_createServerFn_handler = createServerRpc({
	id: "da58e89f107d7e0ceda73ca11ff0c9f559244f83fd6aee702dc09d6cca41a4f9",
	name: "getNotifications",
	filename: "src/lib/social/server.ts"
}, (opts) => getNotifications.__executeServer(opts));
var getNotifications = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(getNotifications_createServerFn_handler, async ({ context }) => {
	return (await (await getSql())`
      select n.id, n.type, n.post_id, n.created_at, n.is_read,
             n.actor_id, pr.username, pr.display_name, pr.avatar_url
      from notifications n
      join profiles pr on pr.user_id = n.actor_id
      where n.user_id = ${context.userId}
      order by n.created_at desc
      limit 40
    `).map((r) => ({
		id: Number(r.id),
		type: r.type,
		postId: r.post_id == null ? null : Number(r.post_id),
		createdAt: toIso(r.created_at),
		isRead: Boolean(r.is_read),
		actor: {
			userId: r.actor_id,
			username: r.username,
			displayName: r.display_name,
			avatarUrl: r.avatar_url
		}
	}));
});
var markNotificationsRead_createServerFn_handler = createServerRpc({
	id: "184d9c5c457f62a3ad94e06fbbf3043c0ce7ef48afdc93ab38829f0683a37c1a",
	name: "markNotificationsRead",
	filename: "src/lib/social/server.ts"
}, (opts) => markNotificationsRead.__executeServer(opts));
var markNotificationsRead = createServerFn({ method: "POST" }).middleware([authMiddleware]).handler(markNotificationsRead_createServerFn_handler, async ({ context }) => {
	await (await getSql())`update notifications set is_read = true where user_id = ${context.userId} and is_read = false`;
	return { ok: true };
});
var getConversations_createServerFn_handler = createServerRpc({
	id: "ef5388f1a742b08813768607a3d9e0e7c0477fba273c3b9faec5c7874656a13f",
	name: "getConversations",
	filename: "src/lib/social/server.ts"
}, (opts) => getConversations.__executeServer(opts));
var getConversations = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(getConversations_createServerFn_handler, async ({ context }) => {
	const sql = await getSql();
	await ensureProfile(sql, context.userId);
	return (await sql`
      with last as (
        select distinct on (
          case when sender_id = ${context.userId} then recipient_id else sender_id end
        )
          case when sender_id = ${context.userId} then recipient_id else sender_id end as other_id,
          body as last_body,
          created_at as last_at
        from messages
        where sender_id = ${context.userId} or recipient_id = ${context.userId}
        order by
          case when sender_id = ${context.userId} then recipient_id else sender_id end,
          created_at desc
      )
      select l.other_id, pr.username, pr.display_name, pr.avatar_url,
             l.last_body, l.last_at,
             (select count(*)::int from messages m
              where m.sender_id = l.other_id and m.recipient_id = ${context.userId} and m.read_at is null
             ) as unread
      from last l
      join profiles pr on pr.user_id = l.other_id
      order by l.last_at desc
    `).map((r) => ({
		userId: r.other_id,
		username: r.username,
		displayName: r.display_name,
		avatarUrl: r.avatar_url,
		lastBody: r.last_body,
		lastAt: toIso(r.last_at),
		unread: Number(r.unread)
	}));
});
var getMessages_createServerFn_handler = createServerRpc({
	id: "45d741f91732e0e34119fe06b23554043bd99435df4b988d56cb926b438ca6af",
	name: "getMessages",
	filename: "src/lib/social/server.ts"
}, (opts) => getMessages.__executeServer(opts));
var getMessages = createServerFn({ method: "GET" }).middleware([authMiddleware]).validator((username) => String(username)).handler(getMessages_createServerFn_handler, async ({ context, data: username }) => {
	const sql = await getSql();
	await ensureProfile(sql, context.userId);
	const other = await sql`
      select user_id, username, display_name, avatar_url from profiles where lower(username) = ${username.toLowerCase()}
    `;
	if (!other[0]) return {
		peer: null,
		messages: []
	};
	const peerId = other[0].user_id;
	const rows = await sql`
      select id, sender_id, recipient_id, body, created_at
      from messages
      where (sender_id = ${context.userId} and recipient_id = ${peerId})
         or (sender_id = ${peerId} and recipient_id = ${context.userId})
      order by created_at asc
      limit 200
    `;
	await sql`
      update messages set read_at = now()
      where sender_id = ${peerId} and recipient_id = ${context.userId} and read_at is null
    `;
	return {
		peer: {
			userId: other[0].user_id,
			username: other[0].username,
			displayName: other[0].display_name,
			avatarUrl: other[0].avatar_url
		},
		messages: rows.map((r) => ({
			id: Number(r.id),
			senderId: r.sender_id,
			recipientId: r.recipient_id,
			body: r.body,
			createdAt: toIso(r.created_at),
			mine: r.sender_id === context.userId
		}))
	};
});
var sendMessage_createServerFn_handler = createServerRpc({
	id: "1aa8e9da95a4494f9ebe4722b1f2a73360ea6de8b2bb716516399f71f92b53e9",
	name: "sendMessage",
	filename: "src/lib/social/server.ts"
}, (opts) => sendMessage.__executeServer(opts));
var sendMessage = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((data) => {
	const body = data.body.trim().slice(0, 500);
	if (!body) throw new Error("Escribe un mensaje");
	return {
		username: data.username,
		body
	};
}).handler(sendMessage_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	await ensureProfile(sql, context.userId);
	const other = await sql`
      select user_id from profiles where lower(username) = ${data.username.toLowerCase()}
    `;
	if (!other[0]) throw new Error("No existe esa persona");
	if (other[0].user_id === context.userId) throw new Error("No puedes escribirte a ti");
	const rows = await sql`
      insert into messages (sender_id, recipient_id, body)
      values (${context.userId}, ${other[0].user_id}, ${data.body})
      returning id, created_at
    `;
	return {
		id: Number(rows[0].id),
		senderId: context.userId,
		recipientId: other[0].user_id,
		body: data.body,
		createdAt: toIso(rows[0].created_at),
		mine: true
	};
});
var deletePost_createServerFn_handler = createServerRpc({
	id: "114cda324b05ca867cd9e6d34965b5dbbade340e531b97c7d35dd23920a78462",
	name: "deletePost",
	filename: "src/lib/social/server.ts"
}, (opts) => deletePost.__executeServer(opts));
var deletePost = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((postId) => Number(postId)).handler(deletePost_createServerFn_handler, async ({ context, data: postId }) => {
	await (await getSql())`delete from posts where id = ${postId} and user_id = ${context.userId}`;
	return { ok: true };
});
//#endregion
export { addComment_createServerFn_handler, bootstrapMe_createServerFn_handler, createPost_createServerFn_handler, createStory_createServerFn_handler, deletePost_createServerFn_handler, getComments_createServerFn_handler, getConversations_createServerFn_handler, getExplore_createServerFn_handler, getFeed_createServerFn_handler, getMessages_createServerFn_handler, getMyProfile_createServerFn_handler, getNotifications_createServerFn_handler, getPost_createServerFn_handler, getProfile_createServerFn_handler, getSaved_createServerFn_handler, getStories_createServerFn_handler, markNotificationsRead_createServerFn_handler, searchAll_createServerFn_handler, sendMessage_createServerFn_handler, toggleFollow_createServerFn_handler, toggleLike_createServerFn_handler, toggleSave_createServerFn_handler, updateProfile_createServerFn_handler };
