import { o as __toESM } from "../_runtime.mjs";
import { i as require_react, r as require_jsx_runtime, t as useQuery } from "../_libs/react+tanstack__react-query.mjs";
import { S as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as queryClient } from "./router-Cy4vxgtI.mjs";
import { n as useCurrentUserState, t as useCurrentUser } from "./use-current-user-B2bKddY0.mjs";
import { C as updateProfile, d as getMyProfile } from "./server-DOuEFaR7.mjs";
import { t as Avatar } from "./avatar-BoIYd6iS.mjs";
import { t as compressImage } from "./image-CJIGJKC0.mjs";
import { t as RedirectToSignIn } from "./gates-q9-EKWXz.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/edit-profile-CmhlqKUl.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function EditProfilePage() {
	const { user, isPending } = useCurrentUserState();
	const live = useCurrentUser();
	const navigate = useNavigate();
	const q = useQuery({
		queryKey: ["me-profile"],
		queryFn: () => getMyProfile(),
		enabled: Boolean(user)
	});
	const [username, setUsername] = (0, import_react.useState)("");
	const [displayName, setDisplayName] = (0, import_react.useState)("");
	const [bio, setBio] = (0, import_react.useState)("");
	const [website, setWebsite] = (0, import_react.useState)("");
	const [avatarUrl, setAvatarUrl] = (0, import_react.useState)(null);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		if (!q.data) return;
		setUsername(q.data.username);
		setDisplayName(q.data.displayName);
		setBio(q.data.bio);
		setWebsite(q.data.website ?? "");
		setAvatarUrl(q.data.avatarUrl);
	}, [q.data]);
	if (isPending) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-40" });
	if (!user) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RedirectToSignIn, {});
	async function save(e) {
		e.preventDefault();
		setBusy(true);
		setError(null);
		try {
			await updateProfile({ data: {
				username,
				displayName,
				bio,
				website,
				avatarUrl
			} });
			await queryClient.invalidateQueries({ queryKey: ["me-profile"] });
			await navigate({
				to: "/u/$username",
				params: { username }
			});
		} catch (err) {
			setError(err instanceof Error ? err.message : "No se pudo guardar");
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		className: "space-y-3 px-4 py-4",
		onSubmit: (e) => void save(e),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-2xl",
				children: "Editar perfil"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col items-center gap-2 py-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Avatar, {
					src: avatarUrl ?? live?.profileImageUrl,
					name: displayName || "Tú",
					size: "xl"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "nex-btn-ghost text-sm",
					children: ["Cambiar retrato", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "file",
						accept: "image/*",
						className: "hidden",
						onChange: async (e) => {
							const file = e.target.files?.[0];
							if (!file) return;
							try {
								setAvatarUrl(await compressImage(file, 480));
							} catch (err) {
								setError(err instanceof Error ? err.message : "Foto no válida");
							}
						}
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				className: "nex-input",
				placeholder: "Usuario",
				value: username,
				onChange: (e) => setUsername(e.target.value)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				className: "nex-input",
				placeholder: "Nombre",
				value: displayName,
				onChange: (e) => setDisplayName(e.target.value)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
				className: "nex-input min-h-24 py-3",
				placeholder: "Bio",
				value: bio,
				onChange: (e) => setBio(e.target.value),
				maxLength: 160
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				className: "nex-input",
				placeholder: "Sitio web",
				value: website,
				onChange: (e) => setWebsite(e.target.value)
			}),
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-ruby",
				children: error
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "submit",
				className: "nex-btn w-full",
				disabled: busy,
				children: busy ? "Guardando…" : "Guardar"
			})
		]
	});
}
//#endregion
export { EditProfilePage as component };
