//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-Dezlbj1m.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/_app",
			"/login",
			"/api/auth/$"
		],
		preloads: [
			"/assets/index-Cbey7yih.js",
			"/assets/react-DB-4Zxce.js",
			"/assets/jsx-runtime-lQ8mZk5u.js",
			"/assets/link-C1C5XRbs.js",
			"/assets/useMatch-IC_uT2vm.js",
			"/assets/lazyRouteComponent-DgChyCpy.js",
			"/assets/useNavigate-BRqbw8y0.js",
			"/assets/preload-helper-Txvy3Y0k.js",
			"/assets/query-BvPW7hhH.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-Cbey7yih.js"
		} }]
	},
	"/_app": {
		filePath: "/workspace/src/routes/_app.tsx",
		children: [
			"/_app/create",
			"/_app/edit-profile",
			"/_app/explore",
			"/_app/messages",
			"/_app/music",
			"/_app/notifications",
			"/_app/saved",
			"/_app/search",
			"/_app/",
			"/_app/p/$postId",
			"/_app/u/$username"
		],
		preloads: [
			"/assets/_app-DUBIKKsf.js",
			"/assets/music-2-O4wK3Lvo.js",
			"/assets/play-CDSngWkr.js",
			"/assets/search-Dl0HgSt7.js",
			"/assets/send-NPceoszI.js",
			"/assets/x-DFvpaanb.js",
			"/assets/useQuery-CVvYVsOT.js",
			"/assets/use-current-user-Coq4jsGU.js",
			"/assets/server-DsHNtP0O.js",
			"/assets/utils-7GfKQqua.js",
			"/assets/itunes-QYcWPdOn.js",
			"/assets/player-DPD8Fp7P.js",
			"/assets/avatar-DF5xjYyu.js"
		]
	},
	"/login": {
		filePath: "/workspace/src/routes/login.tsx",
		children: void 0,
		preloads: [
			"/assets/login-Dxa4k7oD.js",
			"/assets/client-bLCk0icn.js",
			"/assets/use-current-user-Coq4jsGU.js",
			"/assets/server-DsHNtP0O.js"
		]
	},
	"/_app/create": {
		filePath: "/workspace/src/routes/_app/create.tsx",
		children: void 0,
		preloads: [
			"/assets/create-CmCMz1vL.js",
			"/assets/gates-CV-mvPg9.js",
			"/assets/image-DydvVROH.js"
		]
	},
	"/_app/edit-profile": {
		filePath: "/workspace/src/routes/_app/edit-profile.tsx",
		children: void 0,
		preloads: [
			"/assets/edit-profile-5djJ6RUU.js",
			"/assets/gates-CV-mvPg9.js",
			"/assets/image-DydvVROH.js"
		]
	},
	"/_app/explore": {
		filePath: "/workspace/src/routes/_app/explore.tsx",
		children: void 0,
		preloads: ["/assets/explore-RwEpWMGl.js", "/assets/post-card-DXnRj7jY.js"]
	},
	"/_app/messages": {
		filePath: "/workspace/src/routes/_app/messages.tsx",
		children: ["/_app/messages/$username"],
		preloads: ["/assets/messages-GVAuN068.js", "/assets/gates-CV-mvPg9.js"]
	},
	"/_app/music": {
		filePath: "/workspace/src/routes/_app/music.tsx",
		children: void 0,
		preloads: ["/assets/music-CPpxiAIW.js"]
	},
	"/_app/notifications": {
		filePath: "/workspace/src/routes/_app/notifications.tsx",
		children: void 0,
		preloads: ["/assets/notifications-0MgbVM-d.js", "/assets/gates-CV-mvPg9.js"]
	},
	"/_app/saved": {
		filePath: "/workspace/src/routes/_app/saved.tsx",
		children: void 0,
		preloads: [
			"/assets/saved--mKvZbTW.js",
			"/assets/post-card-DXnRj7jY.js",
			"/assets/gates-CV-mvPg9.js"
		]
	},
	"/_app/search": {
		filePath: "/workspace/src/routes/_app/search.tsx",
		children: void 0,
		preloads: ["/assets/search-Dh22kKWY.js", "/assets/post-card-DXnRj7jY.js"]
	},
	"/_app/": {
		filePath: "/workspace/src/routes/_app/index.tsx",
		children: void 0,
		preloads: [
			"/assets/_app-Cpd-uWUz.js",
			"/assets/post-card-DXnRj7jY.js",
			"/assets/image-DydvVROH.js"
		]
	},
	"/_app/messages/$username": {
		filePath: "/workspace/src/routes/_app/messages.$username.tsx",
		children: void 0,
		preloads: ["/assets/messages._username-BHA6hLZH.js"]
	},
	"/_app/p/$postId": {
		filePath: "/workspace/src/routes/_app/p.$postId.tsx",
		children: void 0,
		preloads: ["/assets/p._postId-BdvJKd-0.js", "/assets/post-card-DXnRj7jY.js"]
	},
	"/_app/u/$username": {
		filePath: "/workspace/src/routes/_app/u.$username.tsx",
		children: void 0,
		preloads: [
			"/assets/u._username-QTOeBgSX.js",
			"/assets/post-card-DXnRj7jY.js",
			"/assets/gates-CV-mvPg9.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
